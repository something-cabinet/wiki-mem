import * as i0 from '@angular/core';
import { InjectionToken, inject, forwardRef, input, computed, linkedSignal, output, booleanAttribute, Directive, model } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

const BrnToggleGroupToken = new InjectionToken('BrnToggleGroupToken');
function injectBrnToggleGroup() {
    return inject(BrnToggleGroupToken, { optional: true });
}
function provideBrnToggleGroup(value) {
    return { provide: BrnToggleGroupToken, useExisting: value };
}

const BRN_BUTTON_TOGGLE_GROUP_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => BrnToggleGroup),
    multi: true,
};
class BrnButtonToggleChange {
    source;
    value;
    constructor(source, value) {
        this.source = source;
        this.value = value;
    }
}
class BrnToggleGroup {
    /** The type of the toggle group. */
    type = input('single', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    /** Whether the toggle group allows multiple selections. */
    _multiple = computed(() => this.type() === 'multiple', ...(ngDevMode ? [{ debugName: "_multiple" }] : /* istanbul ignore next */ []));
    /** Value of the toggle group. */
    valueInput = input(undefined, { ...(ngDevMode ? { debugName: "valueInput" } : /* istanbul ignore next */ {}), alias: 'value' });
    value = linkedSignal(this.valueInput, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /** Emits when the value changes. */
    valueChange = output();
    /** Whether no button toggles need to be selected. */
    nullable = input(true, { ...(ngDevMode ? { debugName: "nullable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Whether the button toggle group is disabled. */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** The disabled state. */
    disabledState = linkedSignal(this.disabled, ...(ngDevMode ? [{ debugName: "disabledState" }] : /* istanbul ignore next */ []));
    /** Emit event when the group value changes. */
    change = output();
    /**
     * The method to be called in order to update ngModel.
     */
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    _onChange = () => { };
    /** onTouch function registered via registerOnTouch (ControlValueAccessor). */
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    onTouched = () => { };
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabledState.set(isDisabled);
    }
    /**
     * @internal
     * Determines whether a value can be set on the group.
     */
    canDeselect(value) {
        // if null values are allowed, the group can always be nullable
        if (this.nullable())
            return true;
        const currentValue = this.value();
        if (this._multiple() && Array.isArray(currentValue)) {
            return !(currentValue.length === 1 && currentValue[0] === value);
        }
        return currentValue !== value;
    }
    /**
     * @internal
     * Selects a value.
     */
    select(value, source) {
        if (this.disabledState() || this.isSelected(value)) {
            return;
        }
        const currentValue = this.value();
        // emit the valueChange event here as we should only emit based on user interaction
        if (this._multiple()) {
            this.emitSelectionChange([...(currentValue ?? []), value], source);
        }
        else {
            this.emitSelectionChange(value, source);
        }
    }
    /**
     * @internal
     * Deselects a value.
     */
    deselect(value, source) {
        if (this.disabledState() || !this.isSelected(value) || !this.canDeselect(value)) {
            return;
        }
        const currentValue = this.value();
        if (this._multiple()) {
            this.emitSelectionChange((currentValue ?? []).filter((v) => v !== value), source);
        }
        else if (currentValue === value) {
            this.emitSelectionChange(null, source);
        }
    }
    /**
     * @internal
     * Determines whether a value is selected.
     */
    isSelected(value) {
        const currentValue = this.value();
        if (currentValue == null ||
            currentValue === undefined ||
            (Array.isArray(currentValue) && currentValue.length === 0)) {
            return false;
        }
        if (this._multiple()) {
            return currentValue?.includes(value);
        }
        return currentValue === value;
    }
    /** Update the value of the group */
    emitSelectionChange(value, source) {
        this.value.set(value);
        this.valueChange.emit(value);
        this._onChange(value);
        this.change.emit(new BrnButtonToggleChange(source, this.value()));
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnToggleGroup, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnToggleGroup, isStandalone: true, selector: "[brnToggleGroup],brn-toggle-group", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, valueInput: { classPropertyName: "valueInput", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, nullable: { classPropertyName: "nullable", publicName: "nullable", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange", change: "change" }, host: { attributes: { "role": "group" }, listeners: { "focusout": "onTouched()" }, properties: { "attr.aria-disabled": "disabledState()", "attr.data-disabled": "disabledState()" } }, providers: [provideBrnToggleGroup(BrnToggleGroup), BRN_BUTTON_TOGGLE_GROUP_VALUE_ACCESSOR], exportAs: ["brnToggleGroup"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnToggleGroup, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnToggleGroup],brn-toggle-group',
                    exportAs: 'brnToggleGroup',
                    providers: [provideBrnToggleGroup(BrnToggleGroup), BRN_BUTTON_TOGGLE_GROUP_VALUE_ACCESSOR],
                    host: {
                        role: 'group',
                        '[attr.aria-disabled]': 'disabledState()',
                        '[attr.data-disabled]': 'disabledState()',
                        '(focusout)': 'onTouched()',
                    },
                }]
        }], propDecorators: { type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], valueInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], nullable: [{ type: i0.Input, args: [{ isSignal: true, alias: "nullable", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], change: [{ type: i0.Output, args: ["change"] }] } });

class BrnToggleGroupItem {
    static _uniqueId = 0;
    /** Access the toggle group if available. */
    _group = injectBrnToggleGroup();
    /** The id of the toggle. */
    id = input(`brn-toggle-group-item-${++BrnToggleGroupItem._uniqueId}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** The value this toggle represents. */
    value = input(...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    /** Whether the toggle is disabled. */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Whether the toggle is disabled either from itself or from the group. */
    _disabled = computed(() => this.disabled() || this._group?.disabled(), ...(ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []));
    /** The current state of the toggle when not used in a group. */
    state = model('off', ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    /** The type of the button. */
    type = input('button', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    /**
     * Accessibility label for screen readers.
     * Use when no visible label exists.
     */
    ariaLabel = input(null, { ...(ngDevMode ? { debugName: "ariaLabel" } : /* istanbul ignore next */ {}), alias: 'aria-label' });
    /** Whether the toggle is in the on state. */
    _isOn = computed(() => this._state() === 'on', ...(ngDevMode ? [{ debugName: "_isOn" }] : /* istanbul ignore next */ []));
    /** The current state that reflects the group state or the model state. */
    _state = computed(() => {
        if (this._group) {
            return this._group.isSelected(this.value()) ? 'on' : 'off';
        }
        return this.state();
    }, ...(ngDevMode ? [{ debugName: "_state" }] : /* istanbul ignore next */ []));
    toggle() {
        if (this._disabled())
            return;
        if (this._group) {
            if (this._isOn()) {
                this._group.deselect(this.value(), this);
            }
            else {
                this._group.select(this.value(), this);
            }
        }
        else {
            this.state.set(this._isOn() ? 'off' : 'on');
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnToggleGroupItem, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnToggleGroupItem, isStandalone: true, selector: "button[brnToggleGroupItem]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "aria-label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { state: "stateChange" }, host: { listeners: { "click": "toggle()" }, properties: { "id": "id()", "attr.disabled": "_disabled() ? true : null", "attr.data-disabled": "_disabled() ? true : null", "attr.data-state": "_state()", "attr.aria-pressed": "_isOn()", "attr.aria-label": "ariaLabel() || null", "type": "type()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnToggleGroupItem, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnToggleGroupItem]',
                    host: {
                        '[id]': 'id()',
                        '[attr.disabled]': '_disabled() ? true : null',
                        '[attr.data-disabled]': '_disabled() ? true : null',
                        '[attr.data-state]': '_state()',
                        '[attr.aria-pressed]': '_isOn()',
                        '[attr.aria-label]': 'ariaLabel() || null',
                        '[type]': 'type()',
                        '(click)': 'toggle()',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }, { type: i0.Output, args: ["stateChange"] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "aria-label", required: false }] }] } });

const BrnToggleGroupImports = [BrnToggleGroup, BrnToggleGroupItem];

/**
 * Generated bundle index. Do not edit.
 */

export { BRN_BUTTON_TOGGLE_GROUP_VALUE_ACCESSOR, BrnButtonToggleChange, BrnToggleGroup, BrnToggleGroupImports, BrnToggleGroupItem, injectBrnToggleGroup, provideBrnToggleGroup };
//# sourceMappingURL=spartan-ng-brain-toggle-group.mjs.map
