import { DOCUMENT } from '@angular/common';
import * as i0 from '@angular/core';
import { InjectionToken, inject, input, ElementRef, viewChild, booleanAttribute, computed, linkedSignal, effect, afterEveryRender, Directive } from '@angular/core';

const BrnDatePickerToken = new InjectionToken('BrnDatePickerToken');
function provideBrnDatePicker(instance) {
    return { provide: BrnDatePickerToken, useExisting: instance };
}
/**
 * Inject the date picker component.
 */
function injectBrnDatePicker() {
    return inject(BrnDatePickerToken);
}

/**
 * Headless behavior shared by every date picker text input (single, multi,
 * range, month-year). Owns the editable text mirror, cursor preservation and
 * the commit/parse lifecycle; styled subclasses provide the template, styling
 * and the parse/format strategy.
 *
 * `V` is the value type held by the associated date picker (e.g. `Date`,
 * `Date[]` or `[Date, Date]`).
 */
class BrnDateInput {
    static _nextId = 0;
    inputId = input(`hlm-date-picker-input-${BrnDateInput._nextId++}`, ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    _document = inject(DOCUMENT);
    _host = inject(ElementRef);
    _inputElement = viewChild.required('input');
    _pendingSelection = null;
    _datePicker = injectBrnDatePicker();
    _popover = this._datePicker.popover;
    _disabled = this._datePicker.disabledState;
    /** Initial text shown in the input. Mirrored by the picker once a date is committed. */
    inputValue = input('', ...(ngDevMode ? [{ debugName: "inputValue" }] : /* istanbul ignore next */ []));
    /** Show a clear button that resets the input and picker value. Hidden when empty. */
    showClear = input(true, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Open the popover on input click. */
    openOnClick = input(false, { ...(ngDevMode ? { debugName: "openOnClick" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Forces the invalid state visually, regardless of form control state. */
    forceInvalid = input(false, { ...(ngDevMode ? { debugName: "forceInvalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Accessible label for the clear button. */
    clearAriaLabel = input('Clear date', ...(ngDevMode ? [{ debugName: "clearAriaLabel" }] : /* istanbul ignore next */ []));
    /** Accessible label for the calendar trigger button. */
    calendarAriaLabel = input('Open calendar', ...(ngDevMode ? [{ debugName: "calendarAriaLabel" }] : /* istanbul ignore next */ []));
    /** @internal Id used by the trigger contract for labeling. */
    triggerId = computed(() => this.inputId(), ...(ngDevMode ? [{ debugName: "triggerId" }] : /* istanbul ignore next */ []));
    placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /**
     * Text shown in the input. Mirrors the picker's `formattedDate` and the
     * parent's `inputValue`, and accepts user writes via `_handleInputChange`.
     * Commits only happen on blur / Enter, so in-progress text isn't clobbered.
     */
    _inputValue = linkedSignal({ ...(ngDevMode ? { debugName: "_inputValue" } : /* istanbul ignore next */ {}), source: () => ({
            formatted: this._datePicker.formattedDate(),
            inputValue: this.inputValue(),
        }),
        computation: (source, previous) => {
            // First render: prefer formatted, fall back to inputValue.
            if (previous === undefined) {
                return source.formatted ?? source.inputValue;
            }
            // Picker's formatted date changed - snap to canonical format.
            if (source.formatted !== previous.source.formatted) {
                if (source.formatted !== undefined) {
                    return source.formatted;
                }
                // Cleared externally vs. user has invalid text in flight: only
                // mirror the clear when the displayed text was in sync.
                return previous.value === previous.source.formatted ? '' : previous.value;
            }
            // Parent updated inputValue - reflect it.
            if (source.inputValue !== previous.source.inputValue) {
                return source.inputValue;
            }
            return previous.value;
        } });
    _showClearButton = computed(() => this.showClear() && this._inputValue().length > 0, ...(ngDevMode ? [{ debugName: "_showClearButton" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => this._popover()?.setOrigin(this._host.nativeElement));
        // Re-applying `[value]` on each keystroke moves the caret to the end. Restore the caret to
        // where the user was typing after Angular has written the value back to the DOM.
        afterEveryRender(() => {
            const selection = this._pendingSelection;
            if (!selection)
                return;
            this._pendingSelection = null;
            const element = this._inputElement().nativeElement;
            if (this._document.activeElement === element && selection.start !== null && selection.end !== null) {
                element.setSelectionRange(selection.start, selection.end);
            }
        });
    }
    _handleInputChange(event) {
        const target = event.target;
        this._pendingSelection = { start: target.selectionStart, end: target.selectionEnd };
        this._inputValue.set(target.value);
    }
    _clear() {
        this._inputValue.set('');
        this._datePicker.updateDate?.(null);
        this._datePicker.touched?.();
    }
    _handleEnter(event) {
        event.preventDefault();
        this._commitDate();
        this._popover().close();
        // The field keeps focus after Enter, so restore the edit format the
        // commit snapped away from - otherwise a later blur would re-parse the
        // display format and clear the value.
        this._handleFocus();
    }
    /** On focus, reformat the committed value into the input/edit format. */
    _handleFocus() {
        const value = this._datePicker.value?.();
        if (value != null) {
            this._inputValue.set(this.formatInputValue(value));
        }
    }
    /** On blur, commit the input and snap back to the picker's display format. */
    _handleBlur() {
        this._commitDate();
        const formatted = this._datePicker.formattedDate();
        if (formatted !== undefined) {
            this._inputValue.set(formatted);
        }
    }
    _commitDate() {
        const value = this._inputValue();
        if (!value) {
            this._datePicker.updateDate?.(null);
            this._datePicker.touched?.();
            return;
        }
        // Invalid parse: clear the picker value, keep the text so the user can fix it.
        const parsed = this.parseValue(value);
        this._datePicker.updateDate?.(parsed);
        this._datePicker.touched?.();
    }
    _open() {
        this._popover().open();
    }
    _handleClick() {
        if (this.openOnClick()) {
            this._open();
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDateInput, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnDateInput, isStandalone: true, inputs: { inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, inputValue: { classPropertyName: "inputValue", publicName: "inputValue", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, openOnClick: { classPropertyName: "openOnClick", publicName: "openOnClick", isSignal: true, isRequired: false, transformFunction: null }, forceInvalid: { classPropertyName: "forceInvalid", publicName: "forceInvalid", isSignal: true, isRequired: false, transformFunction: null }, clearAriaLabel: { classPropertyName: "clearAriaLabel", publicName: "clearAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, calendarAriaLabel: { classPropertyName: "calendarAriaLabel", publicName: "calendarAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "_inputElement", first: true, predicate: ["input"], descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDateInput, decorators: [{
            type: Directive
        }], ctorParameters: () => [], propDecorators: { inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], _inputElement: [{ type: i0.ViewChild, args: ['input', { isSignal: true }] }], inputValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputValue", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], openOnClick: [{ type: i0.Input, args: [{ isSignal: true, alias: "openOnClick", required: false }] }], forceInvalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceInvalid", required: false }] }], clearAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearAriaLabel", required: false }] }], calendarAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "calendarAriaLabel", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }] } });

const BrnDatePickerTriggerToken = new InjectionToken('BrnDatePickerTriggerToken');
function provideBrnDatePickerTrigger(instance) {
    return { provide: BrnDatePickerTriggerToken, useExisting: instance };
}

/**
 * Generated bundle index. Do not edit.
 */

export { BrnDateInput, BrnDatePickerToken, BrnDatePickerTriggerToken, injectBrnDatePicker, provideBrnDatePicker, provideBrnDatePickerTrigger };
//# sourceMappingURL=spartan-ng-brain-date-picker.mjs.map
