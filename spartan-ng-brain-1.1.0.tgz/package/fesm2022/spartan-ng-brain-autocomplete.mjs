import { ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import * as i0 from '@angular/core';
import { InjectionToken, inject, forwardRef, Injector, input, booleanAttribute, linkedSignal, model, signal, contentChildren, computed, afterNextRender, effect, untracked, Directive, ElementRef, Renderer2, TemplateRef, ViewContainerRef, contentChild, PLATFORM_ID } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from '@spartan-ng/brain/field';
import { BrnFieldControl, provideBrnLabelable } from '@spartan-ng/brain/field';
import { BrnPopover } from '@spartan-ng/brain/popover';
import { injectElementSize, stringifyAsLabel } from '@spartan-ng/brain/core';
import { BrnOverlay } from '@spartan-ng/brain/overlay';
import { isPlatformBrowser } from '@angular/common';

const BrnAutocompleteItemToken = new InjectionToken('BrnAutocompleteItemToken');
function provideBrnAutocompleteItem(autocomplete) {
    return { provide: BrnAutocompleteItemToken, useExisting: autocomplete };
}

const BrnAutocompleteBaseToken = new InjectionToken('BrnAutocompleteBaseToken');
function provideBrnAutocompleteBase(autocomplete) {
    return { provide: BrnAutocompleteBaseToken, useExisting: autocomplete };
}
function injectBrnAutocompleteBase() {
    return inject(BrnAutocompleteBaseToken);
}
function getDefaultConfig() {
    return {
        isItemEqualToValue: (itemValue, selectedValue) => Object.is(itemValue, selectedValue),
        itemToString: undefined,
        autoHighlight: false,
    };
}
const BrnAutocompleteConfigToken = new InjectionToken('BrnAutocompleteConfig');
function provideBrnAutocompleteConfig(config) {
    return { provide: BrnAutocompleteConfigToken, useValue: { ...getDefaultConfig(), ...config } };
}
function injectBrnAutocompleteConfig() {
    const injectedConfig = inject(BrnAutocompleteConfigToken, { optional: true });
    return injectedConfig ? injectedConfig : getDefaultConfig();
}

const BRN_AUTOCOMPLETE_CONTROL_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => BrnAutocomplete),
    multi: true,
};
class BrnAutocomplete {
    _injector = inject(Injector);
    _fieldControl = inject(BrnFieldControl, { optional: true });
    _config = injectBrnAutocompleteConfig();
    /** Access the popover if present */
    _brnPopover = inject(BrnPopover, { optional: true });
    /** Whether the autocomplete is disabled */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _disabled = linkedSignal(this.disabled, ...(ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []));
    /** @internal The disabled state as a readonly signal */
    disabledState = this._disabled.asReadonly();
    /** A function to compare an item with the selected value. */
    isItemEqualToValue = input(this._config.isItemEqualToValue, ...(ngDevMode ? [{ debugName: "isItemEqualToValue" }] : /* istanbul ignore next */ []));
    /** A function to convert an item to a string for display. */
    itemToString = input(this._config.itemToString, ...(ngDevMode ? [{ debugName: "itemToString" }] : /* istanbul ignore next */ []));
    /** Whether to auto-highlight the first matching item. */
    autoHighlight = input(this._config.autoHighlight, { ...(ngDevMode ? { debugName: "autoHighlight" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** The selected value of the autocomplete. */
    value = model(null, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /** The current search query. */
    search = model('', ...(ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []));
    _inputWidth = signal(null, ...(ngDevMode ? [{ debugName: "_inputWidth" }] : /* istanbul ignore next */ []));
    /** @internal The width of the search input wrapper */
    searchInputWrapperWidth = this._inputWidth.asReadonly();
    /** @internal Access all the items within the autocomplete */
    items = contentChildren(BrnAutocompleteItemToken, { ...(ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {}), descendants: true });
    /** Determine if the autocomplete has any visible items */
    visibleItems = computed(() => this.items().length > 0, ...(ngDevMode ? [{ debugName: "visibleItems" }] : /* istanbul ignore next */ []));
    /** @internal The key manager for managing active descendant */
    keyManager = new ActiveDescendantKeyManager(this.items, this._injector);
    /** @internal Whether the autocomplete is expanded */
    isExpanded = computed(() => this._brnPopover?.stateComputed() === 'open', ...(ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []));
    _autocompleteInput = signal(undefined, ...(ngDevMode ? [{ debugName: "_autocompleteInput" }] : /* istanbul ignore next */ []));
    _onChange;
    _onTouched;
    labelableId = computed(() => this._autocompleteInput()?.id(), ...(ngDevMode ? [{ debugName: "labelableId" }] : /* istanbul ignore next */ []));
    controlState = this._fieldControl?.controlState;
    constructor() {
        this.keyManager
            .withVerticalOrientation()
            .withHomeAndEnd()
            .withWrap()
            .skipPredicate((item) => item.disabled);
        this._brnPopover?.closed.subscribe(() => {
            this.keyManager.setActiveItem(-1);
        });
        afterNextRender(() => {
            effect(() => {
                if (!this.autoHighlight() || !this.isExpanded() || !this.search())
                    return;
                const hasVisibleItems = this.visibleItems();
                untracked(() => {
                    if (hasVisibleItems) {
                        this.keyManager.setFirstItemActive();
                    }
                    else {
                        this.keyManager.setActiveItem(-1);
                    }
                });
            }, { injector: this._injector });
        });
    }
    registerAutocompleteInput(input) {
        return this._autocompleteInput.set(input);
    }
    updateInputWidth(width) {
        this._inputWidth.set(width);
    }
    updateSearch(value) {
        this.search.set(value);
        this.open();
        if (value === '') {
            this.resetValue();
        }
    }
    isSelected(itemValue) {
        return this.isItemEqualToValue()(itemValue, this.value());
    }
    select(itemValue) {
        this.value.set(itemValue);
        this._onChange?.(itemValue);
        this.close();
    }
    /** Select the active item with Enter key. */
    selectActiveItem() {
        if (!this.isExpanded())
            return;
        const value = this.keyManager.activeItem?.value();
        if (value) {
            this.select(value);
        }
        else {
            this.close();
        }
    }
    resetValue() {
        this.value.set(null);
        this.search.set('');
        this._onChange?.(null);
    }
    open() {
        if (this._disabled() || this.isExpanded())
            return;
        this._brnPopover?.open();
    }
    close() {
        if (this._disabled() || !this.isExpanded())
            return;
        this._brnPopover?.close();
    }
    toggle() {
        if (this._disabled())
            return;
        this.isExpanded() ? this.close() : this.open();
    }
    /** CONTROL VALUE ACCESSOR */
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled.set(isDisabled);
    }
    _onFocusOut(event) {
        const currentTarget = event.currentTarget;
        const focusedEl = event.relatedTarget;
        if (!currentTarget.contains(focusedEl)) {
            this._onTouched?.();
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocomplete, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnAutocomplete, isStandalone: true, selector: "[brnAutocomplete]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, isItemEqualToValue: { classPropertyName: "isItemEqualToValue", publicName: "isItemEqualToValue", isSignal: true, isRequired: false, transformFunction: null }, itemToString: { classPropertyName: "itemToString", publicName: "itemToString", isSignal: true, isRequired: false, transformFunction: null }, autoHighlight: { classPropertyName: "autoHighlight", publicName: "autoHighlight", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, search: { classPropertyName: "search", publicName: "search", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", search: "searchChange" }, host: { listeners: { "focusout": "_onFocusOut($event)" } }, providers: [
            BRN_AUTOCOMPLETE_CONTROL_VALUE_ACCESSOR,
            provideBrnAutocompleteBase(BrnAutocomplete),
            provideBrnLabelable(BrnAutocomplete),
        ], queries: [{ propertyName: "items", predicate: BrnAutocompleteItemToken, descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.BrnFieldControl }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocomplete, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocomplete]',
                    providers: [
                        BRN_AUTOCOMPLETE_CONTROL_VALUE_ACCESSOR,
                        provideBrnAutocompleteBase(BrnAutocomplete),
                        provideBrnLabelable(BrnAutocomplete),
                    ],
                    hostDirectives: [BrnFieldControl],
                    host: {
                        '(focusout)': '_onFocusOut($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], isItemEqualToValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "isItemEqualToValue", required: false }] }], itemToString: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemToString", required: false }] }], autoHighlight: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHighlight", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], search: [{ type: i0.Input, args: [{ isSignal: true, alias: "search", required: false }] }, { type: i0.Output, args: ["searchChange"] }], items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => BrnAutocompleteItemToken), { ...{
                            descendants: true,
                        }, isSignal: true }] }] } });

class BrnAutocompleteAnchor {
    _host = inject(ElementRef, { host: true });
    _brnOverlay = inject(BrnOverlay, { optional: true });
    _autocomplete = injectBrnAutocompleteBase();
    _elementSize = injectElementSize();
    constructor() {
        this._brnOverlay?.setOrigin(this._host.nativeElement);
        effect(() => {
            const size = this._elementSize();
            if (!size)
                return;
            this._autocomplete.updateInputWidth(size.width);
            this._brnOverlay?.updatePosition();
        });
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteAnchor, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnAutocompleteAnchor, isStandalone: true, selector: "[brnAutocompleteAnchor]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteAnchor, decorators: [{
            type: Directive,
            args: [{ selector: '[brnAutocompleteAnchor]' }]
        }], ctorParameters: () => [] });

class BrnAutocompleteClear {
    _autocomplete = injectBrnAutocompleteBase();
    _renderer = inject(Renderer2);
    _templateRef = inject(TemplateRef);
    _viewContainerRef = inject(ViewContainerRef);
    /** Determine if the autocomplete has a value or search text */
    _shouldShowClear = computed(() => {
        const value = this._autocomplete.value();
        return (value !== null && value !== undefined) || this._autocomplete.search() !== '';
    }, ...(ngDevMode ? [{ debugName: "_shouldShowClear" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            this._viewContainerRef.clear();
            if (this._shouldShowClear()) {
                const view = this._viewContainerRef.createEmbeddedView(this._templateRef);
                view.rootNodes.forEach((node) => {
                    this._renderer.listen(node, 'click', (e) => {
                        e.preventDefault();
                        this.clear();
                    });
                });
            }
        });
    }
    clear() {
        this._autocomplete.resetValue();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteClear, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnAutocompleteClear, isStandalone: true, selector: "[brnAutocompleteClear]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteClear, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocompleteClear]',
                }]
        }], ctorParameters: () => [] });

class BrnAutocompleteContent {
    _autocomplete = injectBrnAutocompleteBase();
    /** Determine if the autocomplete has any visible items */
    _visibleItems = this._autocomplete.visibleItems;
    _autocompleteWidth = this._autocomplete.searchInputWrapperWidth;
    _dataState = computed(() => this._autocomplete.isExpanded() ? 'open' : 'closed', ...(ngDevMode ? [{ debugName: "_dataState" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnAutocompleteContent, isStandalone: true, selector: "[brnAutocompleteContent]", host: { properties: { "attr.data-state": "_dataState()", "attr.data-empty": "!_visibleItems() ? \"\" : null", "style.--brn-autocomplete-width.px": "_autocompleteWidth()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocompleteContent]',
                    host: {
                        '[attr.data-state]': '_dataState()',
                        '[attr.data-empty]': '!_visibleItems() ? "" : null',
                        '[style.--brn-autocomplete-width.px]': '_autocompleteWidth()',
                    },
                }]
        }] });

class BrnAutocompleteEmpty {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteEmpty, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnAutocompleteEmpty, isStandalone: true, selector: "[brnAutocompleteEmpty]", host: { attributes: { "role": "status", "aria-live": "polite", "aria-atomic": "true" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteEmpty, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocompleteEmpty]',
                    host: {
                        role: 'status',
                        'aria-live': 'polite',
                        'aria-atomic': 'true',
                    },
                }]
        }] });

class BrnAutocompleteLabel {
    static _id = 0;
    /** The id of the autocomplete label */
    id = input(`brn-autocomplete-label-${++BrnAutocompleteLabel._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteLabel, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnAutocompleteLabel, isStandalone: true, selector: "[brnAutocompleteLabel]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "id": "id()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteLabel, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocompleteLabel]',
                    host: {
                        '[id]': 'id()',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }] } });

class BrnAutocompleteGroup {
    /** Get the items in the group */
    _items = contentChildren(BrnAutocompleteItemToken, { ...(ngDevMode ? { debugName: "_items" } : /* istanbul ignore next */ {}), descendants: true });
    /** Determine if there are any visible items in the group */
    _visible = computed(() => this._items().length > 0, ...(ngDevMode ? [{ debugName: "_visible" }] : /* istanbul ignore next */ []));
    /** Get the label associated with the group */
    _label = contentChild(BrnAutocompleteLabel, ...(ngDevMode ? [{ debugName: "_label" }] : /* istanbul ignore next */ []));
    _labelledBy = computed(() => {
        const label = this._label();
        return label ? label.id() : null;
    }, ...(ngDevMode ? [{ debugName: "_labelledBy" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteGroup, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnAutocompleteGroup, isStandalone: true, selector: "[brnAutocompleteGroup]", host: { attributes: { "role": "group" }, properties: { "attr.data-hidden": "!_visible() ? \"\" : null", "attr.aria-labelledby": "_labelledBy()" } }, queries: [{ propertyName: "_items", predicate: BrnAutocompleteItemToken, descendants: true, isSignal: true }, { propertyName: "_label", first: true, predicate: BrnAutocompleteLabel, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteGroup, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocompleteGroup]',
                    host: {
                        role: 'group',
                        '[attr.data-hidden]': '!_visible() ? "" : null',
                        '[attr.aria-labelledby]': '_labelledBy()',
                    },
                }]
        }], propDecorators: { _items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => BrnAutocompleteItemToken), { ...{
                            descendants: true,
                        }, isSignal: true }] }], _label: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BrnAutocompleteLabel), { isSignal: true }] }] } });

class BrnAutocompleteInput {
    static _id = 0;
    _el = inject(ElementRef);
    _autocomplete = injectBrnAutocompleteBase();
    /** The id of the autocomplete input */
    id = input(`brn-autocomplete-input-${++BrnAutocompleteInput._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** Manual override for aria-invalid. When not set, auto-detects from the parent autocomplete error state. */
    ariaInvalidOverride = input(undefined, { ...(ngDevMode ? { debugName: "ariaInvalidOverride" } : /* istanbul ignore next */ {}), transform: (v) => (v === '' || v === undefined ? undefined : booleanAttribute(v)),
        alias: 'aria-invalid' });
    /** Forces the invalid state visually, regardless of form control state. */
    forceInvalid = input(false, { ...(ngDevMode ? { debugName: "forceInvalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = this._autocomplete.disabledState;
    /** Whether the autocomplete panel is expanded */
    _isExpanded = this._autocomplete.isExpanded;
    /** Computed aria-invalid: uses manual override if provided, otherwise reads from parent error state. */
    _ariaInvalid = computed(() => this.ariaInvalidOverride() ?? this._autocomplete.controlState?.()?.invalid, ...(ngDevMode ? [{ debugName: "_ariaInvalid" }] : /* istanbul ignore next */ []));
    _spartanInvalid = computed(() => this.forceInvalid() || this._autocomplete.controlState?.()?.spartanInvalid, ...(ngDevMode ? [{ debugName: "_spartanInvalid" }] : /* istanbul ignore next */ []));
    _touched = computed(() => this._autocomplete.controlState?.()?.touched, ...(ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []));
    _dirty = computed(() => this._autocomplete.controlState?.()?.dirty, ...(ngDevMode ? [{ debugName: "_dirty" }] : /* istanbul ignore next */ []));
    constructor() {
        this._autocomplete.registerAutocompleteInput(this);
        effect(() => {
            const value = this._autocomplete.value();
            const valueLabel = stringifyAsLabel(value, this._autocomplete.itemToString());
            this._el.nativeElement.value = valueLabel ?? '';
        });
        effect(() => {
            const search = this._autocomplete.search();
            if (this._el.nativeElement.value !== search) {
                this._el.nativeElement.value = search;
            }
        });
    }
    onInput(event) {
        const value = event.target.value;
        this._autocomplete.updateSearch(value);
    }
    onKeyDown(event) {
        if (event.key === 'Enter') {
            // prevent form submission if inside a form
            event.preventDefault();
            this._autocomplete.selectActiveItem();
        }
        if (this._isExpanded()) {
            if (event.key === 'Tab') {
                this._autocomplete.selectActiveItem();
            }
        }
        else {
            if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
                this._autocomplete.open();
            }
            if (event.key === 'Escape') {
                this._autocomplete.resetValue();
            }
        }
        this._autocomplete.keyManager.onKeydown(event);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteInput, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnAutocompleteInput, isStandalone: true, selector: "input[brnAutocompleteInput]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaInvalidOverride: { classPropertyName: "ariaInvalidOverride", publicName: "aria-invalid", isSignal: true, isRequired: false, transformFunction: null }, forceInvalid: { classPropertyName: "forceInvalid", publicName: "forceInvalid", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "type": "text", "role": "combobox", "autocomplete": "off", "autocorrect": "off", "autocapitalize": "none", "spellcheck": "false", "aria-autocomplete": "list", "aria-haspopup": "listbox" }, listeners: { "keydown": "onKeyDown($event)", "input": "onInput($event)" }, properties: { "id": "id()", "attr.aria-expanded": "_isExpanded()", "attr.aria-invalid": "_ariaInvalid() ? \"true\": null", "attr.data-invalid": "_ariaInvalid() ? \"true\": null", "attr.data-matches-spartan-invalid": "_spartanInvalid() ? \"true\": null", "attr.data-touched": "_touched() ? \"true\": null", "attr.data-dirty": "_dirty() ? \"true\": null", "attr.disabled": "disabled() ? \"\" : null" } }, exportAs: ["brnAutocompleteInput"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteInput, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[brnAutocompleteInput]',
                    exportAs: 'brnAutocompleteInput',
                    host: {
                        '[id]': 'id()',
                        type: 'text',
                        role: 'combobox',
                        autocomplete: 'off',
                        autocorrect: 'off',
                        autocapitalize: 'none',
                        spellcheck: 'false',
                        'aria-autocomplete': 'list',
                        'aria-haspopup': 'listbox',
                        '[attr.aria-expanded]': '_isExpanded()',
                        '[attr.aria-invalid]': '_ariaInvalid() ? "true": null',
                        '[attr.data-invalid]': '_ariaInvalid() ? "true": null',
                        '[attr.data-matches-spartan-invalid]': '_spartanInvalid() ? "true": null',
                        '[attr.data-touched]': '_touched() ? "true": null',
                        '[attr.data-dirty]': '_dirty() ? "true": null',
                        '[attr.disabled]': 'disabled() ? "" : null',
                        '(keydown)': 'onKeyDown($event)',
                        '(input)': 'onInput($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaInvalidOverride: [{ type: i0.Input, args: [{ isSignal: true, alias: "aria-invalid", required: false }] }], forceInvalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceInvalid", required: false }] }] } });

class BrnAutocompleteItem {
    static _id = 0;
    _platform = inject(PLATFORM_ID);
    _elementRef = inject(ElementRef);
    /** Access the autocomplete component */
    _autocomplete = injectBrnAutocompleteBase();
    /** A unique id for the item */
    id = input(`brn-autocomplete-item-${++BrnAutocompleteItem._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** The value this item represents. */
    value = input.required(...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    // eslint-disable-next-line @typescript-eslint/naming-convention
    _disabled = input(false, { ...(ngDevMode ? { debugName: "_disabled" } : /* istanbul ignore next */ {}), alias: 'disabled',
        transform: booleanAttribute });
    /** Expose disabled as a value - used by the Highlightable interface */
    get disabled() {
        return this._disabled();
    }
    /** Whether the item is selected. */
    active = computed(() => this._autocomplete.isSelected(this.value()), ...(ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []));
    _highlighted = signal(false, ...(ngDevMode ? [{ debugName: "_highlighted" }] : /* istanbul ignore next */ []));
    setActiveStyles() {
        this._highlighted.set(true);
        // ensure the item is in view
        if (isPlatformBrowser(this._platform)) {
            this._elementRef.nativeElement.scrollIntoView({ block: 'nearest' });
        }
    }
    setInactiveStyles() {
        this._highlighted.set(false);
    }
    getLabel() {
        return stringifyAsLabel(this.value(), this._autocomplete.itemToString());
    }
    select() {
        if (this._disabled()) {
            return;
        }
        this._autocomplete.keyManager.setActiveItem(this);
        this._autocomplete.select(this.value());
    }
    activate() {
        if (this._disabled()) {
            return;
        }
        this._autocomplete.keyManager.setActiveItem(this);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteItem, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnAutocompleteItem, isStandalone: true, selector: "[brnAutocompleteItem]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, _disabled: { classPropertyName: "_disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "option" }, listeners: { "click": "select()", "mouseenter": "activate()" }, properties: { "id": "id()", "attr.data-highlighted": "_highlighted() ? \"\" : null", "attr.data-value": "value()", "attr.aria-selected": "active()", "attr.aria-disabled": "_disabled()", "attr.data-disabled": "_disabled() ? \"\" : null" } }, providers: [provideBrnAutocompleteItem(BrnAutocompleteItem)], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteItem, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocompleteItem]',
                    providers: [provideBrnAutocompleteItem(BrnAutocompleteItem)],
                    host: {
                        role: 'option',
                        '[id]': 'id()',
                        '[attr.data-highlighted]': '_highlighted() ? "" : null',
                        '[attr.data-value]': 'value()',
                        '[attr.aria-selected]': 'active()',
                        '[attr.aria-disabled]': '_disabled()',
                        '[attr.data-disabled]': '_disabled() ? "" : null',
                        '(click)': 'select()',
                        '(mouseenter)': 'activate()',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }], _disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });

class BrnAutocompleteList {
    static _id = 0;
    _autocomplete = injectBrnAutocompleteBase();
    /** Determine if the autocomplete has any visible items */
    _visibleItems = this._autocomplete.visibleItems;
    /** The id of the autocomplete list */
    id = input(`brn-autocomplete-list-${++BrnAutocompleteList._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteList, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnAutocompleteList, isStandalone: true, selector: "[brnAutocompleteList]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "listbox", "tabIndex": "-1", "aria-orientation": "vertical" }, properties: { "id": "id()", "attr.data-empty": "!_visibleItems() ? \"\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteList, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocompleteList]',
                    host: {
                        role: 'listbox',
                        tabIndex: '-1',
                        'aria-orientation': 'vertical',
                        '[id]': 'id()',
                        '[attr.data-empty]': '!_visibleItems() ? "" : null',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }] } });

const BRN_AUTOCOMPLETE_SEARCH_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => BrnAutocompleteSearch),
    multi: true,
};
class BrnAutocompleteSearch {
    _injector = inject(Injector);
    _fieldControl = inject(BrnFieldControl, { optional: true });
    _config = injectBrnAutocompleteConfig();
    /** Access the popover if present */
    _brnPopover = inject(BrnPopover, { optional: true });
    controlState = this._fieldControl?.controlState;
    /** Whether the autocomplete is disabled */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _disabled = linkedSignal(this.disabled, ...(ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []));
    /** @internal The disabled state as a readonly signal */
    disabledState = this._disabled.asReadonly();
    /** A function to convert an item to a string for display. */
    itemToString = input(this._config.itemToString, ...(ngDevMode ? [{ debugName: "itemToString" }] : /* istanbul ignore next */ []));
    /** Whether to auto-highlight the first matching item. */
    autoHighlight = input(this._config.autoHighlight, { ...(ngDevMode ? { debugName: "autoHighlight" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** The selected value of the autocomplete. */
    value = model(null, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /** The current search query. */
    search = model('', ...(ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []));
    _inputWidth = signal(null, ...(ngDevMode ? [{ debugName: "_inputWidth" }] : /* istanbul ignore next */ []));
    /** @internal The width of the search input wrapper */
    searchInputWrapperWidth = this._inputWidth.asReadonly();
    /** @internal Access all the items within the autocomplete */
    items = contentChildren(BrnAutocompleteItemToken, { ...(ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {}), descendants: true });
    /** Determine if the autocomplete has any visible items */
    visibleItems = computed(() => this.items().length > 0, ...(ngDevMode ? [{ debugName: "visibleItems" }] : /* istanbul ignore next */ []));
    /** @internal The key manager for managing active descendant */
    keyManager = new ActiveDescendantKeyManager(this.items, this._injector);
    /** @internal Whether the autocomplete is expanded */
    isExpanded = computed(() => this._brnPopover?.stateComputed() === 'open', ...(ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []));
    _autocompleteInput = signal(undefined, ...(ngDevMode ? [{ debugName: "_autocompleteInput" }] : /* istanbul ignore next */ []));
    _onChange;
    _onTouched;
    labelableId = computed(() => this._autocompleteInput()?.id(), ...(ngDevMode ? [{ debugName: "labelableId" }] : /* istanbul ignore next */ []));
    constructor() {
        this.keyManager
            .withVerticalOrientation()
            .withHomeAndEnd()
            .withWrap()
            .skipPredicate((item) => item.disabled);
        this._brnPopover?.closed.subscribe(() => {
            this.keyManager.setActiveItem(-1);
        });
        afterNextRender(() => {
            effect(() => {
                if (!this.autoHighlight() || !this.isExpanded() || !this.search())
                    return;
                const hasVisibleItems = this.visibleItems();
                untracked(() => {
                    if (hasVisibleItems) {
                        this.keyManager.setFirstItemActive();
                    }
                    else {
                        this.keyManager.setActiveItem(-1);
                    }
                });
            }, { injector: this._injector });
        });
    }
    registerAutocompleteInput(input) {
        return this._autocompleteInput.set(input);
    }
    updateInputWidth(width) {
        this._inputWidth.set(width);
    }
    updateSearch(value) {
        this.value.set(value);
        this.search.set(value);
        this._onChange?.(value);
        this.open();
        if (value === '') {
            this.resetValue();
        }
    }
    isSelected(itemValue) {
        return stringifyAsLabel(itemValue, this.itemToString()) === this.value();
    }
    select(itemValue) {
        const label = stringifyAsLabel(itemValue, this.itemToString());
        this.value.set(label);
        this._onChange?.(label);
        this.search.set(label);
        this.close();
    }
    /** Select the active item with Enter key. */
    selectActiveItem() {
        if (!this.isExpanded())
            return;
        const value = this.keyManager.activeItem?.value();
        if (value) {
            this.select(value);
        }
        else {
            this.close();
        }
    }
    resetValue() {
        this.value.set(null);
        this.search.set('');
        this._onChange?.(null);
    }
    open() {
        if (this._disabled() || this.isExpanded())
            return;
        this._brnPopover?.open();
    }
    close() {
        if (this._disabled() || !this.isExpanded())
            return;
        this._brnPopover?.close();
    }
    toggle() {
        if (this._disabled())
            return;
        this.isExpanded() ? this.close() : this.open();
    }
    /** CONTROL VALUE ACCESSOR */
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled.set(isDisabled);
    }
    _onFocusOut(event) {
        const currentTarget = event.currentTarget;
        const focusedEl = event.relatedTarget;
        if (!currentTarget.contains(focusedEl)) {
            this._onTouched?.();
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteSearch, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnAutocompleteSearch, isStandalone: true, selector: "[brnAutocomplete]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, itemToString: { classPropertyName: "itemToString", publicName: "itemToString", isSignal: true, isRequired: false, transformFunction: null }, autoHighlight: { classPropertyName: "autoHighlight", publicName: "autoHighlight", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, search: { classPropertyName: "search", publicName: "search", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", search: "searchChange" }, host: { listeners: { "focusout": "_onFocusOut($event)" } }, providers: [
            BRN_AUTOCOMPLETE_SEARCH_VALUE_ACCESSOR,
            provideBrnAutocompleteBase(BrnAutocompleteSearch),
            provideBrnLabelable(BrnAutocompleteSearch),
        ], queries: [{ propertyName: "items", predicate: BrnAutocompleteItemToken, descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.BrnFieldControl }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteSearch, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocomplete]',
                    providers: [
                        BRN_AUTOCOMPLETE_SEARCH_VALUE_ACCESSOR,
                        provideBrnAutocompleteBase(BrnAutocompleteSearch),
                        provideBrnLabelable(BrnAutocompleteSearch),
                    ],
                    hostDirectives: [BrnFieldControl],
                    host: {
                        '(focusout)': '_onFocusOut($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], itemToString: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemToString", required: false }] }], autoHighlight: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHighlight", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], search: [{ type: i0.Input, args: [{ isSignal: true, alias: "search", required: false }] }, { type: i0.Output, args: ["searchChange"] }], items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => BrnAutocompleteItemToken), { ...{
                            descendants: true,
                        }, isSignal: true }] }] } });

class BrnAutocompleteSeparator {
    orientation = input('horizontal', ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteSeparator, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnAutocompleteSeparator, isStandalone: true, selector: "[brnAutocompleteSeparator]", inputs: { orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "separator" }, properties: { "attr.aria-orientation": "orientation()", "attr.data-orientation": "orientation()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteSeparator, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocompleteSeparator]',
                    host: {
                        role: 'separator',
                        '[attr.aria-orientation]': 'orientation()',
                        '[attr.data-orientation]': 'orientation()',
                    },
                }]
        }], propDecorators: { orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }] } });

class BrnAutocompleteStatus {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteStatus, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnAutocompleteStatus, isStandalone: true, selector: "[brnAutocompleteStatus]", host: { attributes: { "role": "status", "aria-live": "polite", "aria-atomic": "true" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnAutocompleteStatus, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnAutocompleteStatus]',
                    host: {
                        role: 'status',
                        'aria-live': 'polite',
                        'aria-atomic': 'true',
                    },
                }]
        }] });

const BrnAutocompleteImports = [
    BrnAutocomplete,
    BrnAutocompleteAnchor,
    BrnAutocompleteClear,
    BrnAutocompleteContent,
    BrnAutocompleteEmpty,
    BrnAutocompleteGroup,
    BrnAutocompleteInput,
    BrnAutocompleteItem,
    BrnAutocompleteLabel,
    BrnAutocompleteList,
    BrnAutocompleteSearch,
    BrnAutocompleteSeparator,
    BrnAutocompleteStatus,
];

/**
 * Generated bundle index. Do not edit.
 */

export { BRN_AUTOCOMPLETE_CONTROL_VALUE_ACCESSOR, BRN_AUTOCOMPLETE_SEARCH_VALUE_ACCESSOR, BrnAutocomplete, BrnAutocompleteAnchor, BrnAutocompleteBaseToken, BrnAutocompleteClear, BrnAutocompleteContent, BrnAutocompleteEmpty, BrnAutocompleteGroup, BrnAutocompleteImports, BrnAutocompleteInput, BrnAutocompleteItem, BrnAutocompleteItemToken, BrnAutocompleteLabel, BrnAutocompleteList, BrnAutocompleteSearch, BrnAutocompleteSeparator, BrnAutocompleteStatus, injectBrnAutocompleteBase, injectBrnAutocompleteConfig, provideBrnAutocompleteBase, provideBrnAutocompleteConfig, provideBrnAutocompleteItem };
//# sourceMappingURL=spartan-ng-brain-autocomplete.mjs.map
