import * as i0 from '@angular/core';
import { inject, input, booleanAttribute, computed, Directive } from '@angular/core';
import * as i1 from '@spartan-ng/brain/field';
import { BrnFieldControl, provideBrnLabelable } from '@spartan-ng/brain/field';

class BrnTextarea {
    static _id = 0;
    _fieldControl = inject(BrnFieldControl, { optional: true });
    /** The id of the textarea. */
    id = input(`brn-textarea-${++BrnTextarea._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** Whether to force the textarea into an invalid state. */
    forceInvalid = input(false, { ...(ngDevMode ? { debugName: "forceInvalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    labelableId = this.id;
    _ariaInvalid = this._fieldControl?.invalid;
    _touched = this._fieldControl?.touched;
    _dirty = this._fieldControl?.dirty;
    _spartanInvalid = computed(() => this.forceInvalid() || this._fieldControl?.spartanInvalid(), ...(ngDevMode ? [{ debugName: "_spartanInvalid" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTextarea, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnTextarea, isStandalone: true, selector: "[brnTextarea]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, forceInvalid: { classPropertyName: "forceInvalid", publicName: "forceInvalid", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "id": "id()", "attr.aria-invalid": "_ariaInvalid?.() ? \"true\" : null", "attr.data-invalid": "_ariaInvalid?.() ? \"true\" : null", "attr.data-touched": "_touched?.() ? \"true\" : null", "attr.data-dirty": "_dirty?.() ? \"true\" : null", "attr.data-matches-spartan-invalid": "_spartanInvalid() ? \"true\" : null" } }, providers: [provideBrnLabelable(BrnTextarea)], hostDirectives: [{ directive: i1.BrnFieldControl }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTextarea, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnTextarea]',
                    providers: [provideBrnLabelable(BrnTextarea)],
                    hostDirectives: [BrnFieldControl],
                    host: {
                        '[id]': 'id()',
                        '[attr.aria-invalid]': '_ariaInvalid?.() ? "true" : null',
                        '[attr.data-invalid]': '_ariaInvalid?.() ? "true" : null',
                        '[attr.data-touched]': '_touched?.() ? "true" : null',
                        '[attr.data-dirty]': '_dirty?.() ? "true" : null',
                        '[attr.data-matches-spartan-invalid]': '_spartanInvalid() ? "true" : null',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], forceInvalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceInvalid", required: false }] }] } });

const BrnTextareaImports = [BrnTextarea];

/**
 * Generated bundle index. Do not edit.
 */

export { BrnTextarea, BrnTextareaImports };
//# sourceMappingURL=spartan-ng-brain-textarea.mjs.map
