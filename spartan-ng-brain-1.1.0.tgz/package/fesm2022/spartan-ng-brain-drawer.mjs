import * as i0 from '@angular/core';
import { input, linkedSignal, forwardRef, Directive, inject, ElementRef, DestroyRef, effect, untracked } from '@angular/core';
import * as i1 from '@spartan-ng/brain/dialog';
import { BrnDialog, BrnDialogClose, BrnDialogContent, BrnDialogDescription, BrnDialogRef, BrnDialogOverlay, BrnDialogTitle, BrnDialogTrigger } from '@spartan-ng/brain/dialog';
import { provideExposesStateProviderExisting, provideExposedSideProviderExisting, provideCustomClassSettableExisting } from '@spartan-ng/brain/core';
import { DOCUMENT } from '@angular/common';

class BrnDrawer extends BrnDialog {
    directionInput = input('bottom', { ...(ngDevMode ? { debugName: "directionInput" } : /* istanbul ignore next */ {}), alias: 'direction' });
    direction = linkedSignal(this.directionInput, ...(ngDevMode ? [{ debugName: "direction" }] : /* istanbul ignore next */ []));
    getPositionStrategy() {
        switch (this.direction()) {
            case 'bottom':
                return this._positionBuilder.global().bottom();
            case 'top':
                return this._positionBuilder.global().top();
            case 'left':
                return this._positionBuilder.global().left();
            case 'right':
                return this._positionBuilder.global().right();
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawer, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnDrawer, isStandalone: true, selector: "[brnDrawer],brn-drawer", inputs: { directionInput: { classPropertyName: "directionInput", publicName: "direction", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: BrnDialog,
                useExisting: forwardRef((() => BrnDrawer)),
            },
        ], exportAs: ["brnDrawer"], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawer, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDrawer],brn-drawer',
                    exportAs: 'brnDrawer',
                    providers: [
                        {
                            provide: BrnDialog,
                            useExisting: forwardRef((() => BrnDrawer)),
                        },
                    ],
                }]
        }], propDecorators: { directionInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "direction", required: false }] }] } });

class BrnDrawerClose extends BrnDialogClose {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerClose, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnDrawerClose, isStandalone: true, selector: "button[brnDrawerClose]", usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerClose, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnDrawerClose]',
                }]
        }] });

class BrnDrawerContent extends BrnDialogContent {
    side = inject(BrnDrawer).direction;
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerContent, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnDrawerContent, isStandalone: true, selector: "[brnDrawerContent]", providers: [
            provideExposesStateProviderExisting((() => BrnDrawerContent)),
            provideExposedSideProviderExisting((() => BrnDrawerContent)),
        ], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDrawerContent]',
                    providers: [
                        provideExposesStateProviderExisting((() => BrnDrawerContent)),
                        provideExposedSideProviderExisting((() => BrnDrawerContent)),
                    ],
                }]
        }] });

class BrnDrawerDescription {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerDescription, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnDrawerDescription, isStandalone: true, selector: "[brnDrawerDescription]", hostDirectives: [{ directive: i1.BrnDialogDescription }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerDescription, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDrawerDescription]',
                    hostDirectives: [BrnDialogDescription],
                }]
        }] });

const VELOCITY_THRESHOLD = 0.4;
const DEFAULT_CLOSE_THRESHOLD = 0.25;
const SCROLL_LOCK_TIMEOUT = 100;
const TOUCH_SWIPE_THRESHOLD = 10;
const MOUSE_SWIPE_THRESHOLD = 2;
const OPEN_TIME_COOLDOWN = 500;
const TRANSITION = 'transform 0.5s cubic-bezier(0.32, 0.72, 0, 1)';
const OVERLAY_TRANSITION = 'opacity 0.5s cubic-bezier(0.32, 0.72, 0, 1)';
function dampenValue(v) {
    return 8 * (Math.log(v + 1) - 2);
}
class BrnDrawerHandle {
    _brnDialogRef = inject(BrnDialogRef, { optional: true });
    _brnDrawer = inject(BrnDrawer, { optional: true });
    _element = inject(ElementRef);
    _document = inject(DOCUMENT);
    _destroyRef = inject(DestroyRef);
    _pointerId = -1;
    constructor() {
        this._destroyRef.onDestroy(() => {
            this._cleanup();
            // Cancel any pending reset timeout: on destroy its target elements are gone, so the
            // deferred style write is a stale no-op that also retains this directive for ~500ms.
            this._clearResetTimeout();
        });
        effect(() => {
            const state = this._brnDialogRef?.state();
            untracked(() => {
                if (state === 'open') {
                    this._openTime = Date.now();
                }
                else if (state === 'closed') {
                    this._openTime = null;
                }
            });
        });
    }
    _drawerEl = null;
    _backdropEl = null;
    _direction = 'bottom';
    _initialBackdropOpacity = 1;
    _pointerStartX = 0;
    _pointerStartY = 0;
    _pointerStart = 0;
    _pointerType = '';
    _isDragging = false;
    _isAllowedToDrag = false;
    _wasBeyondThreshold = false;
    _openTime = null;
    _lastTimeDragPrevented = null;
    _dragStartTime = null;
    _resetTimeout = null;
    closeThreshold = input(DEFAULT_CLOSE_THRESHOLD, ...(ngDevMode ? [{ debugName: "closeThreshold" }] : /* istanbul ignore next */ []));
    get _isVertical() {
        return this._direction === 'bottom' || this._direction === 'top';
    }
    get _isPositive() {
        return this._direction === 'bottom' || this._direction === 'right';
    }
    get _dimensionMultiplier() {
        return this._isPositive ? 1 : -1;
    }
    get _swipeThreshold() {
        return this._pointerType === 'touch' ? TOUCH_SWIPE_THRESHOLD : MOUSE_SWIPE_THRESHOLD;
    }
    _onPointerDown(event) {
        if (!this._brnDialogRef || !this._brnDrawer || this._isDragging)
            return;
        this._direction = this._brnDrawer.direction();
        this._drawerEl = this._element.nativeElement.closest('[data-vaul-drawer-direction]');
        if (!this._drawerEl)
            return;
        this._pointerType = event.pointerType;
        this._pointerStartX = event.pageX;
        this._pointerStartY = event.pageY;
        this._pointerStart = this._isVertical ? event.pageY : event.pageX;
        this._isDragging = true;
        this._isAllowedToDrag = false;
        this._wasBeyondThreshold = false;
        this._dragStartTime = Date.now();
        this._drawerEl.style.transition = 'none';
        if (!this._findScrollableAncestor(event.target)) {
            this._drawerEl.style.touchAction = 'none';
        }
        const overlayWrapper = this._drawerEl.closest('.cdk-global-overlay-wrapper');
        this._backdropEl = overlayWrapper?.querySelector('.cdk-overlay-backdrop');
        if (this._backdropEl) {
            this._initialBackdropOpacity = parseFloat(getComputedStyle(this._backdropEl).opacity) || 1;
        }
        this._pointerId = event.pointerId;
        this._document.addEventListener('pointermove', this._onPointerMove, { passive: false });
        this._document.addEventListener('pointerup', this._onPointerUp, { once: true });
        this._document.addEventListener('pointercancel', this._onPointerCancel, { once: true });
    }
    _onPointerMove = (e) => {
        if (!this._isDragging || !this._drawerEl)
            return;
        const currentX = e.pageX;
        const currentY = e.pageY;
        const xDelta = currentX - this._pointerStartX;
        const yDelta = currentY - this._pointerStartY;
        if (!this._wasBeyondThreshold) {
            const absX = Math.abs(xDelta);
            const absY = Math.abs(yDelta);
            if (this._isVertical) {
                if (absY < this._swipeThreshold) {
                    if (absX >= this._swipeThreshold) {
                        this._pointerStartX = currentX;
                        this._pointerStartY = currentY;
                    }
                    return;
                }
                if (absX > absY)
                    return;
            }
            else {
                if (absX < this._swipeThreshold) {
                    if (absY >= this._swipeThreshold) {
                        this._pointerStartX = currentX;
                        this._pointerStartY = currentY;
                    }
                    return;
                }
                if (absY > absX)
                    return;
            }
            this._wasBeyondThreshold = true;
        }
        const currentPosition = this._isVertical ? currentY : currentX;
        const draggedDistance = (this._pointerStart - currentPosition) * this._dimensionMultiplier;
        const isDraggingInDirection = draggedDistance > 0;
        const absDraggedDistance = Math.abs(draggedDistance);
        if (!this._isAllowedToDrag && !this._shouldDrag(e.target ?? this._element.nativeElement, isDraggingInDirection))
            return;
        this._isAllowedToDrag = true;
        try {
            this._element.nativeElement.setPointerCapture(e.pointerId);
        }
        catch {
            /* empty - pointer capture not supported */
        }
        this._drawerEl.classList.add('vaul-dragging');
        const dimension = this._isVertical ? this._drawerEl.offsetHeight : this._drawerEl.offsetWidth;
        const progress = dimension > 0 ? Math.min(absDraggedDistance / dimension, 1) : 0;
        if (isDraggingInDirection) {
            const dampened = dampenValue(draggedDistance);
            const translateValue = Math.min(dampened * -1, 0) * this._dimensionMultiplier;
            const prop = this._isVertical ? 'translateY' : 'translateX';
            this._drawerEl.style.transform = `${prop}(${translateValue}px)`;
            if (this._backdropEl) {
                this._backdropEl.style.opacity = String(Math.max(this._initialBackdropOpacity - progress * 0.3, 0));
            }
            return;
        }
        e.preventDefault();
        const translateValue = absDraggedDistance * this._dimensionMultiplier;
        const prop = this._isVertical ? 'translateY' : 'translateX';
        this._drawerEl.style.transform = `${prop}(${translateValue}px)`;
        if (this._backdropEl) {
            this._backdropEl.style.opacity = String(Math.max(this._initialBackdropOpacity - progress, 0));
        }
    };
    _onPointerUp = (e) => {
        if (!this._isDragging || !this._drawerEl) {
            this._cleanup();
            return;
        }
        this._drawerEl.classList.remove('vaul-dragging');
        const swipeAmount = this._getTranslate();
        if (!this._isAllowedToDrag || swipeAmount === null || Number.isNaN(swipeAmount)) {
            this._resetDrawer(true);
            this._cleanup();
            return;
        }
        const currentPosition = this._isVertical ? e.pageY : e.pageX;
        const distMoved = this._pointerStart - currentPosition;
        const timeTaken = Date.now() - (this._dragStartTime ?? Date.now());
        const velocity = timeTaken > 0 ? Math.abs(distMoved) / timeTaken : 0;
        if (this._isPositive ? distMoved > 0 : distMoved < 0) {
            this._resetDrawer(true);
            this._cleanup();
            return;
        }
        if (velocity > VELOCITY_THRESHOLD) {
            this._animateAndClose();
            this._cleanup();
            this._brnDialogRef?.close();
            return;
        }
        const dimension = this._isVertical ? this._drawerEl.offsetHeight : this._drawerEl.offsetWidth;
        if (Math.abs(swipeAmount) >= dimension * this.closeThreshold()) {
            this._animateAndClose();
            this._cleanup();
            this._brnDialogRef?.close();
            return;
        }
        this._resetDrawer(true);
        this._cleanup();
    };
    _onPointerCancel = () => {
        this._resetDrawer(true);
        this._cleanup();
    };
    _shouldDrag(el, isDraggingInDirection) {
        if (this._direction === 'left' || this._direction === 'right')
            return true;
        const now = Date.now();
        if (this._openTime !== null && now - this._openTime < OPEN_TIME_COOLDOWN)
            return false;
        const currentTranslate = this._getTranslate();
        if (this._isPositive ? currentTranslate > 0 : currentTranslate < 0)
            return true;
        if (this._lastTimeDragPrevented !== null &&
            now - this._lastTimeDragPrevented < SCROLL_LOCK_TIMEOUT &&
            currentTranslate === 0) {
            this._lastTimeDragPrevented = now;
            return false;
        }
        if (isDraggingInDirection) {
            this._lastTimeDragPrevented = now;
            return false;
        }
        let element = el;
        while (element) {
            if (element.scrollHeight > element.clientHeight) {
                if (element.scrollTop !== 0) {
                    this._lastTimeDragPrevented = now;
                    return false;
                }
                if (element.getAttribute('role') === 'dialog')
                    return true;
            }
            element = element.parentElement;
        }
        return true;
    }
    _getTranslate() {
        if (!this._drawerEl)
            return 0;
        const style = getComputedStyle(this._drawerEl);
        const transform = style.transform || style.webkitTransform;
        if (!transform || transform === 'none')
            return 0;
        let mat = transform.match(/^matrix3d\((.+)\)$/);
        if (mat) {
            return parseFloat(mat[1].split(', ')[this._isVertical ? 13 : 12]);
        }
        mat = transform.match(/^matrix\((.+)\)$/);
        if (mat) {
            return parseFloat(mat[1].split(', ')[this._isVertical ? 5 : 4]);
        }
        return 0;
    }
    _resetDrawer(animate = true) {
        if (this._drawerEl) {
            this._drawerEl.style.transition = animate ? TRANSITION : 'none';
            this._drawerEl.style.transform = '';
        }
        if (this._backdropEl) {
            this._backdropEl.style.transition = animate ? OVERLAY_TRANSITION : 'none';
            this._backdropEl.style.opacity = String(this._initialBackdropOpacity);
        }
        this._clearResetTimeout();
        this._resetTimeout = setTimeout(() => {
            this._resetTimeout = null;
            if (this._drawerEl)
                this._drawerEl.style.transition = '';
            if (this._backdropEl)
                this._backdropEl.style.transition = '';
        }, 500);
    }
    _clearResetTimeout() {
        if (this._resetTimeout !== null) {
            clearTimeout(this._resetTimeout);
            this._resetTimeout = null;
        }
    }
    _animateAndClose() {
        if (!this._drawerEl)
            return;
        const dimension = this._isVertical ? this._drawerEl.offsetHeight : this._drawerEl.offsetWidth;
        const targetClose = this._isPositive ? dimension : -dimension;
        const prop = this._isVertical ? 'translateY' : 'translateX';
        this._drawerEl.style.transition = 'transform 0.3s cubic-bezier(0.32, 0.72, 0, 1)';
        this._drawerEl.style.transform = `${prop}(${targetClose}px)`;
        this._drawerEl.style.animation = 'none';
        if (this._backdropEl) {
            this._backdropEl.style.transition = 'opacity 0.3s cubic-bezier(0.32, 0.72, 0, 1)';
            this._backdropEl.style.opacity = '0';
        }
    }
    _cleanup() {
        this._isDragging = false;
        this._isAllowedToDrag = false;
        if (this._drawerEl) {
            this._drawerEl.style.touchAction = '';
        }
        if (this._pointerId !== -1) {
            try {
                this._element.nativeElement.releasePointerCapture(this._pointerId);
            }
            catch {
                /* empty */
            }
            this._pointerId = -1;
        }
        this._document.removeEventListener('pointermove', this._onPointerMove);
        // pointerup/pointercancel are registered with `{ once: true }`, but a destroy-during-drag (or a
        // normal end where pointercancel never fired) would otherwise leave them on `document`, pinning
        // this directive until the next global pointer release auto-removes them.
        this._document.removeEventListener('pointerup', this._onPointerUp);
        this._document.removeEventListener('pointercancel', this._onPointerCancel);
    }
    _findScrollableAncestor(element) {
        if (!element)
            return null;
        const scrollProp = this._isVertical ? 'overflow-y' : 'overflow-x';
        const sizeProp = this._isVertical ? 'scrollHeight' : 'scrollWidth';
        const clientProp = this._isVertical ? 'clientHeight' : 'clientWidth';
        let el = element.parentElement;
        while (el) {
            const overflow = getComputedStyle(el)[scrollProp];
            if ((overflow === 'auto' || overflow === 'scroll') && el[sizeProp] > el[clientProp]) {
                return el;
            }
            el = el.parentElement;
        }
        return null;
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerHandle, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnDrawerHandle, isStandalone: true, selector: "[brnDrawerHandle]", inputs: { closeThreshold: { classPropertyName: "closeThreshold", publicName: "closeThreshold", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "presentation" }, listeners: { "pointerdown": "_onPointerDown($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerHandle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDrawerHandle]',
                    host: {
                        role: 'presentation',
                        '(pointerdown)': '_onPointerDown($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { closeThreshold: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeThreshold", required: false }] }] } });

class BrnDrawerOverlay extends BrnDialogOverlay {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerOverlay, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnDrawerOverlay, isStandalone: true, selector: "[brnDrawerOverlay],brn-drawer-overlay", providers: [provideCustomClassSettableExisting((() => BrnDrawerOverlay))], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerOverlay, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDrawerOverlay],brn-drawer-overlay',
                    providers: [provideCustomClassSettableExisting((() => BrnDrawerOverlay))],
                }]
        }] });

class BrnDrawerTitle {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerTitle, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnDrawerTitle, isStandalone: true, selector: "[brnDrawerTitle]", hostDirectives: [{ directive: i1.BrnDialogTitle }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerTitle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDrawerTitle]',
                    hostDirectives: [BrnDialogTitle],
                }]
        }] });

class BrnDrawerTrigger extends BrnDialogTrigger {
    _drawer = inject(BrnDrawer, { optional: true });
    direction = input(undefined, ...(ngDevMode ? [{ debugName: "direction" }] : /* istanbul ignore next */ []));
    open() {
        const direction = this.direction();
        if (this._drawer && direction) {
            this._drawer.direction.set(direction);
        }
        super.open();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerTrigger, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnDrawerTrigger, isStandalone: true, selector: "button[brnDrawerTrigger]", inputs: { direction: { classPropertyName: "direction", publicName: "direction", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDrawerTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnDrawerTrigger]',
                }]
        }], propDecorators: { direction: [{ type: i0.Input, args: [{ isSignal: true, alias: "direction", required: false }] }] } });

const BrnDrawerImports = [
    BrnDrawer,
    BrnDrawerOverlay,
    BrnDrawerTrigger,
    BrnDrawerClose,
    BrnDrawerContent,
    BrnDrawerTitle,
    BrnDrawerDescription,
    BrnDrawerHandle,
];

/**
 * Generated bundle index. Do not edit.
 */

export { BrnDrawer, BrnDrawerClose, BrnDrawerContent, BrnDrawerDescription, BrnDrawerHandle, BrnDrawerImports, BrnDrawerOverlay, BrnDrawerTitle, BrnDrawerTrigger };
//# sourceMappingURL=spartan-ng-brain-drawer.mjs.map
