import { ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import * as i0 from '@angular/core';
import { InjectionToken, inject, forwardRef, Injector, input, booleanAttribute, linkedSignal, model, computed, signal, contentChildren, afterNextRender, effect, untracked, Directive, ElementRef, contentChild, PLATFORM_ID, DestroyRef, TemplateRef, ViewContainerRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from '@spartan-ng/brain/field';
import { BrnFieldControl, provideBrnLabelable } from '@spartan-ng/brain/field';
import { BrnPopover } from '@spartan-ng/brain/popover';
import { isPlatformBrowser } from '@angular/common';
import { stringifyAsLabel, injectElementSize } from '@spartan-ng/brain/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subject, fromEvent, interval } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { BrnOverlay } from '@spartan-ng/brain/overlay';

const BrnSelectItemToken = new InjectionToken('BrnSelectItemToken');
function provideBrnSelectItem(selectItem) {
    return { provide: BrnSelectItemToken, useExisting: selectItem };
}

const BrnSelectBaseToken = new InjectionToken('BrnSelectBaseToken');
function provideBrnSelectBase(instance) {
    return { provide: BrnSelectBaseToken, useExisting: instance };
}
/**
 * Inject the select component.
 */
function injectBrnSelectBase() {
    return inject(BrnSelectBaseToken);
}
function getDefaultConfig() {
    return {
        isItemEqualToValue: (itemValue, selectedValue) => Object.is(itemValue, selectedValue),
        isSingleValuePresent: (value) => value !== undefined && value !== null && value !== '',
        itemToString: undefined,
    };
}
const BrnSelectConfigToken = new InjectionToken('BrnSelectConfig');
function provideBrnSelectConfig(config) {
    return { provide: BrnSelectConfigToken, useValue: { ...getDefaultConfig(), ...config } };
}
function injectBrnSelectConfig() {
    const injectedConfig = inject(BrnSelectConfigToken, { optional: true });
    return injectedConfig ? injectedConfig : getDefaultConfig();
}

const BRN_SELECT_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => BrnSelect),
    multi: true,
};
class BrnSelect {
    _injector = inject(Injector);
    _fieldControl = inject(BrnFieldControl, { optional: true });
    _config = injectBrnSelectConfig();
    controlState = this._fieldControl?.controlState;
    /** Access the popover if present */
    _brnPopover = inject(BrnPopover, { optional: true });
    /** Whether the select is disabled */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _disabled = linkedSignal(this.disabled, ...(ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []));
    /** @internal The disabled state as a readonly signal */
    disabledState = this._disabled.asReadonly();
    /** The selected value of the select. */
    value = model(null, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /**
     * Determines whether a single value is present (i.e., has been selected).
     * Considers `undefined`, `null`, and empty string as "not present".
     * Only used by single select, ignored by the multiple select variant.
     */
    isSingleValuePresent = input(this._config.isSingleValuePresent, ...(ngDevMode ? [{ debugName: "isSingleValuePresent" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.isSingleValuePresent()(this.value()), ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    /** A function to compare an item with the selected value. */
    isItemEqualToValue = input(this._config.isItemEqualToValue, ...(ngDevMode ? [{ debugName: "isItemEqualToValue" }] : /* istanbul ignore next */ []));
    /** A function to convert an item to a string for display. */
    itemToString = input(this._config.itemToString, ...(ngDevMode ? [{ debugName: "itemToString" }] : /* istanbul ignore next */ []));
    _triggerWidth = signal(null, ...(ngDevMode ? [{ debugName: "_triggerWidth" }] : /* istanbul ignore next */ []));
    /** @internal The width of the trigger wrapper */
    triggerWidth = this._triggerWidth.asReadonly();
    /** @internal Access all the items within the select */
    items = contentChildren(BrnSelectItemToken, { ...(ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {}), descendants: true });
    /** @internal The key manager for managing active descendant */
    keyManager = new ActiveDescendantKeyManager(this.items, this._injector);
    /** @internal Whether the select is expanded */
    isExpanded = computed(() => this._brnPopover?.stateComputed() === 'open', ...(ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []));
    _selectTrigger = signal(undefined, ...(ngDevMode ? [{ debugName: "_selectTrigger" }] : /* istanbul ignore next */ []));
    labelableId = computed(() => this._selectTrigger()?.id(), ...(ngDevMode ? [{ debugName: "labelableId" }] : /* istanbul ignore next */ []));
    _onChange;
    _onTouched;
    constructor() {
        this.keyManager
            .withVerticalOrientation()
            .withHomeAndEnd()
            .withTypeAhead()
            .withWrap()
            .skipPredicate((item) => item.disabled);
        this._brnPopover?.closed.subscribe(() => {
            this._onTouched?.();
            this.keyManager.setActiveItem(-1);
        });
        afterNextRender(() => {
            effect(() => {
                if (!this.isExpanded())
                    return;
                const items = this.items();
                const value = this.value();
                untracked(() => {
                    const index = value !== null && value !== undefined
                        ? items.findIndex((item) => this.isItemEqualToValue()(item.value(), value))
                        : -1;
                    if (index !== -1) {
                        this.keyManager.setActiveItem(index);
                    }
                    else if (items.length > 0) {
                        this.keyManager.setFirstItemActive();
                    }
                    else {
                        this.keyManager.setActiveItem(-1);
                    }
                });
            }, { injector: this._injector });
        });
    }
    registerSelectTrigger(input) {
        return this._selectTrigger.set(input);
    }
    updateTriggerWidth(width) {
        this._triggerWidth.set(width);
    }
    isSelected(itemValue) {
        return this.isItemEqualToValue()(itemValue, this.value());
    }
    select(itemValue) {
        this.value.set(itemValue);
        this._onChange?.(itemValue);
        this.close();
    }
    /** Select the active item with Enter key. */
    selectActiveItem() {
        if (!this.isExpanded())
            return;
        const value = this.keyManager.activeItem?.value();
        if (value !== null && value !== undefined) {
            this.select(value);
        }
        else {
            this.close();
        }
    }
    open() {
        if (this._disabled() || this.isExpanded())
            return;
        this._brnPopover?.open();
    }
    close() {
        if (this._disabled() || !this.isExpanded())
            return;
        this._brnPopover?.close();
    }
    toggle() {
        this.isExpanded() ? this.close() : this.open();
    }
    /** CONTROL VALUE ACCESSOR */
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled.set(isDisabled);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelect, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnSelect, isStandalone: true, selector: "[brnSelect]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, isSingleValuePresent: { classPropertyName: "isSingleValuePresent", publicName: "isSingleValuePresent", isSignal: true, isRequired: false, transformFunction: null }, isItemEqualToValue: { classPropertyName: "isItemEqualToValue", publicName: "isItemEqualToValue", isSignal: true, isRequired: false, transformFunction: null }, itemToString: { classPropertyName: "itemToString", publicName: "itemToString", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, providers: [provideBrnSelectBase(BrnSelect), BRN_SELECT_VALUE_ACCESSOR, provideBrnLabelable(BrnSelect)], queries: [{ propertyName: "items", predicate: BrnSelectItemToken, descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.BrnFieldControl }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelect, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelect]',
                    providers: [provideBrnSelectBase(BrnSelect), BRN_SELECT_VALUE_ACCESSOR, provideBrnLabelable(BrnSelect)],
                    hostDirectives: [BrnFieldControl],
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], isSingleValuePresent: [{ type: i0.Input, args: [{ isSignal: true, alias: "isSingleValuePresent", required: false }] }], isItemEqualToValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "isItemEqualToValue", required: false }] }], itemToString: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemToString", required: false }] }], items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => BrnSelectItemToken), { ...{
                            descendants: true,
                        }, isSignal: true }] }] } });

// We use 8px and 15ms to create a smooth scrolling effect.
// 15ms is slightly faster than 60fps (16.6ms), ensuring a smooth animation loop.
const SCROLLBY_PIXEL = 8;
class BrnSelectContent {
    _select = injectBrnSelectBase();
    _selectWidth = this._select.triggerWidth;
    _elementRef = inject((ElementRef));
    _scrollUp = signal(false, ...(ngDevMode ? [{ debugName: "_scrollUp" }] : /* istanbul ignore next */ []));
    showScrollUp = this._scrollUp.asReadonly();
    _scrollDown = signal(false, ...(ngDevMode ? [{ debugName: "_scrollDown" }] : /* istanbul ignore next */ []));
    showScrollDown = this._scrollDown.asReadonly();
    _dataState = computed(() => (this._select.isExpanded() ? 'open' : 'closed'), ...(ngDevMode ? [{ debugName: "_dataState" }] : /* istanbul ignore next */ []));
    constructor() {
        afterNextRender(() => {
            this._checkScroll();
        });
    }
    handleScroll() {
        this._checkScroll();
    }
    _checkScroll() {
        const { scrollTop, scrollHeight, clientHeight } = this._elementRef.nativeElement;
        this._scrollUp.set(scrollTop > 0);
        const maxScroll = scrollHeight - clientHeight;
        this._scrollDown.set(Math.ceil(scrollTop) < maxScroll);
    }
    scrollDown(stop) {
        this._elementRef.nativeElement.scrollBy({
            top: SCROLLBY_PIXEL,
            behavior: 'auto',
        });
        const { scrollTop, scrollHeight, clientHeight } = this._elementRef.nativeElement;
        const maxScroll = scrollHeight - clientHeight;
        if (Math.ceil(scrollTop) >= maxScroll) {
            stop();
        }
    }
    scrollUp(stop) {
        this._elementRef.nativeElement.scrollBy({
            top: -SCROLLBY_PIXEL,
            behavior: 'auto',
        });
        if (this._elementRef.nativeElement.scrollTop === 0) {
            stop();
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnSelectContent, isStandalone: true, selector: "[brnSelectContent]", host: { listeners: { "scroll": "handleScroll()" }, properties: { "attr.data-state": "_dataState()", "style.--brn-select-width.px": "_selectWidth()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectContent]',
                    host: {
                        '[attr.data-state]': '_dataState()',
                        '[style.--brn-select-width.px]': '_selectWidth()',
                        '(scroll)': 'handleScroll()',
                    },
                }]
        }], ctorParameters: () => [] });

class BrnSelectLabel {
    static _id = 0;
    id = input(`brn-select-label-${++BrnSelectLabel._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectLabel, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnSelectLabel, isStandalone: true, selector: "[brnSelectLabel]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "id": "id()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectLabel, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectLabel]',
                    host: {
                        '[id]': 'id()',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }] } });

class BrnSelectGroup {
    _selectLabel = contentChild(BrnSelectLabel, ...(ngDevMode ? [{ debugName: "_selectLabel" }] : /* istanbul ignore next */ []));
    _labelledby = computed(() => this._selectLabel()?.id() ?? null, ...(ngDevMode ? [{ debugName: "_labelledby" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectGroup, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnSelectGroup, isStandalone: true, selector: "[brnSelectGroup]", host: { attributes: { "role": "group" }, properties: { "attr.aria-labelledby": "_labelledby()" } }, queries: [{ propertyName: "_selectLabel", first: true, predicate: BrnSelectLabel, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectGroup, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectGroup]',
                    host: {
                        role: 'group',
                        '[attr.aria-labelledby]': '_labelledby()',
                    },
                }]
        }], propDecorators: { _selectLabel: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BrnSelectLabel), { isSignal: true }] }] } });

class BrnSelectItem {
    static _id = 0;
    _platform = inject(PLATFORM_ID);
    _elementRef = inject(ElementRef);
    /** Access the select component */
    _select = injectBrnSelectBase();
    /** A unique id for the item */
    id = input(`brn-select-item-${++BrnSelectItem._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** The value this item represents. */
    value = input.required(...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    // eslint-disable-next-line @typescript-eslint/naming-convention
    _disabled = input(false, { ...(ngDevMode ? { debugName: "_disabled" } : /* istanbul ignore next */ {}), alias: 'disabled',
        transform: booleanAttribute });
    /** Expose disabled as a value - used by the Highlightable interface */
    get disabled() {
        return this._disabled();
    }
    /** Whether the item is selected. */
    active = computed(() => this._select.isSelected(this.value()), ...(ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []));
    _highlighted = signal(false, ...(ngDevMode ? [{ debugName: "_highlighted" }] : /* istanbul ignore next */ []));
    setActiveStyles() {
        this._highlighted.set(true);
        // ensure the item is in view
        if (isPlatformBrowser(this._platform)) {
            this._elementRef.nativeElement.scrollIntoView({ block: 'nearest' });
        }
    }
    setInactiveStyles() {
        this._highlighted.set(false);
    }
    getLabel() {
        return stringifyAsLabel(this.value(), this._select.itemToString());
    }
    select() {
        if (this._disabled()) {
            return;
        }
        this._select.keyManager.setActiveItem(this);
        this._select.select(this.value());
    }
    activate() {
        if (this._disabled()) {
            return;
        }
        this._select.keyManager.setActiveItem(this);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectItem, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnSelectItem, isStandalone: true, selector: "[brnSelectItem]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, _disabled: { classPropertyName: "_disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "option" }, listeners: { "click": "select()", "mouseenter": "activate()" }, properties: { "id": "id()", "attr.data-highlighted": "_highlighted() ? \"\" : null", "attr.data-value": "value()", "attr.aria-selected": "active()", "attr.aria-disabled": "_disabled()", "attr.data-disabled": "_disabled() ? \"\" : null" } }, providers: [provideBrnSelectItem(BrnSelectItem)], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectItem, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectItem]',
                    providers: [provideBrnSelectItem(BrnSelectItem)],
                    host: {
                        role: 'option',
                        '[id]': 'id()',
                        '[attr.data-highlighted]': '_highlighted() ? "" : null',
                        '[attr.data-value]': 'value()',
                        '[attr.aria-selected]': 'active()',
                        '[attr.aria-disabled]': '_disabled()',
                        '[attr.data-disabled]': '_disabled() ? "" : null',
                        '(click)': 'select()',
                        '(mouseenter)': 'activate()',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }], _disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });

class BrnSelectList {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectList, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnSelectList, isStandalone: true, selector: "[brnSelectList]", host: { attributes: { "role": "listbox" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectList, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectList]',
                    host: {
                        role: 'listbox',
                    },
                }]
        }] });

const BRN_SELECT_MULTIPLE_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => BrnSelectMultiple),
    multi: true,
};
class BrnSelectMultiple {
    _injector = inject(Injector);
    _fieldControl = inject(BrnFieldControl, { optional: true });
    _config = injectBrnSelectConfig();
    controlState = this._fieldControl?.controlState;
    /** Access the popover if present */
    _brnPopover = inject(BrnPopover, { optional: true });
    /** Whether the combobox is disabled */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _disabled = linkedSignal(this.disabled, ...(ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []));
    /** @internal The disabled state as a readonly signal */
    disabledState = this._disabled.asReadonly();
    /** The selected value of the select. */
    value = model(null, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => {
        const value = this.value();
        if (value === null || value === undefined)
            return false;
        return value.length > 0;
    }, ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    /** A function to compare an item with the selected value. */
    isItemEqualToValue = input(this._config.isItemEqualToValue, ...(ngDevMode ? [{ debugName: "isItemEqualToValue" }] : /* istanbul ignore next */ []));
    /** A function to convert an item to a string for display. */
    itemToString = input(this._config.itemToString, ...(ngDevMode ? [{ debugName: "itemToString" }] : /* istanbul ignore next */ []));
    _triggerWidth = signal(null, ...(ngDevMode ? [{ debugName: "_triggerWidth" }] : /* istanbul ignore next */ []));
    /** @internal The width of the trigger wrapper */
    triggerWidth = this._triggerWidth.asReadonly();
    /** @internal Access all the items within the select */
    items = contentChildren(BrnSelectItemToken, { ...(ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {}), descendants: true });
    /** @internal The key manager for managing active descendant */
    keyManager = new ActiveDescendantKeyManager(this.items, this._injector);
    /** @internal Whether the select is expanded */
    isExpanded = computed(() => this._brnPopover?.stateComputed() === 'open', ...(ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []));
    _selectTrigger = signal(undefined, ...(ngDevMode ? [{ debugName: "_selectTrigger" }] : /* istanbul ignore next */ []));
    labelableId = computed(() => this._selectTrigger()?.id(), ...(ngDevMode ? [{ debugName: "labelableId" }] : /* istanbul ignore next */ []));
    _onChange;
    _onTouched;
    constructor() {
        this.keyManager
            .withVerticalOrientation()
            .withHomeAndEnd()
            .withTypeAhead()
            .withWrap()
            .skipPredicate((item) => item.disabled);
        this._brnPopover?.closed.subscribe(() => {
            this._onTouched?.();
            this.keyManager.setActiveItem(-1);
        });
        afterNextRender(() => {
            effect(() => {
                if (!this.isExpanded())
                    return;
                const items = this.items();
                const values = this.value();
                const lastValue = values ? values[values.length - 1] : null;
                untracked(() => {
                    const index = lastValue !== null && lastValue !== undefined
                        ? items.findIndex((item) => this.isItemEqualToValue()(item.value(), lastValue))
                        : -1;
                    if (index !== -1) {
                        this.keyManager.setActiveItem(index);
                    }
                    else if (items.length > 0) {
                        this.keyManager.setFirstItemActive();
                    }
                    else {
                        this.keyManager.setActiveItem(-1);
                    }
                });
            }, { injector: this._injector });
        });
    }
    registerSelectTrigger(input) {
        return this._selectTrigger.set(input);
    }
    updateTriggerWidth(width) {
        this._triggerWidth.set(width);
    }
    isSelected(itemValue) {
        return this.value()?.some((v) => this.isItemEqualToValue()(itemValue, v)) ?? false;
    }
    select(itemValue) {
        const selected = this.value() ?? [];
        if (this.isSelected(itemValue)) {
            this.value.set(selected.filter((d) => !this.isItemEqualToValue()(d, itemValue)) ?? []);
        }
        else {
            this.value.set([...selected, itemValue]);
        }
        this._onChange?.(this.value() ?? []);
    }
    /** Select the active item with Enter key. */
    selectActiveItem() {
        if (!this.isExpanded())
            return;
        const value = this.keyManager.activeItem?.value();
        if (value !== null && value !== undefined) {
            this.select(value);
        }
        else {
            this.close();
        }
    }
    open() {
        if (this._disabled() || this.isExpanded())
            return;
        this._brnPopover?.open();
    }
    close() {
        if (this._disabled() || !this.isExpanded())
            return;
        this._brnPopover?.close();
    }
    toggle() {
        this.isExpanded() ? this.close() : this.open();
    }
    /** CONTROL VALUE ACCESSOR */
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled.set(isDisabled);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectMultiple, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnSelectMultiple, isStandalone: true, selector: "[brnSelectMultiple]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, isItemEqualToValue: { classPropertyName: "isItemEqualToValue", publicName: "isItemEqualToValue", isSignal: true, isRequired: false, transformFunction: null }, itemToString: { classPropertyName: "itemToString", publicName: "itemToString", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, providers: [
            provideBrnSelectBase(BrnSelectMultiple),
            BRN_SELECT_MULTIPLE_VALUE_ACCESSOR,
            provideBrnLabelable(BrnSelectMultiple),
        ], queries: [{ propertyName: "items", predicate: BrnSelectItemToken, descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.BrnFieldControl }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectMultiple, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectMultiple]',
                    providers: [
                        provideBrnSelectBase(BrnSelectMultiple),
                        BRN_SELECT_MULTIPLE_VALUE_ACCESSOR,
                        provideBrnLabelable(BrnSelectMultiple),
                    ],
                    hostDirectives: [BrnFieldControl],
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], isItemEqualToValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "isItemEqualToValue", required: false }] }], itemToString: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemToString", required: false }] }], items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => BrnSelectItemToken), { ...{
                            descendants: true,
                        }, isSignal: true }] }] } });

class BrnSelectPlaceholder {
    _select = injectBrnSelectBase();
    _hasValue = this._select.hasValue;
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectPlaceholder, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnSelectPlaceholder, isStandalone: true, selector: "[brnSelectPlaceholder]", host: { properties: { "attr.data-hidden": "_hasValue() ? \"\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectPlaceholder, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectPlaceholder]',
                    host: {
                        '[attr.data-hidden]': '_hasValue() ? "" : null',
                    },
                }]
        }] });

class BrnSelectScrollDown {
    _el = inject(ElementRef);
    _destroyRef = inject(DestroyRef);
    _selectContent = inject(BrnSelectContent);
    _showScrollDown = this._selectContent.showScrollDown;
    _endReached = new Subject();
    _scrollDown() {
        const mouseLeave$ = fromEvent(this._el.nativeElement, 'mouseleave');
        // 15ms is slightly faster than 60fps (16.6ms), ensuring a smooth animation loop.
        interval(15)
            .pipe(takeUntil(mouseLeave$), takeUntil(this._endReached), takeUntilDestroyed(this._destroyRef))
            .subscribe(() => this._selectContent.scrollDown(() => this._endReached.next(true)));
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectScrollDown, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnSelectScrollDown, isStandalone: true, selector: "[brnSelectScrollDown]", host: { attributes: { "aria-hidden": "true" }, listeners: { "mouseenter": "_scrollDown()" }, properties: { "attr.data-hidden": "!_showScrollDown() ? \"\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectScrollDown, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectScrollDown]',
                    host: {
                        'aria-hidden': 'true',
                        '[attr.data-hidden]': '!_showScrollDown() ? "" : null',
                        '(mouseenter)': '_scrollDown()',
                    },
                }]
        }] });

class BrnSelectScrollUp {
    _el = inject(ElementRef);
    _destroyRef = inject(DestroyRef);
    _selectContent = inject(BrnSelectContent);
    _showScrollUp = this._selectContent.showScrollUp;
    _endReached = new Subject();
    _scrollUp() {
        const mouseLeave$ = fromEvent(this._el.nativeElement, 'mouseleave');
        // 15ms is slightly faster than 60fps (16.6ms), ensuring a smooth animation loop.
        interval(15)
            .pipe(takeUntil(mouseLeave$), takeUntil(this._endReached), takeUntilDestroyed(this._destroyRef))
            .subscribe(() => this._selectContent.scrollUp(() => this._endReached.next(true)));
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectScrollUp, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnSelectScrollUp, isStandalone: true, selector: "[brnSelectScrollUp]", host: { attributes: { "aria-hidden": "true" }, listeners: { "mouseenter": "_scrollUp()" }, properties: { "attr.data-hidden": "!_showScrollUp() ? \"\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectScrollUp, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectScrollUp]',
                    host: {
                        'aria-hidden': 'true',
                        '[attr.data-hidden]': '!_showScrollUp() ? "" : null',
                        '(mouseenter)': '_scrollUp()',
                    },
                }]
        }] });

class BrnSelectSeparator {
    orientation = input('horizontal', ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectSeparator, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnSelectSeparator, isStandalone: true, selector: "[brnSelectSeparator]", inputs: { orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "separator" }, properties: { "attr.aria-orientation": "orientation()", "attr.data-orientation": "orientation()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectSeparator, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectSeparator]',
                    host: {
                        role: 'separator',
                        '[attr.aria-orientation]': 'orientation()',
                        '[attr.data-orientation]': 'orientation()',
                    },
                }]
        }], propDecorators: { orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }] } });

class BrnSelectTrigger {
    static _id = 0;
    _host = inject(ElementRef, { host: true });
    _brnOverlay = inject(BrnOverlay, { optional: true });
    _select = injectBrnSelectBase();
    _elementSize = injectElementSize();
    id = input(`brn-select-trigger-${++BrnSelectTrigger._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** Whether to force the trigger into an invalid state. */
    forceInvalid = input(false, { ...(ngDevMode ? { debugName: "forceInvalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Whether the combobox panel is expanded */
    _isExpanded = this._select.isExpanded;
    _disabled = this._select.disabledState;
    _isPlaceholder = computed(() => !this._select.hasValue(), ...(ngDevMode ? [{ debugName: "_isPlaceholder" }] : /* istanbul ignore next */ []));
    _invalid = computed(() => this._select?.controlState?.()?.invalid, ...(ngDevMode ? [{ debugName: "_invalid" }] : /* istanbul ignore next */ []));
    _touched = computed(() => this._select?.controlState?.()?.touched, ...(ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []));
    _dirty = computed(() => this._select?.controlState?.()?.dirty, ...(ngDevMode ? [{ debugName: "_dirty" }] : /* istanbul ignore next */ []));
    _spartanInvalid = computed(() => this.forceInvalid() || this._select?.controlState?.()?.spartanInvalid, ...(ngDevMode ? [{ debugName: "_spartanInvalid" }] : /* istanbul ignore next */ []));
    constructor() {
        this._select.registerSelectTrigger(this);
        this._brnOverlay?.setOrigin(this._host.nativeElement);
        effect(() => {
            const size = this._elementSize();
            if (!size)
                return;
            this._select.updateTriggerWidth(size.width);
            this._brnOverlay?.updatePosition();
        });
    }
    toggle() {
        this._select.toggle();
    }
    open() {
        this._brnOverlay?.open();
    }
    /** Listen for keydown events */
    onKeyDown(event) {
        // Capture the expansion state up-front. Committing a value (Enter/Tab while open)
        // closes the panel synchronously, so re-reading the state afterwards would report
        // the panel as closed and re-open it on the same keypress.
        const isExpanded = this._isExpanded();
        if (isExpanded && (event.key === 'Enter' || event.key === 'Tab')) {
            // prevent form submission if inside a form
            if (event.key === 'Enter') {
                event.preventDefault();
            }
            this._select.selectActiveItem();
            return;
        }
        if (!isExpanded && (event.key === 'Enter' || event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
            // prevent form submission if inside a form
            if (event.key === 'Enter') {
                event.preventDefault();
            }
            this._select.open();
        }
        this._select.keyManager.onKeydown(event);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectTrigger, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnSelectTrigger, isStandalone: true, selector: "button[brnSelectTrigger]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, forceInvalid: { classPropertyName: "forceInvalid", publicName: "forceInvalid", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "combobox", "aria-haspopup": "listbox", "type": "button" }, listeners: { "click": "toggle()", "keydown": "onKeyDown($event)" }, properties: { "id": "id()", "attr.aria-expanded": "_isExpanded()", "attr.data-placeholder": "_isPlaceholder() ? \"\" : null", "disabled": "_disabled()", "attr.aria-invalid": "_invalid?.() ? \"true\" : null", "attr.data-dirty": "_dirty?.() ? \"true\": null", "attr.data-touched": "_touched?.() ? \"true\" : null", "attr.data-matches-spartan-invalid": "_spartanInvalid?.() ? \"true\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnSelectTrigger]',
                    host: {
                        role: 'combobox',
                        'aria-haspopup': 'listbox',
                        type: 'button',
                        '[id]': 'id()',
                        '[attr.aria-expanded]': '_isExpanded()',
                        '[attr.data-placeholder]': '_isPlaceholder() ? "" : null',
                        '[disabled]': '_disabled()',
                        '[attr.aria-invalid]': '_invalid?.() ? "true" : null',
                        '[attr.data-dirty]': '_dirty?.() ? "true": null',
                        '[attr.data-touched]': '_touched?.() ? "true" : null',
                        '[attr.data-matches-spartan-invalid]': '_spartanInvalid?.() ? "true" : null',
                        '(click)': 'toggle()',
                        '(keydown)': 'onKeyDown($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], forceInvalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceInvalid", required: false }] }] } });

class BrnSelectValue {
    _select = injectBrnSelectBase();
    placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    _isPlaceholder = computed(() => !this._select.hasValue(), ...(ngDevMode ? [{ debugName: "_isPlaceholder" }] : /* istanbul ignore next */ []));
    hidden = computed(() => !this._select.hasValue() && !this.placeholder(), ...(ngDevMode ? [{ debugName: "hidden" }] : /* istanbul ignore next */ []));
    _value = computed(() => {
        return this._select.hasValue()
            ? stringifyAsLabel(this._select.value(), this._select.itemToString())
            : this.placeholder();
    }, ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectValue, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnSelectValue, isStandalone: true, selector: "[brnSelectValue]", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.data-placeholder": "_isPlaceholder() ? \"\" : null", "attr.data-hidden": "hidden() ? \"\" : null", "textContent": "_value()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectValue, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectValue]',
                    host: {
                        '[attr.data-placeholder]': '_isPlaceholder() ? "" : null',
                        '[attr.data-hidden]': 'hidden() ? "" : null',
                        '[textContent]': '_value()',
                    },
                }]
        }], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }] } });

class BrnSelectValueTemplate {
    _templateRef = inject(TemplateRef);
    _viewContainerRef = inject(ViewContainerRef);
    _select = injectBrnSelectBase();
    _value = computed(() => {
        const value = this._select.value();
        if (value === null || value === undefined) {
            return null;
        }
        return value;
    }, ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const value = this._value();
            if (value !== null && value !== undefined) {
                this._viewContainerRef.clear();
                this._viewContainerRef.createEmbeddedView(this._templateRef, {
                    $implicit: value,
                });
            }
            else {
                this._viewContainerRef.clear();
            }
        });
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectValueTemplate, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnSelectValueTemplate, isStandalone: true, selector: "[brnSelectValueTemplate]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectValueTemplate, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectValueTemplate]',
                }]
        }], ctorParameters: () => [] });

class BrnSelectValues {
    _templateRef = inject((TemplateRef));
    _viewContainerRef = inject(ViewContainerRef);
    _select = injectBrnSelectBase();
    _values = computed(() => {
        const values = this._select.value();
        if (values === null || values === undefined) {
            return null;
        }
        return Array.isArray(values) ? values : [values];
    }, ...(ngDevMode ? [{ debugName: "_values" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const values = this._values();
            if (values?.length) {
                this._viewContainerRef.clear();
                this._viewContainerRef.createEmbeddedView(this._templateRef, {
                    $implicit: values,
                });
            }
            else {
                this._viewContainerRef.clear();
            }
        });
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectValues, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnSelectValues, isStandalone: true, selector: "[brnSelectValues]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSelectValues, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSelectValues]',
                }]
        }], ctorParameters: () => [] });

const BrnSelectImports = [
    BrnSelect,
    BrnSelectContent,
    BrnSelectGroup,
    BrnSelectItem,
    BrnSelectLabel,
    BrnSelectList,
    BrnSelectMultiple,
    BrnSelectPlaceholder,
    BrnSelectScrollUp,
    BrnSelectScrollDown,
    BrnSelectSeparator,
    BrnSelectTrigger,
    BrnSelectValue,
    BrnSelectValueTemplate,
    BrnSelectValues,
];

/**
 * Generated bundle index. Do not edit.
 */

export { BRN_SELECT_MULTIPLE_VALUE_ACCESSOR, BRN_SELECT_VALUE_ACCESSOR, BrnSelect, BrnSelectBaseToken, BrnSelectContent, BrnSelectGroup, BrnSelectImports, BrnSelectItem, BrnSelectItemToken, BrnSelectLabel, BrnSelectList, BrnSelectMultiple, BrnSelectPlaceholder, BrnSelectScrollDown, BrnSelectScrollUp, BrnSelectSeparator, BrnSelectTrigger, BrnSelectValue, BrnSelectValueTemplate, BrnSelectValues, injectBrnSelectBase, injectBrnSelectConfig, provideBrnSelectBase, provideBrnSelectConfig, provideBrnSelectItem };
//# sourceMappingURL=spartan-ng-brain-select.mjs.map
