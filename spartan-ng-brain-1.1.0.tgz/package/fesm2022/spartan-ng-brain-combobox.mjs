import { ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import * as i0 from '@angular/core';
import { InjectionToken, inject, ElementRef, computed, Directive, forwardRef, Injector, input, booleanAttribute, linkedSignal, model, signal, contentChildren, contentChild, afterNextRender, effect, untracked, Renderer2, TemplateRef, ViewContainerRef, PLATFORM_ID } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from '@spartan-ng/brain/field';
import { BrnFieldControl, provideBrnLabelable } from '@spartan-ng/brain/field';
import { BrnPopover } from '@spartan-ng/brain/popover';
import { stringifyAsLabel, injectElementSize } from '@spartan-ng/brain/core';
import { BrnOverlay } from '@spartan-ng/brain/overlay';
import { isPlatformBrowser } from '@angular/common';

const comboboxContainsFilter = (item, query, collator, itemToString) => {
    if (!query) {
        return true;
    }
    const itemString = stringifyAsLabel(item, itemToString);
    for (let i = 0; i <= itemString.length - query.length; i += 1) {
        if (collator.compare(itemString.slice(i, i + query.length), query) === 0) {
            return true;
        }
    }
    return false;
};
const comboboxStartsWithFilter = (item, query, collator, itemToString) => {
    if (!query) {
        return true;
    }
    const itemString = stringifyAsLabel(item, itemToString);
    return collator.compare(itemString.slice(0, query.length), query) === 0;
};
const comboboxEndsWithFilter = (item, query, collator, itemToString) => {
    if (!query) {
        return true;
    }
    const itemString = stringifyAsLabel(item, itemToString);
    const queryLength = query.length;
    return (itemString.length >= queryLength && collator.compare(itemString.slice(itemString.length - queryLength), query) === 0);
};

const BrnComboboxBaseToken = new InjectionToken('BrnComboboxBaseToken');
function provideBrnComboboxBase(instance) {
    return { provide: BrnComboboxBaseToken, useExisting: instance };
}
/**
 * Inject the combobox component.
 */
function injectBrnComboboxBase() {
    return inject(BrnComboboxBaseToken);
}
function getDefaultConfig() {
    return {
        filterOptions: {
            usage: 'search',
            sensitivity: 'base',
            ignorePunctuation: true,
        },
        filter: (itemValue, search, collator, itemToString) => comboboxContainsFilter(itemValue, search, collator, itemToString),
        isItemEqualToValue: (itemValue, selectedValue) => Object.is(itemValue, selectedValue),
        isSingleValuePresent: (value) => value !== undefined && value !== null && value !== '',
        itemToString: undefined,
        autoHighlight: false,
        closeOnSelect: true,
    };
}
const BrnComboboxConfigToken = new InjectionToken('BrnComboboxConfig');
function provideBrnComboboxConfig(config) {
    return { provide: BrnComboboxConfigToken, useValue: { ...getDefaultConfig(), ...config } };
}
function injectBrnComboboxConfig() {
    const injectedConfig = inject(BrnComboboxConfigToken, { optional: true });
    return injectedConfig ? injectedConfig : getDefaultConfig();
}

class BrnComboboxContent {
    _combobox = injectBrnComboboxBase();
    el = inject(ElementRef);
    _dataState = computed(() => (this._combobox.isExpanded() ? 'open' : 'closed'), ...(ngDevMode ? [{ debugName: "_dataState" }] : /* istanbul ignore next */ []));
    /** Determine if the combobox has no visible items */
    _isEmpty = computed(() => !this._combobox.visibleItems(), ...(ngDevMode ? [{ debugName: "_isEmpty" }] : /* istanbul ignore next */ []));
    _comboboxWidth = this._combobox.searchInputWrapperWidth;
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnComboboxContent, isStandalone: true, selector: "[brnComboboxContent]", host: { properties: { "attr.data-state": "_dataState()", "attr.data-empty": "_isEmpty() ? \"\" : null", "style.--brn-combobox-width.px": "_comboboxWidth()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxContent]',
                    host: {
                        '[attr.data-state]': '_dataState()',
                        '[attr.data-empty]': '_isEmpty() ? "" : null',
                        '[style.--brn-combobox-width.px]': '_comboboxWidth()',
                    },
                }]
        }] });

const BrnComboboxItemToken = new InjectionToken('BrnComboboxItemToken');
function provideBrnComboboxItem(comboboxItem) {
    return { provide: BrnComboboxItemToken, useExisting: comboboxItem };
}

const BRN_COMBOBOX_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => BrnCombobox),
    multi: true,
};
class BrnCombobox {
    _injector = inject(Injector);
    _fieldControl = inject(BrnFieldControl, { optional: true });
    _config = injectBrnComboboxConfig();
    /** Access the popover if present */
    _brnPopover = inject(BrnPopover, { optional: true });
    controlState = this._fieldControl?.controlState;
    /** Whether the combobox is disabled */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _disabled = linkedSignal(this.disabled, ...(ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []));
    /** @internal The disabled state as a readonly signal */
    disabledState = this._disabled.asReadonly();
    /** Options for filtering the combobox items */
    filterOptions = input({}, ...(ngDevMode ? [{ debugName: "filterOptions" }] : /* istanbul ignore next */ []));
    /** @internal The collator used for string comparison */
    collator = computed(() => {
        const options = this.filterOptions();
        const mergedOptions = { ...this._config.filterOptions, ...options };
        return new Intl.Collator(options.locale, mergedOptions);
    }, ...(ngDevMode ? [{ debugName: "collator" }] : /* istanbul ignore next */ []));
    /** A function to compare an item with the selected value. */
    isItemEqualToValue = input(this._config.isItemEqualToValue, ...(ngDevMode ? [{ debugName: "isItemEqualToValue" }] : /* istanbul ignore next */ []));
    /** A function to convert an item to a string for display. */
    itemToString = input(this._config.itemToString, ...(ngDevMode ? [{ debugName: "itemToString" }] : /* istanbul ignore next */ []));
    /** A custom filter function to use when searching. */
    filter = input(this._config.filter, ...(ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []));
    /** Whether to auto-highlight the first matching item. */
    autoHighlight = input(this._config.autoHighlight, { ...(ngDevMode ? { debugName: "autoHighlight" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Whether to close the popover after selecting an item. */
    closeOnSelect = input(this._config.closeOnSelect, { ...(ngDevMode ? { debugName: "closeOnSelect" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** The selected value of the combobox. */
    value = model(null, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /**
     * Determines whether a single value is present (i.e., has been selected).
     * Considers `undefined`, `null`, and empty string as "not present".
     * Only used by single-select combobox in popup mode, ignored by the multiple select variant.
     */
    isSingleValuePresent = input(this._config.isSingleValuePresent, ...(ngDevMode ? [{ debugName: "isSingleValuePresent" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.isSingleValuePresent()(this.value()), ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    /** The current search query. */
    search = model('', ...(ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []));
    _inputWidth = signal(null, ...(ngDevMode ? [{ debugName: "_inputWidth" }] : /* istanbul ignore next */ []));
    /** @internal The width of the search input wrapper */
    searchInputWrapperWidth = this._inputWidth.asReadonly();
    /** @internal Access all the items within the combobox */
    items = contentChildren(BrnComboboxItemToken, { ...(ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {}), descendants: true });
    _content = contentChild(BrnComboboxContent, { ...(ngDevMode ? { debugName: "_content" } : /* istanbul ignore next */ {}), descendants: true });
    /** Determine if the combobox has any visible items */
    visibleItems = computed(() => this.items().some((item) => item.visible()), ...(ngDevMode ? [{ debugName: "visibleItems" }] : /* istanbul ignore next */ []));
    /** @internal The key manager for managing active descendant */
    keyManager = new ActiveDescendantKeyManager(this.items, this._injector);
    /** @internal Whether the combobox is expanded */
    isExpanded = computed(() => this._brnPopover?.stateComputed() === 'open', ...(ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []));
    _comboboxInput = signal(undefined, ...(ngDevMode ? [{ debugName: "_comboboxInput" }] : /* istanbul ignore next */ []));
    mode = computed(() => this._comboboxInput()?.mode() || 'combobox', ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    labelableId = computed(() => this._comboboxInput()?.id(), ...(ngDevMode ? [{ debugName: "labelableId" }] : /* istanbul ignore next */ []));
    _onChange;
    _onTouched;
    constructor() {
        this.keyManager
            .withVerticalOrientation()
            .withHomeAndEnd()
            .withWrap()
            .skipPredicate((item) => item.disabled || !item.visible());
        this._brnPopover?.closed.subscribe(() => {
            this.search.set('');
            this.keyManager.setActiveItem(-1);
        });
        afterNextRender(() => {
            effect(() => {
                if (!this.autoHighlight() || !this.isExpanded() || !this.search())
                    return;
                const hasVisibleItems = this.visibleItems();
                untracked(() => {
                    if (hasVisibleItems) {
                        this.keyManager.setFirstItemActive();
                    }
                    else {
                        this.keyManager.setActiveItem(-1);
                    }
                });
            }, { injector: this._injector });
        });
    }
    registerComboboxInput(input) {
        this._comboboxInput.set(input);
    }
    updateInputWidth(width) {
        this._inputWidth.set(width);
    }
    isSelected(itemValue) {
        return this.isItemEqualToValue()(itemValue, this.value());
    }
    select(itemValue) {
        this.value.set(itemValue);
        this._onChange?.(itemValue);
        if (this.closeOnSelect()) {
            this.close();
        }
    }
    /** Select the active item with Enter key. */
    selectActiveItem() {
        if (!this.isExpanded())
            return;
        const value = this.keyManager.activeItem?.value();
        if (value) {
            this.select(value);
        }
        else {
            this.close();
        }
    }
    resetValue() {
        this.value.set(null);
        this._onChange?.(null);
    }
    resetSearch() {
        this.search.set('');
    }
    removeValue(_) {
        console.warn('BrnComboboxChipRemove only works with multiple selection comboboxes.');
    }
    removeLastSelectedItem() {
        console.warn('BrnComboboxChipInput only works with multiple selection comboboxes.');
    }
    open() {
        if (this._disabled() || this.isExpanded())
            return;
        this._brnPopover?.open();
    }
    /** CONTROL VALUE ACCESSOR */
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled.set(isDisabled);
    }
    _onFocusOut(event) {
        const currentTarget = event.currentTarget;
        const focusedEl = event.relatedTarget;
        const contentEl = this._content()?.el.nativeElement;
        if (!currentTarget.contains(focusedEl) && !contentEl?.contains(focusedEl)) {
            if (this.isExpanded()) {
                this._brnPopover?.close();
            }
            this._onTouched?.();
        }
    }
    close() {
        if (this._disabled() || !this.isExpanded())
            return;
        this._brnPopover?.close();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCombobox, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnCombobox, isStandalone: true, selector: "[brnCombobox]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, filterOptions: { classPropertyName: "filterOptions", publicName: "filterOptions", isSignal: true, isRequired: false, transformFunction: null }, isItemEqualToValue: { classPropertyName: "isItemEqualToValue", publicName: "isItemEqualToValue", isSignal: true, isRequired: false, transformFunction: null }, itemToString: { classPropertyName: "itemToString", publicName: "itemToString", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, autoHighlight: { classPropertyName: "autoHighlight", publicName: "autoHighlight", isSignal: true, isRequired: false, transformFunction: null }, closeOnSelect: { classPropertyName: "closeOnSelect", publicName: "closeOnSelect", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, isSingleValuePresent: { classPropertyName: "isSingleValuePresent", publicName: "isSingleValuePresent", isSignal: true, isRequired: false, transformFunction: null }, search: { classPropertyName: "search", publicName: "search", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", search: "searchChange" }, host: { listeners: { "focusout": "_onFocusOut($event)" } }, providers: [BRN_COMBOBOX_VALUE_ACCESSOR, provideBrnComboboxBase(BrnCombobox), provideBrnLabelable(BrnCombobox)], queries: [{ propertyName: "items", predicate: BrnComboboxItemToken, descendants: true, isSignal: true }, { propertyName: "_content", first: true, predicate: BrnComboboxContent, descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.BrnFieldControl }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCombobox, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCombobox]',
                    providers: [BRN_COMBOBOX_VALUE_ACCESSOR, provideBrnComboboxBase(BrnCombobox), provideBrnLabelable(BrnCombobox)],
                    hostDirectives: [BrnFieldControl],
                    host: {
                        '(focusout)': '_onFocusOut($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], filterOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterOptions", required: false }] }], isItemEqualToValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "isItemEqualToValue", required: false }] }], itemToString: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemToString", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], autoHighlight: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHighlight", required: false }] }], closeOnSelect: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnSelect", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], isSingleValuePresent: [{ type: i0.Input, args: [{ isSignal: true, alias: "isSingleValuePresent", required: false }] }], search: [{ type: i0.Input, args: [{ isSignal: true, alias: "search", required: false }] }, { type: i0.Output, args: ["searchChange"] }], items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => BrnComboboxItemToken), { ...{
                            descendants: true,
                        }, isSignal: true }] }], _content: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BrnComboboxContent), { ...{
                            descendants: true,
                        }, isSignal: true }] }] } });

class BrnComboboxAnchor {
    _host = inject(ElementRef, { host: true });
    _brnOverlay = inject(BrnOverlay, { optional: true });
    _content = inject(BrnComboboxContent, { optional: true });
    _combobox = injectBrnComboboxBase();
    _elementSize = injectElementSize();
    constructor() {
        // skip if it's inside a combobox content
        if (this._content)
            return;
        this._brnOverlay?.setOrigin(this._host.nativeElement);
        effect(() => {
            const size = this._elementSize();
            if (!size)
                return;
            this._combobox.updateInputWidth(size.width);
            this._brnOverlay?.updatePosition();
        });
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxAnchor, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnComboboxAnchor, isStandalone: true, selector: "[brnComboboxAnchor]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxAnchor, decorators: [{
            type: Directive,
            args: [{ selector: '[brnComboboxAnchor]' }]
        }], ctorParameters: () => [] });

class BrnComboboxChip {
    _combobox = injectBrnComboboxBase();
    _disabled = this._combobox.disabledState;
    value = input.required(...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxChip, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnComboboxChip, isStandalone: true, selector: "[brnComboboxChip]", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null } }, host: { attributes: { "tabindex": "-1" }, properties: { "attr.data-disabled": "_disabled() ? \"\" : null", "attr.aria-disabled": "_disabled() ? \"true\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxChip, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxChip]',
                    host: {
                        tabindex: '-1',
                        '[attr.data-disabled]': '_disabled() ? "" : null',
                        '[attr.aria-disabled]': '_disabled() ? "true" : null',
                    },
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }] } });

class BrnComboboxChipInput {
    static _id = 0;
    _el = inject(ElementRef);
    _combobox = injectBrnComboboxBase();
    /** The id of the combobox input */
    id = input(`brn-combobox-input-${++BrnComboboxChipInput._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** Manual override for aria-invalid. When not set, auto-detects from the parent combobox error state. */
    ariaInvalidOverride = input(undefined, { ...(ngDevMode ? { debugName: "ariaInvalidOverride" } : /* istanbul ignore next */ {}), transform: (v) => (v === '' || v === undefined ? undefined : booleanAttribute(v)),
        alias: 'aria-invalid' });
    /** Computed aria-invalid: uses manual override if provided, otherwise reads from parent error state. */
    _ariaInvalid = computed(() => this.ariaInvalidOverride() ?? this._combobox.controlState?.()?.invalid, ...(ngDevMode ? [{ debugName: "_ariaInvalid" }] : /* istanbul ignore next */ []));
    _dirty = computed(() => this._combobox.controlState?.()?.dirty, ...(ngDevMode ? [{ debugName: "_dirty" }] : /* istanbul ignore next */ []));
    _touched = computed(() => this._combobox.controlState?.()?.touched, ...(ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []));
    _spartanInvalid = computed(() => this._combobox.controlState?.()?.spartanInvalid, ...(ngDevMode ? [{ debugName: "_spartanInvalid" }] : /* istanbul ignore next */ []));
    _disabled = this._combobox.disabledState;
    /** Whether the combobox panel is expanded */
    _isExpanded = this._combobox.isExpanded;
    constructor() {
        this._combobox.registerComboboxChipInput?.(this);
        effect(() => {
            const search = this._combobox.search();
            if (search === '') {
                // reset input on popover close
                this._el.nativeElement.value = '';
            }
        });
    }
    onInput(event) {
        const value = event.target.value;
        this._combobox.search.set(value);
        this._combobox.open();
    }
    /** Listen for keydown events */
    onKeyDown(event) {
        if (event.key === 'Enter') {
            // prevent form submission if inside a form
            event.preventDefault();
            this._combobox.selectActiveItem();
        }
        if (!this._isExpanded()) {
            if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
                this._combobox.open();
            }
            if (event.key === 'Escape') {
                this._combobox.resetValue();
            }
        }
        if (this._combobox.search() === '' && event.key === 'Backspace') {
            this._combobox.removeLastSelectedItem();
        }
        this._combobox.keyManager.onKeydown(event);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxChipInput, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnComboboxChipInput, isStandalone: true, selector: "input[brnComboboxChipInput]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaInvalidOverride: { classPropertyName: "ariaInvalidOverride", publicName: "aria-invalid", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "type": "text", "role": "combobox", "autocomplete": "off", "autocorrect": "off", "autocapitalize": "none", "spellcheck": "false", "aria-autocomplete": "list", "aria-haspopup": "listbox" }, listeners: { "keydown": "onKeyDown($event)", "input": "onInput($event)" }, properties: { "id": "id()", "attr.aria-expanded": "_isExpanded()", "attr.aria-invalid": "_ariaInvalid() ? \"true\" : null", "attr.data-invalid": "_ariaInvalid() ? \"true\" : null", "attr.data-matches-spartan-invalid": "_spartanInvalid() ? \"true\" : null", "attr.data-dirty": "_touched() ? \"true\" : null", "attr.data-touched": "_touched() ? \"true\" : null", "attr.disabled": "_disabled() ? \"\" : null", "attr.data-disabled": "_disabled() ? \"\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxChipInput, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[brnComboboxChipInput]',
                    host: {
                        '[id]': 'id()',
                        type: 'text',
                        role: 'combobox',
                        autocomplete: 'off',
                        autocorrect: 'off',
                        autocapitalize: 'none',
                        spellcheck: 'false',
                        'aria-autocomplete': 'list',
                        'aria-haspopup': 'listbox',
                        '[attr.aria-expanded]': '_isExpanded()',
                        '[attr.aria-invalid]': '_ariaInvalid() ? "true" : null',
                        '[attr.data-invalid]': '_ariaInvalid() ? "true" : null',
                        '[attr.data-matches-spartan-invalid]': '_spartanInvalid() ? "true" : null',
                        '[attr.data-dirty]': '_touched() ? "true" : null',
                        '[attr.data-touched]': '_touched() ? "true" : null',
                        '[attr.disabled]': '_disabled() ? "" : null',
                        '[attr.data-disabled]': '_disabled() ? "" : null',
                        '(keydown)': 'onKeyDown($event)',
                        '(input)': 'onInput($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaInvalidOverride: [{ type: i0.Input, args: [{ isSignal: true, alias: "aria-invalid", required: false }] }] } });

class BrnComboboxChipRemove {
    _combobox = injectBrnComboboxBase();
    _chip = inject((BrnComboboxChip));
    _disabled = this._combobox.disabledState;
    removeChip(event) {
        event.stopPropagation();
        if (this._combobox.disabledState()) {
            return;
        }
        const value = this._chip.value();
        this._combobox.removeValue(value);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxChipRemove, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnComboboxChipRemove, isStandalone: true, selector: "button[brnComboboxChipRemove]", host: { attributes: { "type": "button", "tabindex": "-1", "aria-disabled": "true" }, listeners: { "click": "removeChip($event)" }, properties: { "attr.data-disabled": "_disabled() ? \"\" : null", "attr.aria-disabled": "_disabled() ? \"true\" : null", "attr.disabled": "_disabled() ? \"\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxChipRemove, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnComboboxChipRemove]',
                    host: {
                        type: 'button',
                        tabindex: '-1',
                        'aria-disabled': 'true',
                        '[attr.data-disabled]': '_disabled() ? "" : null',
                        '[attr.aria-disabled]': '_disabled() ? "true" : null',
                        '[attr.disabled]': '_disabled() ? "" : null',
                        '(click)': 'removeChip($event)',
                    },
                }]
        }] });

class BrnComboboxClear {
    _combobox = injectBrnComboboxBase();
    _renderer = inject(Renderer2);
    _templateRef = inject(TemplateRef);
    _viewContainerRef = inject(ViewContainerRef);
    /** Determine if the combobox has a value */
    _shouldShowClear = computed(() => {
        const mode = this._combobox.mode();
        if (mode === 'combobox') {
            return this._combobox.value() !== null || this._combobox.search() !== '';
        }
        else {
            return this._combobox.search() !== '';
        }
    }, ...(ngDevMode ? [{ debugName: "_shouldShowClear" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            this._viewContainerRef.clear();
            if (this._shouldShowClear()) {
                const view = this._viewContainerRef.createEmbeddedView(this._templateRef);
                view.rootNodes.forEach((node) => {
                    this._renderer.listen(node, 'click', (e) => {
                        e.preventDefault();
                        this.clear();
                    });
                });
            }
        });
    }
    clear() {
        if (this._combobox.mode() === 'combobox') {
            this._combobox.resetValue();
            this._combobox.resetSearch();
        }
        else {
            this._combobox.resetSearch();
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxClear, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnComboboxClear, isStandalone: true, selector: "[brnComboboxClear]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxClear, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxClear]',
                }]
        }], ctorParameters: () => [] });

class BrnComboboxEmpty {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxEmpty, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnComboboxEmpty, isStandalone: true, selector: "[brnComboboxEmpty]", host: { attributes: { "role": "status", "aria-live": "polite", "aria-atomic": "true" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxEmpty, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxEmpty]',
                    host: {
                        role: 'status',
                        'aria-live': 'polite',
                        'aria-atomic': 'true',
                    },
                }]
        }] });

class BrnComboboxLabel {
    static _id = 0;
    /** The id of the combobox label */
    id = input(`brn-combobox-label-${++BrnComboboxLabel._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxLabel, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnComboboxLabel, isStandalone: true, selector: "[brnComboboxLabel]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "id": "id()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxLabel, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxLabel]',
                    host: {
                        '[id]': 'id()',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }] } });

class BrnComboboxGroup {
    /** Get the items in the group */
    _items = contentChildren(BrnComboboxItemToken, { ...(ngDevMode ? { debugName: "_items" } : /* istanbul ignore next */ {}), descendants: true });
    /** Determine if there are any visible items in the group */
    _visible = computed(() => this._items().some((item) => item.visible()), ...(ngDevMode ? [{ debugName: "_visible" }] : /* istanbul ignore next */ []));
    /** Get the label associated with the group */
    _label = contentChild(BrnComboboxLabel, ...(ngDevMode ? [{ debugName: "_label" }] : /* istanbul ignore next */ []));
    _labelledBy = computed(() => {
        const label = this._label();
        return label ? label.id() : null;
    }, ...(ngDevMode ? [{ debugName: "_labelledBy" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxGroup, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnComboboxGroup, isStandalone: true, selector: "[brnComboboxGroup]", host: { attributes: { "role": "group" }, properties: { "attr.data-hidden": "!_visible() ? \"\" : null", "attr.aria-labelledby": "_labelledBy()" } }, queries: [{ propertyName: "_items", predicate: BrnComboboxItemToken, descendants: true, isSignal: true }, { propertyName: "_label", first: true, predicate: BrnComboboxLabel, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxGroup, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxGroup]',
                    host: {
                        role: 'group',
                        '[attr.data-hidden]': '!_visible() ? "" : null',
                        '[attr.aria-labelledby]': '_labelledBy()',
                    },
                }]
        }], propDecorators: { _items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => BrnComboboxItemToken), { ...{
                            descendants: true,
                        }, isSignal: true }] }], _label: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BrnComboboxLabel), { isSignal: true }] }] } });

class BrnComboboxInput {
    static _id = 0;
    _el = inject(ElementRef);
    _combobox = injectBrnComboboxBase();
    _content = inject(BrnComboboxContent, { optional: true });
    mode = computed(() => (this._content ? 'popup' : 'combobox'), ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    /** The id of the combobox input */
    id = input(`brn-combobox-input-${++BrnComboboxInput._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** Manual override for aria-invalid. When not set, auto-detects from the parent combobox error state. */
    ariaInvalidOverride = input(undefined, { ...(ngDevMode ? { debugName: "ariaInvalidOverride" } : /* istanbul ignore next */ {}), transform: (v) => (v === '' || v === undefined ? undefined : booleanAttribute(v)),
        alias: 'aria-invalid' });
    /** Forces the invalid state visually, regardless of form control state. */
    forceInvalid = input(false, { ...(ngDevMode ? { debugName: "forceInvalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = this._combobox.disabledState;
    /** Whether the combobox panel is expanded */
    _isExpanded = this._combobox.isExpanded;
    /** Computed aria-invalid: uses manual override if provided, otherwise reads from parent error state. */
    _ariaInvalid = computed(() => this.ariaInvalidOverride() ?? this._combobox.controlState?.()?.invalid, ...(ngDevMode ? [{ debugName: "_ariaInvalid" }] : /* istanbul ignore next */ []));
    _dirty = computed(() => this._combobox.controlState?.()?.dirty, ...(ngDevMode ? [{ debugName: "_dirty" }] : /* istanbul ignore next */ []));
    _touched = computed(() => this._combobox.controlState?.()?.touched, ...(ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []));
    _spartanInvalid = computed(() => this.forceInvalid() || this._combobox.controlState?.()?.spartanInvalid, ...(ngDevMode ? [{ debugName: "_spartanInvalid" }] : /* istanbul ignore next */ []));
    constructor() {
        this._combobox.registerComboboxInput?.(this);
        effect(() => {
            const mode = this.mode();
            const value = this._combobox.value();
            const search = this._combobox.search();
            // In combobox mode we want to display the label of the selected value if no search is active
            if (mode === 'combobox' && value && search === '') {
                this._el.nativeElement.value = stringifyAsLabel(value, this._combobox.itemToString());
                return;
            }
            // Otherwise we want to update the input value to the search value
            if (this._el.nativeElement.value !== search) {
                this._el.nativeElement.value = search;
            }
        });
    }
    onInput(event) {
        const value = event.target.value;
        this._combobox.search.set(value);
        this._combobox.open();
        if (value === '' && this.mode() === 'combobox') {
            this._combobox.resetValue();
        }
    }
    /** Listen for keydown events */
    onKeyDown(event) {
        if (event.key === 'Enter') {
            // prevent form submission if inside a form
            event.preventDefault();
            this._combobox.selectActiveItem();
        }
        if (this._isExpanded()) {
            if (event.key === 'Tab') {
                this._combobox.selectActiveItem();
            }
        }
        else {
            if (event.key === 'Enter' || event.key === 'ArrowDown' || event.key === 'ArrowUp') {
                this._combobox.open();
            }
            if (event.key === 'Escape') {
                this._combobox.resetValue();
            }
        }
        this._combobox.keyManager.onKeydown(event);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxInput, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnComboboxInput, isStandalone: true, selector: "input[brnComboboxInput]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaInvalidOverride: { classPropertyName: "ariaInvalidOverride", publicName: "aria-invalid", isSignal: true, isRequired: false, transformFunction: null }, forceInvalid: { classPropertyName: "forceInvalid", publicName: "forceInvalid", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "type": "text", "role": "combobox", "autocomplete": "off", "autocorrect": "off", "autocapitalize": "none", "spellcheck": "false", "aria-autocomplete": "list", "aria-haspopup": "listbox" }, listeners: { "keydown": "onKeyDown($event)", "input": "onInput($event)" }, properties: { "id": "id()", "attr.aria-expanded": "_isExpanded()", "attr.aria-invalid": "_ariaInvalid() ? \"true\": null", "attr.data-invalid": "_ariaInvalid() ? \"true\": null", "attr.data-matches-spartan-invalid": "_spartanInvalid() ? \"true\": null", "attr.data-touched": "_touched() ? \"true\": null", "attr.data-dirty": "_dirty() ? \"true\": null", "attr.disabled": "disabled() ? \"\" : null" } }, exportAs: ["brnComboboxInput"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxInput, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[brnComboboxInput]',
                    exportAs: 'brnComboboxInput',
                    host: {
                        '[id]': 'id()',
                        type: 'text',
                        role: 'combobox',
                        autocomplete: 'off',
                        autocorrect: 'off',
                        autocapitalize: 'none',
                        spellcheck: 'false',
                        'aria-autocomplete': 'list',
                        'aria-haspopup': 'listbox',
                        '[attr.aria-expanded]': '_isExpanded()',
                        '[attr.aria-invalid]': '_ariaInvalid() ? "true": null',
                        '[attr.data-invalid]': '_ariaInvalid() ? "true": null',
                        '[attr.data-matches-spartan-invalid]': '_spartanInvalid() ? "true": null',
                        '[attr.data-touched]': '_touched() ? "true": null',
                        '[attr.data-dirty]': '_dirty() ? "true": null',
                        '[attr.disabled]': 'disabled() ? "" : null',
                        '(keydown)': 'onKeyDown($event)',
                        '(input)': 'onInput($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaInvalidOverride: [{ type: i0.Input, args: [{ isSignal: true, alias: "aria-invalid", required: false }] }], forceInvalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceInvalid", required: false }] }] } });

class BrnComboboxItem {
    static _id = 0;
    _platform = inject(PLATFORM_ID);
    _elementRef = inject(ElementRef);
    /** Access the combobox component */
    _combobox = injectBrnComboboxBase();
    /** A unique id for the item */
    id = input(`brn-combobox-item-${++BrnComboboxItem._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** The value this item represents. */
    value = input.required(...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    // eslint-disable-next-line @typescript-eslint/naming-convention
    _disabled = input(false, { ...(ngDevMode ? { debugName: "_disabled" } : /* istanbul ignore next */ {}), alias: 'disabled',
        transform: booleanAttribute });
    /** Expose disabled as a value - used by the Highlightable interface */
    get disabled() {
        return this._disabled();
    }
    /** Whether the item is selected. */
    active = computed(() => this._combobox.isSelected(this.value()), ...(ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []));
    _highlighted = signal(false, ...(ngDevMode ? [{ debugName: "_highlighted" }] : /* istanbul ignore next */ []));
    /** @internal Determine if this item is visible based on the current search query */
    visible = computed(() => {
        return this._combobox.filter()(this.value(), this._combobox.search(), this._combobox.collator(), this._combobox.itemToString());
    }, ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    setActiveStyles() {
        this._highlighted.set(true);
        // ensure the item is in view
        if (isPlatformBrowser(this._platform)) {
            this._elementRef.nativeElement.scrollIntoView({ block: 'nearest' });
        }
    }
    setInactiveStyles() {
        this._highlighted.set(false);
    }
    getLabel() {
        return stringifyAsLabel(this.value(), this._combobox.itemToString());
    }
    select() {
        if (this._disabled()) {
            return;
        }
        this._combobox.keyManager.setActiveItem(this);
        this._combobox.select(this.value());
    }
    activate() {
        if (this._disabled()) {
            return;
        }
        this._combobox.keyManager.setActiveItem(this);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxItem, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnComboboxItem, isStandalone: true, selector: "[brnComboboxItem]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, _disabled: { classPropertyName: "_disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "option" }, listeners: { "click": "select()", "mouseenter": "activate()" }, properties: { "id": "id()", "attr.data-highlighted": "_highlighted() ? \"\" : null", "attr.data-value": "value()", "attr.data-hidden": "!visible() ? '' : null", "attr.aria-selected": "active()", "attr.aria-disabled": "_disabled()", "attr.data-disabled": "_disabled() ? \"\" : null" } }, providers: [provideBrnComboboxItem(BrnComboboxItem)], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxItem, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxItem]',
                    providers: [provideBrnComboboxItem(BrnComboboxItem)],
                    host: {
                        role: 'option',
                        '[id]': 'id()',
                        '[attr.data-highlighted]': '_highlighted() ? "" : null',
                        '[attr.data-value]': 'value()',
                        '[attr.data-hidden]': "!visible() ? '' : null",
                        '[attr.aria-selected]': 'active()',
                        '[attr.aria-disabled]': '_disabled()',
                        '[attr.data-disabled]': '_disabled() ? "" : null',
                        '(click)': 'select()',
                        '(mouseenter)': 'activate()',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }], _disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });

class BrnComboboxList {
    static _id = 0;
    _combobox = injectBrnComboboxBase();
    /** Determine if the combobox has any visible items */
    _visibleItems = this._combobox.visibleItems;
    /** The id of the combobox list */
    id = input(`brn-combobox-list-${++BrnComboboxList._id}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxList, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnComboboxList, isStandalone: true, selector: "[brnComboboxList]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "listbox", "tabIndex": "-1", "aria-orientation": "vertical" }, properties: { "id": "id()", "attr.data-empty": "!_visibleItems() ? \"\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxList, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxList]',
                    host: {
                        role: 'listbox',
                        tabIndex: '-1',
                        'aria-orientation': 'vertical',
                        '[id]': 'id()',
                        '[attr.data-empty]': '!_visibleItems() ? "" : null',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }] } });

const BRN_COMBOBOX_MULTIPLE_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => BrnComboboxMultiple),
    multi: true,
};
class BrnComboboxMultiple {
    _injector = inject(Injector);
    _fieldControl = inject(BrnFieldControl, { optional: true });
    _config = injectBrnComboboxConfig();
    /** Access the popover if present */
    _brnPopover = inject(BrnPopover, { optional: true });
    controlState = this._fieldControl?.controlState;
    /** Whether the combobox is disabled */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _disabled = linkedSignal(this.disabled, ...(ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []));
    /** @internal The disabled state as a readonly signal */
    disabledState = this._disabled.asReadonly();
    /** Options for filtering the combobox items */
    filterOptions = input({}, ...(ngDevMode ? [{ debugName: "filterOptions" }] : /* istanbul ignore next */ []));
    /** @internal The collator used for string comparison */
    collator = computed(() => {
        const options = this.filterOptions();
        const mergedOptions = { ...this._config.filterOptions, ...options };
        return new Intl.Collator(options.locale, mergedOptions);
    }, ...(ngDevMode ? [{ debugName: "collator" }] : /* istanbul ignore next */ []));
    /** A function to compare an item with the selected value. */
    isItemEqualToValue = input(this._config.isItemEqualToValue, ...(ngDevMode ? [{ debugName: "isItemEqualToValue" }] : /* istanbul ignore next */ []));
    /** A function to convert an item to a string for display. */
    itemToString = input(this._config.itemToString, ...(ngDevMode ? [{ debugName: "itemToString" }] : /* istanbul ignore next */ []));
    /** A custom filter function to use when searching. */
    filter = input(this._config.filter, ...(ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []));
    /** Whether to auto-highlight the first matching item. */
    autoHighlight = input(this._config.autoHighlight, { ...(ngDevMode ? { debugName: "autoHighlight" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Whether to reset the search and close the popover after selecting an item when the search is active. */
    closeOnSelect = input(this._config.closeOnSelect, { ...(ngDevMode ? { debugName: "closeOnSelect" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** The selected values of the combobox. */
    value = model(null, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => {
        const value = this.value();
        if (value === null || value === undefined)
            return false;
        return value.length > 0;
    }, ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    /** The current search query. */
    search = model('', ...(ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []));
    _inputWidth = signal(null, ...(ngDevMode ? [{ debugName: "_inputWidth" }] : /* istanbul ignore next */ []));
    /** @internal The width of the search input wrapper */
    searchInputWrapperWidth = this._inputWidth.asReadonly();
    /** @internal Access all the items within the combobox */
    items = contentChildren(BrnComboboxItemToken, { ...(ngDevMode ? { debugName: "items" } : /* istanbul ignore next */ {}), descendants: true });
    _content = contentChild(BrnComboboxContent, { ...(ngDevMode ? { debugName: "_content" } : /* istanbul ignore next */ {}), descendants: true });
    /** Determine if the combobox has any visible items */
    visibleItems = computed(() => this.items().some((item) => item.visible()), ...(ngDevMode ? [{ debugName: "visibleItems" }] : /* istanbul ignore next */ []));
    /** @internal The key manager for managing active descendant */
    keyManager = new ActiveDescendantKeyManager(this.items, this._injector);
    /** @internal Whether the autocomplete is expanded */
    isExpanded = computed(() => this._brnPopover?.stateComputed() === 'open', ...(ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []));
    _comboboxChipInput = signal(undefined, ...(ngDevMode ? [{ debugName: "_comboboxChipInput" }] : /* istanbul ignore next */ []));
    mode = signal('combobox').asReadonly();
    labelableId = computed(() => this._comboboxChipInput()?.id(), ...(ngDevMode ? [{ debugName: "labelableId" }] : /* istanbul ignore next */ []));
    _onChange;
    _onTouched;
    constructor() {
        this.keyManager
            .withVerticalOrientation()
            .withHomeAndEnd()
            .withWrap()
            .skipPredicate((item) => item.disabled || !item.visible());
        this._brnPopover?.closed.subscribe(() => {
            this.search.set('');
            this.keyManager.setActiveItem(-1);
        });
        afterNextRender(() => {
            effect(() => {
                if (!this.autoHighlight() || !this.isExpanded() || !this.search())
                    return;
                const hasVisibleItems = this.visibleItems();
                untracked(() => {
                    if (hasVisibleItems) {
                        this.keyManager.setFirstItemActive();
                    }
                    else {
                        this.keyManager.setActiveItem(-1);
                    }
                });
            }, { injector: this._injector });
        });
    }
    registerComboboxChipInput(input) {
        this._comboboxChipInput.set(input);
    }
    updateInputWidth(width) {
        this._inputWidth.set(width);
    }
    isSelected(itemValue) {
        return this.value()?.some((v) => this.isItemEqualToValue()(itemValue, v)) ?? false;
    }
    select(itemValue) {
        const selected = this.value() ?? [];
        if (this.isSelected(itemValue)) {
            this.value.set(selected.filter((d) => !this.isItemEqualToValue()(d, itemValue)) ?? []);
        }
        else {
            this.value.set([...selected, itemValue]);
        }
        if (this.closeOnSelect() && this.search() !== '') {
            // reset search after selection and close popover
            this.search.set('');
            this.close();
        }
        this._onChange?.(this.value() ?? []);
    }
    /** Select the active item with Enter key. */
    selectActiveItem() {
        if (!this.isExpanded())
            return;
        const value = this.keyManager.activeItem?.value();
        if (value) {
            this.select(value);
        }
        else {
            this.close();
        }
    }
    resetValue() {
        this.value.set(null);
        this._onChange?.(null);
    }
    resetSearch() {
        this.search.set('');
    }
    removeValue(itemValue) {
        const selected = this.value() ?? [];
        this.value.set(selected.filter((value) => !this.isItemEqualToValue()(itemValue, value)) ?? []);
        this._onChange?.(this.value());
    }
    removeLastSelectedItem() {
        const selected = this.value() ?? [];
        if (selected.length === 0)
            return;
        this.value.set(selected.slice(0, -1));
        this._onChange?.(this.value());
    }
    open() {
        if (this._disabled() || this.isExpanded())
            return;
        this._brnPopover?.open();
    }
    _onFocusOut(event) {
        const currentTarget = event.currentTarget;
        const focusedEl = event.relatedTarget;
        const contentEl = this._content()?.el.nativeElement;
        if (!currentTarget.contains(focusedEl) && !contentEl?.contains(focusedEl)) {
            if (this.isExpanded()) {
                this._brnPopover?.close();
            }
            this._onTouched?.();
        }
    }
    close() {
        if (this._disabled() || !this.isExpanded())
            return;
        this._brnPopover?.close();
    }
    /** CONTROL VALUE ACCESSOR */
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this._disabled.set(isDisabled);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxMultiple, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnComboboxMultiple, isStandalone: true, selector: "[brnCombobox]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, filterOptions: { classPropertyName: "filterOptions", publicName: "filterOptions", isSignal: true, isRequired: false, transformFunction: null }, isItemEqualToValue: { classPropertyName: "isItemEqualToValue", publicName: "isItemEqualToValue", isSignal: true, isRequired: false, transformFunction: null }, itemToString: { classPropertyName: "itemToString", publicName: "itemToString", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, autoHighlight: { classPropertyName: "autoHighlight", publicName: "autoHighlight", isSignal: true, isRequired: false, transformFunction: null }, closeOnSelect: { classPropertyName: "closeOnSelect", publicName: "closeOnSelect", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, search: { classPropertyName: "search", publicName: "search", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", search: "searchChange" }, host: { listeners: { "focusout": "_onFocusOut($event)" } }, providers: [
            BRN_COMBOBOX_MULTIPLE_VALUE_ACCESSOR,
            provideBrnComboboxBase(BrnComboboxMultiple),
            provideBrnLabelable(BrnComboboxMultiple),
        ], queries: [{ propertyName: "items", predicate: BrnComboboxItemToken, descendants: true, isSignal: true }, { propertyName: "_content", first: true, predicate: BrnComboboxContent, descendants: true, isSignal: true }], hostDirectives: [{ directive: i1.BrnFieldControl }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxMultiple, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCombobox]',
                    providers: [
                        BRN_COMBOBOX_MULTIPLE_VALUE_ACCESSOR,
                        provideBrnComboboxBase(BrnComboboxMultiple),
                        provideBrnLabelable(BrnComboboxMultiple),
                    ],
                    hostDirectives: [BrnFieldControl],
                    host: {
                        '(focusout)': '_onFocusOut($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], filterOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterOptions", required: false }] }], isItemEqualToValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "isItemEqualToValue", required: false }] }], itemToString: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemToString", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], autoHighlight: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHighlight", required: false }] }], closeOnSelect: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnSelect", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], search: [{ type: i0.Input, args: [{ isSignal: true, alias: "search", required: false }] }, { type: i0.Output, args: ["searchChange"] }], items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => BrnComboboxItemToken), { ...{
                            descendants: true,
                        }, isSignal: true }] }], _content: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BrnComboboxContent), { ...{
                            descendants: true,
                        }, isSignal: true }] }] } });

class BrnComboboxPlaceholder {
    _combobox = injectBrnComboboxBase();
    _hasValue = this._combobox.hasValue;
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxPlaceholder, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnComboboxPlaceholder, isStandalone: true, selector: "[brnComboboxPlaceholder]", host: { properties: { "attr.data-hidden": "_hasValue() ? \"\" : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxPlaceholder, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxPlaceholder]',
                    host: {
                        '[attr.data-hidden]': '_hasValue() ? "" : null',
                    },
                }]
        }] });

class BrnComboboxPopoverTrigger {
    _combobox = injectBrnComboboxBase();
    _brnOverlay = inject(BrnOverlay, { optional: true });
    /**
     * Whether clicking the trigger may close an open popover. Button triggers toggle (click again to
     * close); text-input triggers set this to `false` so clicking or typing in an open combobox only
     * ever opens it and never closes it underneath the user.
     */
    closeOnTriggerClickInput = input(true, { ...(ngDevMode ? { debugName: "closeOnTriggerClickInput" } : /* istanbul ignore next */ {}), alias: 'closeOnTriggerClick',
        transform: booleanAttribute });
    /** Writable, input-synced state so the behavior can also be set programmatically. */
    closeOnTriggerClick = linkedSignal(this.closeOnTriggerClickInput, ...(ngDevMode ? [{ debugName: "closeOnTriggerClick" }] : /* istanbul ignore next */ []));
    _onClick() {
        if (this._combobox.disabledState())
            return;
        if (this.closeOnTriggerClick()) {
            this._brnOverlay?.toggle();
        }
        else {
            this._brnOverlay?.open();
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxPopoverTrigger, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnComboboxPopoverTrigger, isStandalone: true, selector: "[brnComboboxPopoverTrigger]", inputs: { closeOnTriggerClickInput: { classPropertyName: "closeOnTriggerClickInput", publicName: "closeOnTriggerClick", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "_onClick()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxPopoverTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxPopoverTrigger]',
                    host: {
                        '(click)': '_onClick()',
                    },
                }]
        }], propDecorators: { closeOnTriggerClickInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnTriggerClick", required: false }] }] } });

class BrnComboboxSeparator {
    orientation = input('horizontal', ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxSeparator, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnComboboxSeparator, isStandalone: true, selector: "[brnComboboxSeparator]", inputs: { orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "separator" }, properties: { "attr.aria-orientation": "orientation()", "attr.data-orientation": "orientation()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxSeparator, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxSeparator]',
                    host: {
                        role: 'separator',
                        '[attr.aria-orientation]': 'orientation()',
                        '[attr.data-orientation]': 'orientation()',
                    },
                }]
        }], propDecorators: { orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }] } });

class BrnComboboxStatus {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxStatus, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnComboboxStatus, isStandalone: true, selector: "[brnComboboxStatus]", host: { attributes: { "role": "status", "aria-live": "polite", "aria-atomic": "true" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxStatus, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxStatus]',
                    host: {
                        role: 'status',
                        'aria-live': 'polite',
                        'aria-atomic': 'true',
                    },
                }]
        }] });

class BrnComboboxTrigger {
    _combobox = injectBrnComboboxBase();
    _isExpanded = this._combobox.isExpanded;
    _disabled = this._combobox.disabledState;
    _isPlaceholder = computed(() => !this._combobox.hasValue(), ...(ngDevMode ? [{ debugName: "_isPlaceholder" }] : /* istanbul ignore next */ []));
    _ariaInvalid = computed(() => this._combobox.controlState?.()?.invalid, ...(ngDevMode ? [{ debugName: "_ariaInvalid" }] : /* istanbul ignore next */ []));
    _dirty = computed(() => this._combobox.controlState?.()?.dirty, ...(ngDevMode ? [{ debugName: "_dirty" }] : /* istanbul ignore next */ []));
    _touched = computed(() => this._combobox.controlState?.()?.touched, ...(ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []));
    _spartanInvalid = computed(() => this.forceInvalid() || this._combobox.controlState?.()?.spartanInvalid, ...(ngDevMode ? [{ debugName: "_spartanInvalid" }] : /* istanbul ignore next */ []));
    forceInvalid = input(false, { ...(ngDevMode ? { debugName: "forceInvalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Listen for keydown events */
    onKeyDown(event) {
        if (!this._combobox.isExpanded() && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
            this._combobox.open();
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxTrigger, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnComboboxTrigger, isStandalone: true, selector: "button[brnComboboxTrigger]", inputs: { forceInvalid: { classPropertyName: "forceInvalid", publicName: "forceInvalid", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "type": "button", "role": "combobox", "aria-haspopup": "dialog" }, listeners: { "keydown": "onKeyDown($event)" }, properties: { "attr.aria-expanded": "_isExpanded() ? \"true\" : \"false\"", "attr.aria-disabled": "_disabled() ? \"true\" : null", "attr.disabled": "_disabled() ? \"\" : null", "attr.data-placeholder": "_isPlaceholder() ? \"\" : null", "attr.aria-invalid": " _ariaInvalid() ? \"true\": null", "attr.data-invalid": " _ariaInvalid() ? \"true\": null", "attr.data-matches-spartan-invalid": " _spartanInvalid() ? \"true\": null", "attr.data-touched": " _touched() ? \"true\": null", "attr.data-dirty": " _dirty() ? \"true\": null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnComboboxTrigger]',
                    host: {
                        type: 'button',
                        role: 'combobox',
                        'aria-haspopup': 'dialog',
                        '[attr.aria-expanded]': '_isExpanded() ? "true" : "false"',
                        '[attr.aria-disabled]': '_disabled() ? "true" : null',
                        '[attr.disabled]': '_disabled() ? "" : null',
                        '[attr.data-placeholder]': '_isPlaceholder() ? "" : null',
                        '[attr.aria-invalid]': ' _ariaInvalid() ? "true": null',
                        '[attr.data-invalid]': ' _ariaInvalid() ? "true": null',
                        '[attr.data-matches-spartan-invalid]': ' _spartanInvalid() ? "true": null',
                        '[attr.data-touched]': ' _touched() ? "true": null',
                        '[attr.data-dirty]': ' _dirty() ? "true": null',
                        '(keydown)': 'onKeyDown($event)',
                    },
                }]
        }], propDecorators: { forceInvalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceInvalid", required: false }] }] } });

class BrnComboboxValue {
    _combobox = injectBrnComboboxBase();
    placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    _isPlaceholder = computed(() => !this._combobox.hasValue(), ...(ngDevMode ? [{ debugName: "_isPlaceholder" }] : /* istanbul ignore next */ []));
    hidden = computed(() => !this._combobox.hasValue() && !this.placeholder(), ...(ngDevMode ? [{ debugName: "hidden" }] : /* istanbul ignore next */ []));
    _value = computed(() => {
        return this._combobox.hasValue()
            ? stringifyAsLabel(this._combobox.value(), this._combobox.itemToString())
            : this.placeholder();
    }, ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxValue, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnComboboxValue, isStandalone: true, selector: "[brnComboboxValue]", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.data-placeholder": "_isPlaceholder() ? \"\" : null", "attr.data-hidden": "hidden() ? \"\" : null", "textContent": "_value()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxValue, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxValue]',
                    host: {
                        '[attr.data-placeholder]': '_isPlaceholder() ? "" : null',
                        '[attr.data-hidden]': 'hidden() ? "" : null',
                        '[textContent]': '_value()',
                    },
                }]
        }], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }] } });

class BrnComboboxValueTemplate {
    _templateRef = inject(TemplateRef);
    _viewContainerRef = inject(ViewContainerRef);
    _combobox = injectBrnComboboxBase();
    _value = computed(() => {
        const value = this._combobox.value();
        if (value === null) {
            return null;
        }
        return value;
    }, ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const value = this._value();
            if (value !== null) {
                this._viewContainerRef.clear();
                this._viewContainerRef.createEmbeddedView(this._templateRef, {
                    $implicit: value,
                });
            }
            else {
                this._viewContainerRef.clear();
            }
        });
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxValueTemplate, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnComboboxValueTemplate, isStandalone: true, selector: "[brnComboboxValueTemplate]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxValueTemplate, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxValueTemplate]',
                }]
        }], ctorParameters: () => [] });

class BrnComboboxValues {
    _templateRef = inject((TemplateRef));
    _viewContainerRef = inject(ViewContainerRef);
    _combobox = injectBrnComboboxBase();
    _values = computed(() => {
        const values = this._combobox.value();
        if (values === null || values === undefined) {
            return null;
        }
        return Array.isArray(values) ? values : [values];
    }, ...(ngDevMode ? [{ debugName: "_values" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const values = this._values();
            if (values?.length) {
                this._viewContainerRef.clear();
                this._viewContainerRef.createEmbeddedView(this._templateRef, {
                    $implicit: values,
                });
            }
            else {
                this._viewContainerRef.clear();
            }
        });
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxValues, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnComboboxValues, isStandalone: true, selector: "[brnComboboxValues]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnComboboxValues, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnComboboxValues]',
                }]
        }], ctorParameters: () => [] });

const BrnComboboxImports = [
    BrnCombobox,
    BrnComboboxAnchor,
    BrnComboboxChip,
    BrnComboboxChipInput,
    BrnComboboxChipRemove,
    BrnComboboxClear,
    BrnComboboxContent,
    BrnComboboxEmpty,
    BrnComboboxGroup,
    BrnComboboxInput,
    BrnComboboxItem,
    BrnComboboxLabel,
    BrnComboboxList,
    BrnComboboxMultiple,
    BrnComboboxPlaceholder,
    BrnComboboxPopoverTrigger,
    BrnComboboxSeparator,
    BrnComboboxStatus,
    BrnComboboxTrigger,
    BrnComboboxValue,
    BrnComboboxValueTemplate,
    BrnComboboxValues,
];

/**
 * Generated bundle index. Do not edit.
 */

export { BRN_COMBOBOX_MULTIPLE_VALUE_ACCESSOR, BRN_COMBOBOX_VALUE_ACCESSOR, BrnCombobox, BrnComboboxAnchor, BrnComboboxBaseToken, BrnComboboxChip, BrnComboboxChipInput, BrnComboboxChipRemove, BrnComboboxClear, BrnComboboxContent, BrnComboboxEmpty, BrnComboboxGroup, BrnComboboxImports, BrnComboboxInput, BrnComboboxItem, BrnComboboxItemToken, BrnComboboxLabel, BrnComboboxList, BrnComboboxMultiple, BrnComboboxPlaceholder, BrnComboboxPopoverTrigger, BrnComboboxSeparator, BrnComboboxStatus, BrnComboboxTrigger, BrnComboboxValue, BrnComboboxValueTemplate, BrnComboboxValues, comboboxContainsFilter, comboboxEndsWithFilter, comboboxStartsWithFilter, injectBrnComboboxBase, injectBrnComboboxConfig, provideBrnComboboxBase, provideBrnComboboxConfig, provideBrnComboboxItem };
//# sourceMappingURL=spartan-ng-brain-combobox.mjs.map
