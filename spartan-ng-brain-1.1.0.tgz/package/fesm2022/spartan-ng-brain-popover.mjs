import * as i0 from '@angular/core';
import { InjectionToken, inject, input, numberAttribute, forwardRef, Directive, ElementRef } from '@angular/core';
import { defaultOptions, BrnOverlay, provideBrnOverlayDefaultOptions, BrnOverlayContent, BrnOverlayTrigger } from '@spartan-ng/brain/overlay';
import { provideExposesStateProviderExisting } from '@spartan-ng/brain/core';

const defaultConfig = {
    align: 'center',
    sideOffset: 0,
    offsetX: 0,
};
const BrnPopoverConfigToken = new InjectionToken('BrnPopoverConfig');
function provideBrnPopoverConfig(config) {
    return { provide: BrnPopoverConfigToken, useValue: { ...defaultConfig, ...config } };
}
function injectBrnPopoverConfig() {
    return inject(BrnPopoverConfigToken, { optional: true }) ?? defaultConfig;
}
const BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS = {
    ...defaultOptions,
    autoFocus: true,
    closeOnOutsidePointerEvents: true,
    hasBackdrop: false,
    role: 'dialog',
    scrollStrategy: 'reposition',
};
const BRN_POPOVER_DEFAULT_OPTIONS = new InjectionToken('brn-popover-default-options', {
    providedIn: 'root',
    factory: () => BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS,
});
function provideBrnPopoverDefaultOptions(options) {
    return {
        provide: BRN_POPOVER_DEFAULT_OPTIONS,
        useValue: { ...BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS, ...options },
    };
}
function injectBrnPopoverDefaultOptions() {
    return inject(BRN_POPOVER_DEFAULT_OPTIONS, { optional: true }) ?? BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS;
}

/** @deprecated Use `BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS`. */
const BRN_POPOVER_DIALOG_DEFAULT_OPTIONS = BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS;
class BrnPopover extends BrnOverlay {
    _config = injectBrnPopoverConfig();
    align = input(this._config.align, ...(ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []));
    sideOffset = input(this._config.sideOffset, { ...(ngDevMode ? { debugName: "sideOffset" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    offsetX = input(this._config.offsetX, { ...(ngDevMode ? { debugName: "offsetX" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    getDefaultOptions() {
        return injectBrnPopoverDefaultOptions();
    }
    getAttachPositions() {
        const align = this.align();
        const sideOffset = this.sideOffset();
        const offsetX = this.offsetX();
        return [
            {
                originX: align,
                originY: 'bottom',
                overlayX: align,
                overlayY: 'top',
                offsetX,
                offsetY: sideOffset,
            },
            {
                originX: align,
                originY: 'top',
                overlayX: align,
                overlayY: 'bottom',
                offsetX,
                offsetY: -sideOffset,
            },
        ];
    }
    getPositionStrategy() {
        const attachTo = this.getAttachTo();
        if (!attachTo)
            return super.getPositionStrategy();
        return this._positionBuilder.flexibleConnectedTo(attachTo).withPositions(this.getAttachPositions()).withPush(false);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnPopover, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnPopover, isStandalone: true, selector: "[brnPopover],brn-popover", inputs: { align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null }, sideOffset: { classPropertyName: "sideOffset", publicName: "sideOffset", isSignal: true, isRequired: false, transformFunction: null }, offsetX: { classPropertyName: "offsetX", publicName: "offsetX", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: BrnOverlay,
                useExisting: forwardRef((() => BrnPopover)),
            },
            provideBrnOverlayDefaultOptions(BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS),
        ], exportAs: ["brnPopover"], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnPopover, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnPopover],brn-popover',
                    exportAs: 'brnPopover',
                    providers: [
                        {
                            provide: BrnOverlay,
                            useExisting: forwardRef((() => BrnPopover)),
                        },
                        provideBrnOverlayDefaultOptions(BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS),
                    ],
                }]
        }], propDecorators: { align: [{ type: i0.Input, args: [{ isSignal: true, alias: "align", required: false }] }], sideOffset: [{ type: i0.Input, args: [{ isSignal: true, alias: "sideOffset", required: false }] }], offsetX: [{ type: i0.Input, args: [{ isSignal: true, alias: "offsetX", required: false }] }] } });

class BrnPopoverContent extends BrnOverlayContent {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnPopoverContent, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnPopoverContent, isStandalone: true, selector: "[brnPopoverContent]", providers: [provideExposesStateProviderExisting((() => BrnPopoverContent))], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnPopoverContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnPopoverContent]',
                    providers: [provideExposesStateProviderExisting((() => BrnPopoverContent))],
                }]
        }] });

class BrnPopoverTrigger extends BrnOverlayTrigger {
    _host = inject(ElementRef, { host: true });
    brnPopoverTriggerFor = input(undefined, ...(ngDevMode ? [{ debugName: "brnPopoverTriggerFor" }] : /* istanbul ignore next */ []));
    getOverlay() {
        return this.brnPopoverTriggerFor() ?? super.getOverlay();
    }
    open() {
        const popover = this.getOverlay();
        if (!popover)
            return;
        popover.setOrigin(this._host.nativeElement);
        popover.open();
    }
    toggle() {
        const popover = this.getOverlay();
        if (!popover)
            return;
        popover.setOrigin(this._host.nativeElement);
        popover.toggle();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnPopoverTrigger, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnPopoverTrigger, isStandalone: true, selector: "button[brnPopoverTrigger],button[brnPopoverTriggerFor]", inputs: { brnPopoverTriggerFor: { classPropertyName: "brnPopoverTriggerFor", publicName: "brnPopoverTriggerFor", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "aria-haspopup": "dialog" }, properties: { "id": "id()", "attr.aria-expanded": "state() === 'open' ? 'true': 'false'", "attr.data-state": "state()", "attr.aria-controls": "overlayId()", "type": "type()" } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnPopoverTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnPopoverTrigger],button[brnPopoverTriggerFor]',
                    host: {
                        '[id]': 'id()',
                        'aria-haspopup': 'dialog',
                        '[attr.aria-expanded]': "state() === 'open' ? 'true': 'false'",
                        '[attr.data-state]': 'state()',
                        '[attr.aria-controls]': 'overlayId()',
                        '[type]': 'type()',
                    },
                }]
        }], propDecorators: { brnPopoverTriggerFor: [{ type: i0.Input, args: [{ isSignal: true, alias: "brnPopoverTriggerFor", required: false }] }] } });

const BrnPopoverImports = [BrnPopover, BrnPopoverTrigger, BrnPopoverContent];

/**
 * Generated bundle index. Do not edit.
 */

export { BRN_POPOVER_DIALOG_DEFAULT_OPTIONS, BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS, BrnPopover, BrnPopoverContent, BrnPopoverImports, BrnPopoverTrigger, injectBrnPopoverConfig, injectBrnPopoverDefaultOptions, provideBrnPopoverConfig, provideBrnPopoverDefaultOptions };
//# sourceMappingURL=spartan-ng-brain-popover.mjs.map
