import * as i0 from '@angular/core';
import { signal, computed, Injectable, input, booleanAttribute, Directive, InjectionToken, inject, Injector, DestroyRef } from '@angular/core';
import { NgForm, FormGroupDirective, NgControl } from '@angular/forms';
import { ErrorStateMatcher, createStateTracker } from '@spartan-ng/brain/forms';

class BrnFieldA11yService {
    _descriptions = signal([], ...(ngDevMode ? [{ debugName: "_descriptions" }] : /* istanbul ignore next */ []));
    _errors = signal([], ...(ngDevMode ? [{ debugName: "_errors" }] : /* istanbul ignore next */ []));
    describedBy = computed(() => {
        const ids = [...this._descriptions(), ...this._errors()].filter(Boolean);
        const uniqueIds = [...new Set(ids)];
        return uniqueIds.length ? uniqueIds.join(' ') : null;
    }, ...(ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []));
    registerDescription(id) {
        this._descriptions.update((ids) => (ids.includes(id) ? ids : [...ids, id]));
    }
    unregisterDescription(id) {
        this._descriptions.update((ids) => ids.filter((value) => value !== id));
    }
    registerError(id) {
        this._errors.update((ids) => (ids.includes(id) ? ids : [...ids, id]));
    }
    unregisterError(id) {
        this._errors.update((ids) => ids.filter((value) => value !== id));
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnFieldA11yService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    /** @nocollapse */ static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnFieldA11yService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnFieldA11yService, decorators: [{
            type: Injectable
        }] });

class BrnField {
    _brnFieldControl = signal(null, ...(ngDevMode ? [{ debugName: "_brnFieldControl" }] : /* istanbul ignore next */ []));
    _labelable = signal(null, ...(ngDevMode ? [{ debugName: "_labelable" }] : /* istanbul ignore next */ []));
    /** Whether the field is invalid. Overrides the `data-invalid` attribute. */
    dataInvalid = input(false, { ...(ngDevMode ? { debugName: "dataInvalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute,
        alias: 'data-invalid' });
    /**
     * Whether to force the field into an invalid state, regardless of the form control's state.
     * Overrides both the `data-invalid` and `data-matches-spartan-invalid` attributes.
     */
    forceInvalid = input(false, { ...(ngDevMode ? { debugName: "forceInvalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _invalid = computed(() => {
        if (this.forceInvalid() || this.dataInvalid())
            return true;
        const control = this._brnFieldControl();
        if (!control || !control.ngControl)
            return false;
        return control.controlState()?.invalid;
    }, ...(ngDevMode ? [{ debugName: "_invalid" }] : /* istanbul ignore next */ []));
    _spartanInvalid = computed(() => {
        return this.forceInvalid() || (this._brnFieldControl()?.controlState()?.spartanInvalid ?? null);
    }, ...(ngDevMode ? [{ debugName: "_spartanInvalid" }] : /* istanbul ignore next */ []));
    _dirty = computed(() => {
        return this._brnFieldControl()?.controlState()?.dirty ?? null;
    }, ...(ngDevMode ? [{ debugName: "_dirty" }] : /* istanbul ignore next */ []));
    _touched = computed(() => {
        return this._brnFieldControl()?.controlState()?.touched ?? null;
    }, ...(ngDevMode ? [{ debugName: "_touched" }] : /* istanbul ignore next */ []));
    labelableId = computed(() => this._labelable()?.labelableId(), ...(ngDevMode ? [{ debugName: "labelableId" }] : /* istanbul ignore next */ []));
    brnFieldControl = this._brnFieldControl.asReadonly();
    errors = computed(() => this._brnFieldControl()?.errors() ?? null, ...(ngDevMode ? [{ debugName: "errors" }] : /* istanbul ignore next */ []));
    controlState = computed(() => this._brnFieldControl()?.controlState() ?? null, ...(ngDevMode ? [{ debugName: "controlState" }] : /* istanbul ignore next */ []));
    registerFieldControl(fieldControl) {
        if (this._brnFieldControl())
            return;
        this._brnFieldControl.set(fieldControl);
    }
    registerLabelable(labelable) {
        if (this._labelable())
            return;
        this._labelable.set(labelable);
    }
    unregisterFieldControl(fieldControl) {
        if (this._brnFieldControl() !== fieldControl)
            return;
        this._brnFieldControl.set(null);
    }
    unregisterLabelable(labelable) {
        if (this._labelable() !== labelable)
            return;
        this._labelable.set(null);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnField, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnField, isStandalone: true, selector: "[brnField],brn-field", inputs: { dataInvalid: { classPropertyName: "dataInvalid", publicName: "data-invalid", isSignal: true, isRequired: false, transformFunction: null }, forceInvalid: { classPropertyName: "forceInvalid", publicName: "forceInvalid", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.data-invalid": "_invalid() ? \"true\" : null", "attr.data-matches-spartan-invalid": "_spartanInvalid() ? \"true\" : null", "attr.data-touched": "_touched() ? \"true\" : null", "attr.data-dirty": "_dirty() ? \"true\" : null" } }, providers: [BrnFieldA11yService], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnField, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnField],brn-field',
                    providers: [BrnFieldA11yService],
                    host: {
                        '[attr.data-invalid]': '_invalid() ? "true" : null',
                        '[attr.data-matches-spartan-invalid]': '_spartanInvalid() ? "true" : null',
                        '[attr.data-touched]': '_touched() ? "true" : null',
                        '[attr.data-dirty]': '_dirty() ? "true" : null',
                    },
                }]
        }], propDecorators: { dataInvalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "data-invalid", required: false }] }], forceInvalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceInvalid", required: false }] }] } });

const BrnLabelable = new InjectionToken('BrnLabelable');
function provideBrnLabelable(labelable) {
    return { provide: BrnLabelable, useExisting: labelable };
}
function injectBrnLabelable() {
    return inject(BrnLabelable, { optional: true });
}

class BrnFieldControl {
    _injector = inject(Injector);
    _errorStateMatcher = inject(ErrorStateMatcher);
    _parentForm = inject(NgForm, { optional: true });
    _parentFormGroup = inject(FormGroupDirective, { optional: true });
    _field = inject(BrnField, { optional: true });
    _destroyRef = inject(DestroyRef);
    _labelable = null;
    _parentFieldControl = null;
    _stateTracker = signal(null, ...(ngDevMode ? [{ debugName: "_stateTracker" }] : /* istanbul ignore next */ []));
    /** Sentinel value to differentiate "never checked" from "control is null". */
    _lastControl = null;
    /** Gets the AbstractControlDirective for this control. */
    ngControl = null;
    controlState = computed(() => this._stateTracker()?.controlState() ?? null, ...(ngDevMode ? [{ debugName: "controlState" }] : /* istanbul ignore next */ []));
    errors = computed(() => this._stateTracker()?.errors() ?? null, ...(ngDevMode ? [{ debugName: "errors" }] : /* istanbul ignore next */ []));
    dirty = computed(() => this._stateTracker()?.dirty() ?? null, ...(ngDevMode ? [{ debugName: "dirty" }] : /* istanbul ignore next */ []));
    invalid = computed(() => this._stateTracker()?.invalid() ?? null, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    spartanInvalid = computed(() => this._stateTracker()?.spartanInvalid() ?? null, ...(ngDevMode ? [{ debugName: "spartanInvalid" }] : /* istanbul ignore next */ []));
    touched = computed(() => this._stateTracker()?.touched() ?? null, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
    constructor() {
        this._destroyRef.onDestroy(() => {
            this._field?.unregisterFieldControl(this);
            if (this._labelable) {
                this._field?.unregisterLabelable(this._labelable);
            }
            this._stateTracker()?.destroy();
        });
    }
    ngOnInit() {
        this.ngControl = this._injector.get(NgControl, null);
        this._parentFieldControl = this._injector.get(BrnFieldControl, null, { skipSelf: true });
        if (this.ngControl) {
            this._field?.registerFieldControl(this);
        }
        // Try to sync the tracker eagerly.
        this._syncTracker();
        // For template-driven forms and FormControlName, the control is often resolved
        // asynchronously by Angular's directives after our ngOnInit/ngDoCheck.
        // Schedule a one-time microtask to catch the initial resolution.
        if (this.ngControl) {
            Promise.resolve().then(() => {
                this._syncTracker();
            });
        }
        this._labelable = this._injector.get(BrnLabelable, null);
        if (this._labelable) {
            this._field?.registerLabelable(this._labelable);
        }
    }
    // Re-evaluate the control reference on every change detection cycle because
    // the underlying AbstractControl may change when [formControl] rebinds to a new instance.
    // When the instance changes we tear down the old tracker and create a fresh one.
    ngDoCheck() {
        this._syncTracker();
    }
    /** @returns true if the control reference changed */
    _syncTracker() {
        if (!this.ngControl || this._hasFieldControlParent())
            return;
        const currentControl = this.ngControl.control ?? null;
        if (currentControl === this._lastControl)
            return;
        this._lastControl = currentControl;
        this._stateTracker()?.destroy();
        this._stateTracker.set(currentControl
            ? createStateTracker(this.ngControl, this._errorStateMatcher, this._parentFormGroup, this._parentForm)
            : null);
    }
    _hasFieldControlParent() {
        if (this._field) {
            return this._field.brnFieldControl() !== this;
        }
        return !!this._parentFieldControl?.ngControl && this._parentFieldControl.ngControl === this.ngControl;
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnFieldControl, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnFieldControl, isStandalone: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnFieldControl, decorators: [{
            type: Directive
        }], ctorParameters: () => [] });

class BrnFieldControlDescribedBy {
    describedBy = input(null, { ...(ngDevMode ? { debugName: "describedBy" } : /* istanbul ignore next */ {}), alias: 'aria-describedby' });
    _a11y = inject(BrnFieldA11yService, { optional: true });
    _computedDescribedBy = computed(() => {
        const manual = this.describedBy();
        const manualList = manual ? manual.split(/\s+/).filter(Boolean) : [];
        const fieldIds = this._a11y?.describedBy() ?? null;
        const fieldList = fieldIds ? fieldIds.split(/\s+/).filter(Boolean) : [];
        const combined = [...new Set([...manualList, ...fieldList])];
        return combined.length ? combined.join(' ') : null;
    }, ...(ngDevMode ? [{ debugName: "_computedDescribedBy" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnFieldControlDescribedBy, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnFieldControlDescribedBy, isStandalone: true, selector: "[brnFieldControlDescribedBy]", inputs: { describedBy: { classPropertyName: "describedBy", publicName: "aria-describedby", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.aria-describedby": "_computedDescribedBy()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnFieldControlDescribedBy, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnFieldControlDescribedBy]',
                    host: {
                        '[attr.aria-describedby]': '_computedDescribedBy()',
                    },
                }]
        }], propDecorators: { describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "aria-describedby", required: false }] }] } });

const BrnFieldImports = [BrnField, BrnFieldControl, BrnFieldControlDescribedBy];

/**
 * Generated bundle index. Do not edit.
 */

export { BrnField, BrnFieldA11yService, BrnFieldControl, BrnFieldControlDescribedBy, BrnFieldImports, BrnLabelable, injectBrnLabelable, provideBrnLabelable };
//# sourceMappingURL=spartan-ng-brain-field.mjs.map
