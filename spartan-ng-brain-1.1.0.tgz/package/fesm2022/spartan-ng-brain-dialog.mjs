import { Directionality } from '@angular/cdk/bidi';
import { OverlayOutsideClickDispatcher, OverlayPositionBuilder, ScrollStrategyOptions } from '@angular/cdk/overlay';
import * as i0 from '@angular/core';
import { InjectionToken, inject, signal, computed, afterNextRender, Injector, ElementRef, Injectable, DestroyRef, ViewContainerRef, output, input, booleanAttribute, effect, untracked, Directive, TemplateRef } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { cssClassesToArray, waitForAnimations, getActiveElementAnimations, provideExposesStateProviderExisting, provideCustomClassSettableExisting } from '@spartan-ng/brain/core';
export { cssClassesToArray } from '@spartan-ng/brain/core';
import { DIALOG_DATA, Dialog } from '@angular/cdk/dialog';
import { takeUntil, filter } from 'rxjs/operators';
import { Subject, ReplaySubject } from 'rxjs';

const defaultOptions = {
    ariaDescribedBy: undefined,
    ariaLabel: undefined,
    ariaLabelledBy: undefined,
    ariaModal: true,
    attachPositions: [],
    attachTo: null,
    autoFocus: 'first-tabbable',
    backdropClass: '',
    closeOnOutsidePointerEvents: false,
    disableClose: false,
    hasBackdrop: true,
    panelClass: '',
    positionStrategy: null,
    restoreFocus: true,
    role: 'dialog',
    scrollStrategy: null,
};
const BRN_DIALOG_DEFAULT_OPTIONS = new InjectionToken('brn-dialog-default-options', {
    providedIn: 'root',
    factory: () => defaultOptions,
});
function provideBrnDialogDefaultOptions(options) {
    return { provide: BRN_DIALOG_DEFAULT_OPTIONS, useValue: { ...defaultOptions, ...options } };
}
function injectBrnDialogDefaultOptions() {
    return inject(BRN_DIALOG_DEFAULT_OPTIONS, { optional: true }) ?? defaultOptions;
}

class BrnDialogRef {
    _cdkDialogRef;
    _injector;
    dialogId;
    initialOptions;
    _closing = new Subject();
    closing$ = this._closing.asObservable();
    _closed = new ReplaySubject(1);
    closed$ = this._closed.asObservable();
    _stateChanged = new ReplaySubject(1);
    stateChanged$ = this._stateChanged.asObservable();
    _phase = signal('open', ...(ngDevMode ? [{ debugName: "_phase" }] : /* istanbul ignore next */ []));
    phase = this._phase.asReadonly();
    state = computed(() => (this._phase() === 'open' ? 'open' : 'closed'), ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    _closeGeneration = 0;
    _panelClasses;
    _backdropClasses;
    get open() {
        return this._phase() === 'open';
    }
    get id() {
        return this.initialOptions.id;
    }
    constructor(_cdkDialogRef, _injector, dialogId, initialOptions) {
        this._cdkDialogRef = _cdkDialogRef;
        this._injector = _injector;
        this.dialogId = dialogId;
        this.initialOptions = initialOptions;
        this._panelClasses = cssClassesToArray(initialOptions.panelClass);
        this._backdropClasses = cssClassesToArray(initialOptions.backdropClass);
        this._setDataState('open');
        this._stateChanged.next('open');
        this._cdkDialogRef.closed.subscribe((result) => {
            this._phase.set('closed');
            this._closed.next(result);
            this._closed.complete();
            this._closing.complete();
            this._stateChanged.complete();
        });
    }
    close(result) {
        if (!this.open)
            return;
        const generation = ++this._closeGeneration;
        const animationsBeforeClose = new Set(this._getActiveAnimations());
        this._phase.set('closing');
        this._setDataState('closed');
        this._closing.next();
        this._stateChanged.next('closed');
        afterNextRender(() => {
            void this._finishClose(generation, animationsBeforeClose, result);
        }, { injector: this._injector });
    }
    dismiss(reason) {
        const options = this.initialOptions;
        if (!this.open || options.disableClose)
            return false;
        if (reason === 'outside' && !options.closeOnOutsidePointerEvents)
            return false;
        this.close();
        return true;
    }
    reopen() {
        if (this._phase() !== 'closing')
            return;
        this._closeGeneration++;
        this._phase.set('open');
        this._setDataState('open');
        this._stateChanged.next('open');
    }
    forceClose(result) {
        if (this._phase() === 'closed')
            return;
        this._closeGeneration++;
        this._phase.set('closed');
        this._cdkDialogRef.close(result);
    }
    setPanelClass(panelClass) {
        if (this._panelClasses.length)
            this._cdkDialogRef.removePanelClass(this._panelClasses);
        this._panelClasses = cssClassesToArray(panelClass);
        if (this._panelClasses.length)
            this._cdkDialogRef.addPanelClass(this._panelClasses);
    }
    setOverlayClass(overlayClass) {
        const backdrop = this._cdkDialogRef.overlayRef.backdropElement;
        if (!backdrop)
            return;
        backdrop.classList.remove(...this._backdropClasses);
        this._backdropClasses = cssClassesToArray(overlayClass);
        backdrop.classList.add(...this._backdropClasses);
    }
    updatePosition() {
        this._cdkDialogRef.updatePosition();
    }
    async _finishClose(generation, animationsBeforeClose, result) {
        if (generation !== this._closeGeneration || this._phase() !== 'closing')
            return;
        const exitAnimations = this._getActiveAnimations().filter((animation) => !animationsBeforeClose.has(animation));
        // Pin each exit animation to its final frame. tw-animate-css uses `animation-fill-mode: none`,
        // so a finished exit reverts the element to its visible state in the gap before we dispose it -
        // that one-frame snap-back is the flicker. updateTiming pins only the animations we await.
        for (const animation of exitAnimations) {
            animation.effect?.updateTiming({ fill: 'forwards' });
        }
        await waitForAnimations(exitAnimations);
        if (generation === this._closeGeneration && this._phase() === 'closing') {
            this._phase.set('closed');
            this._cdkDialogRef.close(result);
        }
    }
    _getActiveAnimations() {
        return getActiveElementAnimations([
            this._cdkDialogRef.overlayRef.overlayElement,
            this._cdkDialogRef.overlayRef.backdropElement,
        ]);
    }
    _setDataState(state) {
        this._cdkDialogRef.overlayRef.overlayElement.setAttribute('data-state', state);
        this._cdkDialogRef.overlayRef.backdropElement?.setAttribute('data-state', state);
    }
}

let dialogSequence = 0;
const injectBrnDialogContext = (options = {}) => inject(DIALOG_DATA, options);
class BrnDialogService {
    _overlayCloseDispatcher = inject(OverlayOutsideClickDispatcher);
    _cdkDialog = inject(Dialog);
    _positionBuilder = inject(OverlayPositionBuilder);
    _scrollStrategies = inject(ScrollStrategyOptions);
    _injector = inject(Injector);
    _defaultOptions = injectBrnDialogDefaultOptions();
    open(content, vcr, context, options) {
        const dialogId = ++dialogSequence;
        const mergedOptions = {
            ...this._defaultOptions,
            ...options,
            id: options?.id ?? `brn-dialog-${dialogId}`,
        };
        if (this._cdkDialog.getDialogById(mergedOptions.id)) {
            throw new Error(`Dialog with ID: ${mergedOptions.id} already exists`);
        }
        const positionStrategy = mergedOptions.positionStrategy ??
            (mergedOptions.attachTo && mergedOptions.attachPositions.length
                ? this._positionBuilder.flexibleConnectedTo(mergedOptions.attachTo).withPositions(mergedOptions.attachPositions)
                : this._positionBuilder.global().centerHorizontally().centerVertically());
        const scrollStrategy = mergedOptions.scrollStrategy === 'close'
            ? this._scrollStrategies.close()
            : mergedOptions.scrollStrategy === 'reposition'
                ? this._scrollStrategies.reposition()
                : (mergedOptions.scrollStrategy ?? this._scrollStrategies.block());
        let brnDialogRef;
        const contextOrData = {
            ...context,
            close: (result = undefined) => brnDialogRef.close(result),
        };
        const cdkDialogRef = this._cdkDialog.open(content, {
            id: mergedOptions.id,
            role: mergedOptions.role,
            viewContainerRef: vcr,
            templateContext: () => ({ $implicit: contextOrData }),
            data: contextOrData,
            direction: mergedOptions.direction,
            hasBackdrop: mergedOptions.hasBackdrop,
            panelClass: mergedOptions.panelClass,
            backdropClass: mergedOptions.backdropClass,
            positionStrategy,
            scrollStrategy,
            restoreFocus: mergedOptions.restoreFocus,
            disableClose: true,
            autoFocus: mergedOptions.autoFocus,
            ariaDescribedBy: mergedOptions.ariaDescribedBy === undefined
                ? `brn-dialog-description-${dialogId}`
                : mergedOptions.ariaDescribedBy,
            ariaLabelledBy: mergedOptions.ariaLabelledBy === undefined ? `brn-dialog-title-${dialogId}` : mergedOptions.ariaLabelledBy,
            ariaLabel: mergedOptions.ariaLabel,
            ariaModal: mergedOptions.ariaModal,
            providers: (dialogRef) => {
                brnDialogRef = new BrnDialogRef(dialogRef, this._injector, dialogId, mergedOptions);
                return this._createProviders(brnDialogRef, mergedOptions);
            },
        });
        this._connectDismissalEvents(brnDialogRef, cdkDialogRef.overlayRef);
        return brnDialogRef;
    }
    _createProviders(dialogRef, options) {
        const providers = [{ provide: BrnDialogRef, useValue: dialogRef }];
        if (options.providers) {
            providers.push(...(typeof options.providers === 'function' ? options.providers() : options.providers));
        }
        return providers;
    }
    _connectDismissalEvents(dialogRef, overlayRef) {
        const closed$ = dialogRef.closed$;
        overlayRef
            .outsidePointerEvents()
            .pipe(takeUntil(closed$))
            .subscribe(() => {
            if (this._isTopmostOutsideTarget(overlayRef))
                dialogRef.dismiss('outside');
        });
        overlayRef
            .backdropClick()
            .pipe(takeUntil(closed$))
            .subscribe(() => dialogRef.dismiss('backdrop'));
        overlayRef
            .keydownEvents()
            .pipe(filter((event) => event.key === 'Escape'), takeUntil(closed$))
            .subscribe((event) => {
            if (this._overlayCloseDispatcher._attachedOverlays.at(-1) !== overlayRef)
                return;
            if (dialogRef.dismiss('escape'))
                event.preventDefault();
        });
    }
    _isTopmostOutsideTarget(overlayRef) {
        const overlays = this._overlayCloseDispatcher._attachedOverlays;
        const index = overlays.indexOf(overlayRef);
        return index === overlays.length - 1 || (overlays.length > 1 && !this._isNested(overlayRef, overlays.at(-1)));
    }
    _isNested(parent, child) {
        const childOrigin = child.getConfig().positionStrategy._origin;
        if (!childOrigin)
            return false;
        if ('x' in childOrigin && 'y' in childOrigin) {
            const rect = parent.hostElement.getBoundingClientRect();
            return (childOrigin.x >= rect.left &&
                childOrigin.x <= rect.right &&
                childOrigin.y >= rect.top &&
                childOrigin.y <= rect.bottom);
        }
        const element = childOrigin instanceof ElementRef ? childOrigin.nativeElement : childOrigin;
        return typeof Node !== 'undefined' && element instanceof Node ? parent.hostElement.contains(element) : false;
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    /** @nocollapse */ static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

let dialogIdSequence = 0;
class BrnDialog {
    _dialogService = inject(BrnDialogService);
    _destroyRef = inject(DestroyRef);
    _vcr = inject(ViewContainerRef);
    _positionBuilder = inject(OverlayPositionBuilder);
    _scrollStrategies = inject(ScrollStrategyOptions);
    _injector = inject(Injector);
    _directionality = inject(Directionality);
    _defaultOptions = injectBrnDialogDefaultOptions();
    _dialogRef = signal(undefined, ...(ngDevMode ? [{ debugName: "_dialogRef" }] : /* istanbul ignore next */ []));
    _origin = signal(undefined, ...(ngDevMode ? [{ debugName: "_origin" }] : /* istanbul ignore next */ []));
    _panelClass = signal(undefined, ...(ngDevMode ? [{ debugName: "_panelClass" }] : /* istanbul ignore next */ []));
    _backdropClass = signal(undefined, ...(ngDevMode ? [{ debugName: "_backdropClass" }] : /* istanbul ignore next */ []));
    _content;
    _destroyed = false;
    _overlayClass;
    _resolvedBackdropClass = computed(() => this._backdropClass() ?? this._overlayClass?.() ?? this._defaultOptions.backdropClass, ...(ngDevMode ? [{ debugName: "_resolvedBackdropClass" }] : /* istanbul ignore next */ []));
    _resolvedPanelClass = computed(() => this._panelClass() ?? this._content?.panelClass() ?? this._defaultOptions.panelClass, ...(ngDevMode ? [{ debugName: "_resolvedPanelClass" }] : /* istanbul ignore next */ []));
    closed = output();
    stateChanged = output();
    stateComputed = computed(() => this._dialogRef()?.state() ?? 'closed', ...(ngDevMode ? [{ debugName: "stateComputed" }] : /* istanbul ignore next */ []));
    id = input(`brn-dialog-${++dialogIdSequence}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    state = input(null, ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    role = input(this._defaultOptions.role, ...(ngDevMode ? [{ debugName: "role" }] : /* istanbul ignore next */ []));
    hasBackdrop = input(this._defaultOptions.hasBackdrop, { ...(ngDevMode ? { debugName: "hasBackdrop" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    positionStrategy = input(this._defaultOptions.positionStrategy, ...(ngDevMode ? [{ debugName: "positionStrategy" }] : /* istanbul ignore next */ []));
    scrollStrategy = input(this._defaultOptions.scrollStrategy, ...(ngDevMode ? [{ debugName: "scrollStrategy" }] : /* istanbul ignore next */ []));
    restoreFocus = input(this._defaultOptions.restoreFocus, ...(ngDevMode ? [{ debugName: "restoreFocus" }] : /* istanbul ignore next */ []));
    closeOnOutsidePointerEvents = input(this._defaultOptions.closeOnOutsidePointerEvents, { ...(ngDevMode ? { debugName: "closeOnOutsidePointerEvents" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    attachTo = input(this._defaultOptions.attachTo, ...(ngDevMode ? [{ debugName: "attachTo" }] : /* istanbul ignore next */ []));
    attachPositions = input(this._defaultOptions.attachPositions, ...(ngDevMode ? [{ debugName: "attachPositions" }] : /* istanbul ignore next */ []));
    autoFocus = input(this._defaultOptions.autoFocus, ...(ngDevMode ? [{ debugName: "autoFocus" }] : /* istanbul ignore next */ []));
    disableClose = input(this._defaultOptions.disableClose, { ...(ngDevMode ? { debugName: "disableClose" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaDescribedBy = input(this._defaultOptions.ariaDescribedBy, { ...(ngDevMode ? { debugName: "ariaDescribedBy" } : /* istanbul ignore next */ {}), alias: 'aria-describedby' });
    ariaLabelledBy = input(this._defaultOptions.ariaLabelledBy, { ...(ngDevMode ? { debugName: "ariaLabelledBy" } : /* istanbul ignore next */ {}), alias: 'aria-labelledby' });
    ariaLabel = input(this._defaultOptions.ariaLabel, { ...(ngDevMode ? { debugName: "ariaLabel" } : /* istanbul ignore next */ {}), alias: 'aria-label' });
    ariaModal = input(this._defaultOptions.ariaModal, { ...(ngDevMode ? { debugName: "ariaModal" } : /* istanbul ignore next */ {}), alias: 'aria-modal',
        transform: booleanAttribute });
    _options = computed(() => ({
        id: this.id(),
        role: this.role(),
        direction: this._directionality.valueSignal(),
        hasBackdrop: this.hasBackdrop(),
        positionStrategy: this.getPositionStrategy(),
        scrollStrategy: this.getScrollStrategy(),
        restoreFocus: this.restoreFocus(),
        closeOnOutsidePointerEvents: this.closeOnOutsidePointerEvents(),
        attachTo: this.getAttachTo(),
        attachPositions: this.attachPositions(),
        autoFocus: this.autoFocus(),
        disableClose: this.disableClose(),
        backdropClass: cssClassesToArray(this._resolvedBackdropClass()),
        panelClass: cssClassesToArray(this._resolvedPanelClass()),
        ariaDescribedBy: this.ariaDescribedBy(),
        ariaLabelledBy: this.ariaLabelledBy(),
        ariaLabel: this.ariaLabel(),
        ariaModal: this.ariaModal(),
    }), ...(ngDevMode ? [{ debugName: "_options" }] : /* istanbul ignore next */ []));
    constructor() {
        // Registered first so the flag is set before forceClose() below tears the dialog down and
        // emits on closed$/stateChanged$ - otherwise those emits hit a destroyed OutputRef (NG0953).
        this._destroyRef.onDestroy(() => (this._destroyed = true));
        this._destroyRef.onDestroy(() => this._dialogRef()?.forceClose());
        this._syncPanelClass();
        this._syncOverlayClass();
        afterNextRender(() => {
            effect(() => {
                const state = this.state();
                if (state === 'open')
                    untracked(() => this.open());
                if (state === 'closed')
                    untracked(() => this.close());
            }, { injector: this._injector });
        });
    }
    open() {
        if (!this._content)
            return;
        const currentRef = this._dialogRef();
        if (currentRef) {
            currentRef.reopen();
            return;
        }
        const dialogRef = this._dialogService.open(this._content.template, this._vcr, this._content.context() ?? {}, this._options());
        this._dialogRef.set(dialogRef);
        dialogRef.stateChanged$.pipe(takeUntilDestroyed(this._destroyRef)).subscribe((state) => {
            if (!this._destroyed)
                this.stateChanged.emit(state);
        });
        dialogRef.closed$.pipe(takeUntilDestroyed(this._destroyRef)).subscribe((result) => {
            if (this._dialogRef() === dialogRef)
                this._dialogRef.set(undefined);
            if (!this._destroyed)
                this.closed.emit(result);
        });
    }
    close(result) {
        this._dialogRef()?.close(result);
    }
    registerContent(template, context, panelClass) {
        this._content = { template, context, panelClass };
    }
    registerOverlayClass(overlayClass) {
        this._overlayClass = overlayClass;
    }
    setOrigin(origin) {
        this._origin.set(origin);
    }
    setOverlayClass(overlayClass) {
        this._backdropClass.set(overlayClass);
        this._dialogRef()?.setOverlayClass(overlayClass);
    }
    setPanelClass(panelClass) {
        this._panelClass.set(panelClass);
        this._dialogRef()?.setPanelClass(panelClass);
    }
    updatePosition() {
        this._dialogRef()?.updatePosition();
    }
    getAttachTo() {
        return this._origin() ?? this.attachTo();
    }
    getPositionStrategy() {
        return this.positionStrategy();
    }
    getScrollStrategy() {
        const strategy = this.scrollStrategy();
        if (strategy === 'close')
            return this._scrollStrategies.close();
        if (strategy === 'reposition')
            return this._scrollStrategies.reposition();
        return strategy;
    }
    _syncPanelClass() {
        effect(() => {
            const dialogRef = this._dialogRef();
            if (!dialogRef)
                return;
            const panelClass = this._resolvedPanelClass();
            untracked(() => dialogRef.setPanelClass(panelClass));
        }, { injector: this._injector });
    }
    _syncOverlayClass() {
        effect(() => {
            const dialogRef = this._dialogRef();
            if (!dialogRef)
                return;
            const overlayClass = this._resolvedBackdropClass();
            untracked(() => dialogRef.setOverlayClass(overlayClass));
        }, { injector: this._injector });
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialog, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnDialog, isStandalone: true, selector: "[brnDialog],brn-dialog", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null }, role: { classPropertyName: "role", publicName: "role", isSignal: true, isRequired: false, transformFunction: null }, hasBackdrop: { classPropertyName: "hasBackdrop", publicName: "hasBackdrop", isSignal: true, isRequired: false, transformFunction: null }, positionStrategy: { classPropertyName: "positionStrategy", publicName: "positionStrategy", isSignal: true, isRequired: false, transformFunction: null }, scrollStrategy: { classPropertyName: "scrollStrategy", publicName: "scrollStrategy", isSignal: true, isRequired: false, transformFunction: null }, restoreFocus: { classPropertyName: "restoreFocus", publicName: "restoreFocus", isSignal: true, isRequired: false, transformFunction: null }, closeOnOutsidePointerEvents: { classPropertyName: "closeOnOutsidePointerEvents", publicName: "closeOnOutsidePointerEvents", isSignal: true, isRequired: false, transformFunction: null }, attachTo: { classPropertyName: "attachTo", publicName: "attachTo", isSignal: true, isRequired: false, transformFunction: null }, attachPositions: { classPropertyName: "attachPositions", publicName: "attachPositions", isSignal: true, isRequired: false, transformFunction: null }, autoFocus: { classPropertyName: "autoFocus", publicName: "autoFocus", isSignal: true, isRequired: false, transformFunction: null }, disableClose: { classPropertyName: "disableClose", publicName: "disableClose", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedBy: { classPropertyName: "ariaDescribedBy", publicName: "aria-describedby", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "aria-labelledby", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "aria-label", isSignal: true, isRequired: false, transformFunction: null }, ariaModal: { classPropertyName: "ariaModal", publicName: "aria-modal", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closed: "closed", stateChanged: "stateChanged" }, exportAs: ["brnDialog"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialog, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDialog],brn-dialog',
                    exportAs: 'brnDialog',
                }]
        }], ctorParameters: () => [], propDecorators: { closed: [{ type: i0.Output, args: ["closed"] }], stateChanged: [{ type: i0.Output, args: ["stateChanged"] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }], role: [{ type: i0.Input, args: [{ isSignal: true, alias: "role", required: false }] }], hasBackdrop: [{ type: i0.Input, args: [{ isSignal: true, alias: "hasBackdrop", required: false }] }], positionStrategy: [{ type: i0.Input, args: [{ isSignal: true, alias: "positionStrategy", required: false }] }], scrollStrategy: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollStrategy", required: false }] }], restoreFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "restoreFocus", required: false }] }], closeOnOutsidePointerEvents: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnOutsidePointerEvents", required: false }] }], attachTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "attachTo", required: false }] }], attachPositions: [{ type: i0.Input, args: [{ isSignal: true, alias: "attachPositions", required: false }] }], autoFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoFocus", required: false }] }], disableClose: [{ type: i0.Input, args: [{ isSignal: true, alias: "disableClose", required: false }] }], ariaDescribedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "aria-describedby", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "aria-labelledby", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "aria-label", required: false }] }], ariaModal: [{ type: i0.Input, args: [{ isSignal: true, alias: "aria-modal", required: false }] }] } });

class BrnDialogClose {
    _brnDialogRef = inject(BrnDialogRef);
    close() {
        this._brnDialogRef.close();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogClose, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnDialogClose, isStandalone: true, selector: "button[brnDialogClose]", host: { listeners: { "click": "close()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogClose, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnDialogClose]',
                    host: {
                        '(click)': 'close()',
                    },
                }]
        }] });

class BrnDialogContent {
    _brnDialog = inject(BrnDialog, { optional: true });
    _brnDialogRef = inject(BrnDialogRef, { optional: true });
    _template = inject(TemplateRef);
    state = computed(() => this._brnDialog?.stateComputed() ?? this._brnDialogRef?.state() ?? 'closed', ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    className = input(undefined, { ...(ngDevMode ? { debugName: "className" } : /* istanbul ignore next */ {}), alias: 'class' });
    context = input(undefined, ...(ngDevMode ? [{ debugName: "context" }] : /* istanbul ignore next */ []));
    constructor() {
        this._brnDialog?.registerContent(this._template, this.context, this.className);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnDialogContent, isStandalone: true, selector: "[brnDialogContent]", inputs: { className: { classPropertyName: "className", publicName: "class", isSignal: true, isRequired: false, transformFunction: null }, context: { classPropertyName: "context", publicName: "context", isSignal: true, isRequired: false, transformFunction: null } }, providers: [provideExposesStateProviderExisting((() => BrnDialogContent))], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDialogContent]',
                    providers: [provideExposesStateProviderExisting((() => BrnDialogContent))],
                }]
        }], ctorParameters: () => [], propDecorators: { className: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], context: [{ type: i0.Input, args: [{ isSignal: true, alias: "context", required: false }] }] } });

class BrnDialogDescription {
    _brnDialogRef = inject(BrnDialogRef);
    _id = `brn-dialog-description-${this._brnDialogRef.dialogId}`;
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogDescription, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnDialogDescription, isStandalone: true, selector: "[brnDialogDescription]", host: { properties: { "id": "_id" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogDescription, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDialogDescription]',
                    host: {
                        '[id]': '_id',
                    },
                }]
        }] });

class BrnDialogOverlay {
    _brnDialog = inject(BrnDialog);
    _customClass = signal(undefined, ...(ngDevMode ? [{ debugName: "_customClass" }] : /* istanbul ignore next */ []));
    className = input(undefined, { ...(ngDevMode ? { debugName: "className" } : /* istanbul ignore next */ {}), alias: 'class' });
    _resolvedClass = computed(() => this._customClass() ?? this.className(), ...(ngDevMode ? [{ debugName: "_resolvedClass" }] : /* istanbul ignore next */ []));
    constructor() {
        this._brnDialog.registerOverlayClass(this._resolvedClass);
    }
    setClassToCustomElement(newClass) {
        this._customClass.set(newClass);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogOverlay, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnDialogOverlay, isStandalone: true, selector: "[brnDialogOverlay],brn-dialog-overlay", inputs: { className: { classPropertyName: "className", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, providers: [provideCustomClassSettableExisting((() => BrnDialogOverlay))], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogOverlay, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDialogOverlay],brn-dialog-overlay',
                    providers: [provideCustomClassSettableExisting((() => BrnDialogOverlay))],
                }]
        }], ctorParameters: () => [], propDecorators: { className: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

class BrnDialogTitle {
    _brnDialogRef = inject(BrnDialogRef);
    _id = `brn-dialog-title-${this._brnDialogRef.dialogId}`;
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogTitle, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnDialogTitle, isStandalone: true, selector: "[brnDialogTitle]", host: { properties: { "id": "_id" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogTitle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnDialogTitle]',
                    host: {
                        '[id]': '_id',
                    },
                }]
        }] });

let triggerIdSequence = 0;
class BrnDialogTrigger {
    _injectedDialog = inject(BrnDialog, { optional: true });
    _dialogRef = inject(BrnDialogRef, { optional: true });
    id = input(`brn-dialog-trigger-${++triggerIdSequence}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    type = input('button', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    brnDialogTriggerFor = input(undefined, { ...(ngDevMode ? { debugName: "brnDialogTriggerFor" } : /* istanbul ignore next */ {}), alias: 'brnDialogTriggerFor' });
    state = computed(() => this.getDialog()?.stateComputed() ?? this._dialogRef?.state() ?? 'closed', ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    dialogId = computed(() => this.getDialog()?.id() ?? this._dialogRef?.id ?? null, ...(ngDevMode ? [{ debugName: "dialogId" }] : /* istanbul ignore next */ []));
    getDialog() {
        return this.brnDialogTriggerFor() ?? this._injectedDialog ?? undefined;
    }
    open() {
        this.getDialog()?.open();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogTrigger, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnDialogTrigger, isStandalone: true, selector: "button[brnDialogTrigger],button[brnDialogTriggerFor]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, brnDialogTriggerFor: { classPropertyName: "brnDialogTriggerFor", publicName: "brnDialogTriggerFor", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "aria-haspopup": "dialog" }, listeners: { "click": "open()" }, properties: { "id": "id()", "attr.aria-expanded": "state() === 'open' ? 'true' : 'false'", "attr.data-state": "state()", "attr.aria-controls": "dialogId()", "type": "type()" } }, exportAs: ["brnDialogTrigger"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnDialogTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnDialogTrigger],button[brnDialogTriggerFor]',
                    exportAs: 'brnDialogTrigger',
                    host: {
                        '[id]': 'id()',
                        '(click)': 'open()',
                        'aria-haspopup': 'dialog',
                        '[attr.aria-expanded]': "state() === 'open' ? 'true' : 'false'",
                        '[attr.data-state]': 'state()',
                        '[attr.aria-controls]': 'dialogId()',
                        '[type]': 'type()',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], brnDialogTriggerFor: [{ type: i0.Input, args: [{ isSignal: true, alias: "brnDialogTriggerFor", required: false }] }] } });

const BrnDialogImports = [
    BrnDialog,
    BrnDialogOverlay,
    BrnDialogTrigger,
    BrnDialogClose,
    BrnDialogContent,
    BrnDialogTitle,
    BrnDialogDescription,
];

/**
 * Generated bundle index. Do not edit.
 */

export { BrnDialog, BrnDialogClose, BrnDialogContent, BrnDialogDescription, BrnDialogImports, BrnDialogOverlay, BrnDialogRef, BrnDialogService, BrnDialogTitle, BrnDialogTrigger, defaultOptions, injectBrnDialogContext, injectBrnDialogDefaultOptions, provideBrnDialogDefaultOptions };
//# sourceMappingURL=spartan-ng-brain-dialog.mjs.map
