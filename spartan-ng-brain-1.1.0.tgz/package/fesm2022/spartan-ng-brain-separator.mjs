import * as i0 from '@angular/core';
import { InjectionToken, inject, input, booleanAttribute, computed, Directive } from '@angular/core';

// brn-separator.token.ts
const defaultConfig = {
    orientation: 'horizontal',
};
const BrnSeparatorConfigToken = new InjectionToken('BrnSeparatorConfig');
function provideBrnSeparatorConfig(config) {
    return { provide: BrnSeparatorConfigToken, useValue: { ...defaultConfig, ...config } };
}
function injectBrnSeparatorConfig() {
    return inject(BrnSeparatorConfigToken, { optional: true }) ?? defaultConfig;
}

class BrnSeparator {
    _config = injectBrnSeparatorConfig();
    /** Orientation of the separator. */
    orientation = input(this._config.orientation, ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    /** Whether the separator is decorative. */
    decorative = input(true, { ...(ngDevMode ? { debugName: "decorative" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _role = computed(() => (this.decorative() ? 'none' : 'separator'), ...(ngDevMode ? [{ debugName: "_role" }] : /* istanbul ignore next */ []));
    _ariaOrientation = computed(() => this.decorative() ? undefined : this.orientation() === 'vertical' ? 'vertical' : undefined, ...(ngDevMode ? [{ debugName: "_ariaOrientation" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSeparator, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnSeparator, isStandalone: true, selector: "[brnSeparator],brn-separator", inputs: { orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, decorative: { classPropertyName: "decorative", publicName: "decorative", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.role": "_role()", "attr.aria-orientation": "_ariaOrientation()", "attr.data-orientation": "orientation()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnSeparator, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSeparator],brn-separator',
                    host: {
                        '[attr.role]': '_role()',
                        '[attr.aria-orientation]': '_ariaOrientation()',
                        '[attr.data-orientation]': 'orientation()',
                    },
                }]
        }], propDecorators: { orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], decorative: [{ type: i0.Input, args: [{ isSignal: true, alias: "decorative", required: false }] }] } });

const BrnSeparatorImports = [BrnSeparator];

/**
 * Generated bundle index. Do not edit.
 */

export { BrnSeparator, BrnSeparatorImports, injectBrnSeparatorConfig, provideBrnSeparatorConfig };
//# sourceMappingURL=spartan-ng-brain-separator.mjs.map
