import { Overlay, OverlayPositionBuilder } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { DOCUMENT } from '@angular/common';
import * as i0 from '@angular/core';
import { TemplateRef, inject, ViewContainerRef, input, effect, Directive, signal, ChangeDetectionStrategy, Component, InjectionToken, Injectable, DestroyRef, ElementRef, Injector, Renderer2, booleanAttribute, linkedSignal, numberAttribute, output, computed, afterNextRender, runInInjectionContext } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Directionality } from '@angular/cdk/bidi';
import { injectSkipDelay, waitForElementAnimations } from '@spartan-ng/brain/core';
import { Subject, of, timer } from 'rxjs';
import { switchMap, map } from 'rxjs/operators';

function isTemplateRef(value) {
    return value instanceof TemplateRef;
}
class BrnTooltipStringTemplateOutlet {
    _viewContainer = inject(ViewContainerRef);
    _templateRef = inject((TemplateRef));
    _embeddedViewRef = null;
    _context = {};
    _isFirstChange = true;
    _lastOutletWasTemplate = false;
    _lastTemplateRef = null;
    _lastContext;
    brnTooltipStringTemplateOutletContext = input(undefined, ...(ngDevMode ? [{ debugName: "brnTooltipStringTemplateOutletContext" }] : /* istanbul ignore next */ []));
    brnTooltipStringTemplateOutlet = input.required(...(ngDevMode ? [{ debugName: "brnTooltipStringTemplateOutlet" }] : /* istanbul ignore next */ []));
    _hasContextShapeChanged(context) {
        if (!context) {
            return false;
        }
        const prevCtxKeys = Object.keys(this._lastContext || {});
        const currCtxKeys = Object.keys(context || {});
        if (prevCtxKeys.length === currCtxKeys.length) {
            for (const propName of currCtxKeys) {
                if (!prevCtxKeys.includes(propName)) {
                    return true;
                }
            }
            return false;
        }
        else {
            return true;
        }
    }
    _shouldViewBeRecreated(stringTemplateOutlet, stringTemplateOutletContext) {
        const isTemplate = isTemplateRef(stringTemplateOutlet);
        const shouldOutletRecreate = this._isFirstChange ||
            isTemplate !== this._lastOutletWasTemplate ||
            (isTemplate && stringTemplateOutlet !== this._lastTemplateRef);
        const shouldContextRecreate = this._hasContextShapeChanged(stringTemplateOutletContext);
        return shouldContextRecreate || shouldOutletRecreate;
    }
    _updateTrackingState(stringTemplateOutlet, stringTemplateOutletContext) {
        const isTemplate = isTemplateRef(stringTemplateOutlet);
        if (this._isFirstChange && !isTemplate) {
            this._isFirstChange = false;
        }
        if (stringTemplateOutletContext !== undefined) {
            this._lastContext = stringTemplateOutletContext;
        }
        this._lastOutletWasTemplate = isTemplate;
        this._lastTemplateRef = isTemplate ? stringTemplateOutlet : null;
    }
    _viewEffect = effect(() => {
        const stringTemplateOutlet = this.brnTooltipStringTemplateOutlet();
        const stringTemplateOutletContext = this.brnTooltipStringTemplateOutletContext();
        if (!this._isFirstChange && isTemplateRef(stringTemplateOutlet)) {
            this._isFirstChange = true;
        }
        if (!isTemplateRef(stringTemplateOutlet)) {
            this._context['$implicit'] = stringTemplateOutlet;
        }
        const recreateView = this._shouldViewBeRecreated(stringTemplateOutlet, stringTemplateOutletContext);
        this._updateTrackingState(stringTemplateOutlet, stringTemplateOutletContext);
        if (recreateView) {
            this._recreateView(stringTemplateOutlet, stringTemplateOutletContext);
        }
        else {
            this._updateContext(stringTemplateOutlet, stringTemplateOutletContext);
        }
    }, ...(ngDevMode ? [{ debugName: "_viewEffect" }] : /* istanbul ignore next */ []));
    _recreateView(outlet, context) {
        this._viewContainer.clear();
        if (isTemplateRef(outlet)) {
            this._embeddedViewRef = this._viewContainer.createEmbeddedView(outlet, context);
        }
        else {
            this._embeddedViewRef = this._viewContainer.createEmbeddedView(this._templateRef, this._context);
        }
    }
    _updateContext(outlet, context) {
        const newCtx = isTemplateRef(outlet) ? context : this._context;
        let oldCtx = this._embeddedViewRef?.context;
        if (!oldCtx) {
            oldCtx = newCtx;
        }
        else if (newCtx && typeof newCtx === 'object') {
            for (const propName of Object.keys(newCtx)) {
                oldCtx[propName] = newCtx[propName];
            }
        }
        this._lastContext = oldCtx;
    }
    static ngTemplateContextGuard(_dir, _ctx) {
        return true;
    }
    ngOnDestroy() {
        this._viewEffect.destroy();
        this._viewContainer.clear();
        this._embeddedViewRef = null;
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTooltipStringTemplateOutlet, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnTooltipStringTemplateOutlet, isStandalone: true, selector: "[brnTooltipStringTemplateOutlet]", inputs: { brnTooltipStringTemplateOutletContext: { classPropertyName: "brnTooltipStringTemplateOutletContext", publicName: "brnTooltipStringTemplateOutletContext", isSignal: true, isRequired: false, transformFunction: null }, brnTooltipStringTemplateOutlet: { classPropertyName: "brnTooltipStringTemplateOutlet", publicName: "brnTooltipStringTemplateOutlet", isSignal: true, isRequired: true, transformFunction: null } }, exportAs: ["brnTooltipStringTemplateOutlet"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTooltipStringTemplateOutlet, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnTooltipStringTemplateOutlet]',
                    exportAs: 'brnTooltipStringTemplateOutlet',
                }]
        }], propDecorators: { brnTooltipStringTemplateOutletContext: [{ type: i0.Input, args: [{ isSignal: true, alias: "brnTooltipStringTemplateOutletContext", required: false }] }], brnTooltipStringTemplateOutlet: [{ type: i0.Input, args: [{ isSignal: true, alias: "brnTooltipStringTemplateOutlet", required: true }] }] } });

let uniqueId = 0;
class BrnTooltipContent {
    id = input(`brn-tooltip-${++uniqueId}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    state = signal('closed', ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    _tooltipClass = signal('', ...(ngDevMode ? [{ debugName: "_tooltipClass" }] : /* istanbul ignore next */ []));
    _arrowClass = signal('', ...(ngDevMode ? [{ debugName: "_arrowClass" }] : /* istanbul ignore next */ []));
    _svgClass = signal('', ...(ngDevMode ? [{ debugName: "_svgClass" }] : /* istanbul ignore next */ []));
    _position = signal('top', ...(ngDevMode ? [{ debugName: "_position" }] : /* istanbul ignore next */ []));
    _tooltipText = signal(null, ...(ngDevMode ? [{ debugName: "_tooltipText" }] : /* istanbul ignore next */ []));
    setProps(tooltipText, position, tooltipClasses, arrowClasses, svgClasses) {
        if (tooltipText) {
            this._tooltipText.set(tooltipText);
        }
        this._position.set(position);
        this._tooltipClass.set(tooltipClasses);
        this._arrowClass.set(arrowClasses);
        this._svgClass.set(svgClasses);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTooltipContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    /** @nocollapse */ static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.16", type: BrnTooltipContent, isStandalone: true, selector: "ng-component", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "tooltip" }, properties: { "class": "_tooltipClass()", "attr.id": "id()", "attr.data-side": "_position()", "attr.data-state": "state()" } }, ngImport: i0, template: `
		<ng-container *brnTooltipStringTemplateOutlet="_tooltipText()">{{ _tooltipText() }}</ng-container>

		<span [class]="_arrowClass()">
			<svg [class]="_svgClass()" width="10" height="5" viewBox="0 0 30 10" preserveAspectRatio="none">
				<polygon points="0,0 30,0 15,10" />
			</svg>
		</span>
	`, isInline: true, dependencies: [{ kind: "directive", type: BrnTooltipStringTemplateOutlet, selector: "[brnTooltipStringTemplateOutlet]", inputs: ["brnTooltipStringTemplateOutletContext", "brnTooltipStringTemplateOutlet"], exportAs: ["brnTooltipStringTemplateOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTooltipContent, decorators: [{
            type: Component,
            args: [{
                    imports: [BrnTooltipStringTemplateOutlet],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        '[class]': '_tooltipClass()',
                        '[attr.id]': 'id()',
                        '[attr.data-side]': '_position()',
                        '[attr.data-state]': 'state()',
                        role: 'tooltip',
                    },
                    template: `
		<ng-container *brnTooltipStringTemplateOutlet="_tooltipText()">{{ _tooltipText() }}</ng-container>

		<span [class]="_arrowClass()">
			<svg [class]="_svgClass()" width="10" height="5" viewBox="0 0 30 10" preserveAspectRatio="none">
				<polygon points="0,0 30,0 15,10" />
			</svg>
		</span>
	`,
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }] } });

const defaultGroupOptions = { skipDelayDuration: 300 };
const BRN_TOOLTIP_GROUP_OPTIONS = new InjectionToken('BrnTooltipGroupOptions');
/** Skip-delay coordinator for grouped tooltips; provide via `provideBrnTooltipGroup` on the wrapper. */
class BrnTooltipGroup {
    _options = inject(BRN_TOOLTIP_GROUP_OPTIONS);
    _skipDelay = injectSkipDelay(() => this._options.skipDelayDuration);
    /** Whether the next tooltip waits for its show delay, or opens instantly within the skip window. */
    isOpenDelayed = this._skipDelay.isOpenDelayed;
    onOpen() {
        this._skipDelay.open();
    }
    onClose() {
        this._skipDelay.close();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTooltipGroup, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    /** @nocollapse */ static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTooltipGroup });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTooltipGroup, decorators: [{
            type: Injectable
        }] });
function provideBrnTooltipGroup(options) {
    return [{ provide: BRN_TOOLTIP_GROUP_OPTIONS, useValue: { ...defaultGroupOptions, ...options } }, BrnTooltipGroup];
}

const BRN_TOOLTIP_POSITIONS_MAP = {
    top: {
        originX: 'center',
        originY: 'top',
        overlayX: 'center',
        overlayY: 'bottom',
        offsetY: -8,
    },
    bottom: {
        originX: 'center',
        originY: 'bottom',
        overlayX: 'center',
        overlayY: 'top',
        offsetY: 8,
    },
    left: {
        originX: 'start',
        originY: 'center',
        overlayX: 'end',
        overlayY: 'center',
        offsetX: -8,
    },
    right: {
        originX: 'end',
        originY: 'center',
        overlayX: 'start',
        overlayY: 'center',
        offsetX: 8,
    },
};
/** Fallback order for each preferred position when it doesn't fit in the viewport. */
const BRN_TOOLTIP_FALLBACK_POSITIONS = {
    top: ['bottom', 'right', 'left'],
    bottom: ['top', 'right', 'left'],
    left: ['right', 'top', 'bottom'],
    right: ['left', 'top', 'bottom'],
};
/** Map a resolved CDK ConnectedPosition back to a BrnTooltipPosition, or null if no match. */
function resolveTooltipPosition(pair) {
    for (const [pos, config] of Object.entries(BRN_TOOLTIP_POSITIONS_MAP)) {
        if (pair.originX === config.originX &&
            pair.originY === config.originY &&
            pair.overlayX === config.overlayX &&
            pair.overlayY === config.overlayY) {
            return pos;
        }
    }
    return null;
}

const defaultOptions = {
    showDelay: 150,
    hideDelay: 100,
    svgClasses: '',
    arrowClasses: () => '',
    tooltipContentClasses: '',
};
const BRN_TOOLTIP_DEFAULT_OPTIONS = new InjectionToken('brn-tooltip-default-options', {
    providedIn: 'root',
    factory: () => defaultOptions,
});
function provideBrnTooltipDefaultOptions(options) {
    return { provide: BRN_TOOLTIP_DEFAULT_OPTIONS, useValue: { ...defaultOptions, ...options } };
}
function injectBrnTooltipDefaultOptions() {
    return inject(BRN_TOOLTIP_DEFAULT_OPTIONS, { optional: true }) ?? defaultOptions;
}

class BrnTooltip {
    _config = injectBrnTooltipDefaultOptions();
    _destroyRef = inject(DestroyRef);
    _document = inject(DOCUMENT);
    _elementRef = inject((ElementRef));
    _injector = inject(Injector);
    _overlay = inject(Overlay);
    _overlayPositionBuilder = inject(OverlayPositionBuilder);
    _renderer = inject(Renderer2);
    _dir = inject(Directionality);
    _group = inject(BrnTooltipGroup, { optional: true });
    _tooltipHovered = false;
    _listenersRefs = [];
    _delaySubject = undefined;
    _componentRef = undefined;
    _overlayRef = undefined;
    _ariaEffectRef = undefined;
    _positionChangeSub = undefined;
    /** Bumped on every close/show so a pending exit-animation teardown can detect it was superseded. */
    _closeGeneration = 0;
    /** The position currently applied to the content - the CDK-resolved one after a flip, not the raw input. */
    _activePosition = undefined;
    tooltipDisabled = input(false, { ...(ngDevMode ? { debugName: "tooltipDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    mutableTooltipDisabled = linkedSignal(this.tooltipDisabled, ...(ngDevMode ? [{ debugName: "mutableTooltipDisabled" }] : /* istanbul ignore next */ []));
    position = input(this._config.position ?? 'top', ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    brnTooltip = input(null, ...(ngDevMode ? [{ debugName: "brnTooltip" }] : /* istanbul ignore next */ []));
    showDelay = input(this._config.showDelay, { ...(ngDevMode ? { debugName: "showDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    hideDelay = input(this._config.hideDelay, { ...(ngDevMode ? { debugName: "hideDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    show = output();
    hide = output();
    _tooltipText = computed(() => {
        let tooltipText = this.brnTooltip();
        if (!tooltipText) {
            return '';
        }
        else if (typeof tooltipText === 'string') {
            tooltipText = tooltipText.trim();
        }
        return tooltipText;
    }, ...(ngDevMode ? [{ debugName: "_tooltipText" }] : /* istanbul ignore next */ []));
    constructor() {
        afterNextRender(() => {
            this._overlayRef = this._overlay.create({
                direction: this._dir,
                positionStrategy: this._buildPositionStrategy(),
            });
            this._dir.change.pipe(takeUntilDestroyed(this._destroyRef)).subscribe(() => {
                if (this._overlayRef) {
                    this._updatePosition();
                    if (this._overlayRef.hasAttached()) {
                        this._overlayRef.updatePosition();
                    }
                }
            });
            runInInjectionContext(this._injector, () => {
                if (!this._overlayRef)
                    return;
                this._setupDelayMechanism();
                this._cleanupTriggerEvents();
                this._initTriggers();
                /**
                 * This effect is used to update the tooltip content when the tooltip text changes.
                 * It's the reactive bridge between the tooltip text and the tooltip content.
                 */
                effect(() => {
                    const text = this._tooltipText();
                    if (this._componentRef) {
                        this._applyContentProps(this._componentRef.instance, this._activePosition ?? this.position(), text);
                    }
                });
                this._listenersRefs = [
                    ...this._listenersRefs,
                    this._renderer.listen(this._overlayRef.hostElement, 'mouseenter', () => (this._tooltipHovered = true)),
                    this._renderer.listen(this._overlayRef.hostElement, 'mouseleave', () => {
                        this._tooltipHovered = false;
                        this.delay(false, this.hideDelay());
                    }),
                ];
            });
        });
        this._destroyRef.onDestroy(() => {
            this._clearAriaDescribedBy();
            this._delaySubject?.complete();
            this._cleanupTriggerEvents();
            this._overlayRef?.dispose();
        });
    }
    _updatePosition() {
        const strategy = this._overlayRef?.getConfig().positionStrategy;
        if (strategy) {
            strategy.withPositions(this._getAllPositions());
        }
    }
    _buildPositionStrategy() {
        return this._overlayPositionBuilder
            .flexibleConnectedTo(this._elementRef)
            .withPositions(this._getAllPositions())
            .withViewportMargin(8);
    }
    /** Build [preferred, ...fallbacks] position array for viewport-aware auto-flip. */
    _getAllPositions() {
        const preferred = this.position();
        return [preferred, ...BRN_TOOLTIP_FALLBACK_POSITIONS[preferred]].map((pos) => this._getAdjustedPositionFor(pos));
    }
    _getAdjustedPositionFor(pos) {
        const position = BRN_TOOLTIP_POSITIONS_MAP[pos];
        const isLtr = this._dir.value !== 'rtl';
        return {
            ...position,
            offsetX: position.offsetX != null ? (isLtr ? position.offsetX : -position.offsetX) : undefined,
        };
    }
    _initTriggers() {
        this._initScrollListener();
        this._initHoverListeners();
    }
    _initHoverListeners() {
        this._listenersRefs = [
            ...this._listenersRefs,
            this._renderer.listen(this._elementRef.nativeElement, 'mouseenter', () => this._requestShow()),
            this._renderer.listen(this._elementRef.nativeElement, 'mouseleave', () => this.delay(false, this.hideDelay())),
            this._renderer.listen(this._elementRef.nativeElement, 'focus', () => this._requestShow()),
            this._renderer.listen(this._elementRef.nativeElement, 'blur', () => this.delay(false, this.hideDelay())),
        ];
    }
    /** Snapshot the group skip decision once, so the delay and the instant-open state agree even if a
     *  sibling flips the window during the show delay. */
    _requestShow() {
        const skip = !!this._group && !this._group.isOpenDelayed();
        this.delay(true, skip ? 0 : this.showDelay(), skip);
    }
    _initScrollListener() {
        this._listenersRefs = [
            ...this._listenersRefs,
            this._renderer.listen(this._document.defaultView, 'scroll', () => this._hide()),
        ];
    }
    _cleanupTriggerEvents() {
        for (const eventRef of this._listenersRefs) {
            eventRef();
        }
        this._listenersRefs = [];
    }
    delay(isShow, delay = -1, instant = false) {
        this._delaySubject?.next({ isShow, delay, instant });
    }
    _setupDelayMechanism() {
        this._delaySubject?.complete();
        this._delaySubject = new Subject();
        this._delaySubject
            .pipe(switchMap((config) => (config.delay < 0 ? of(config) : timer(config.delay).pipe(map(() => config)))), takeUntilDestroyed(this._destroyRef))
            .subscribe((config) => {
            if (config.isShow) {
                this._show(config.instant);
            }
            else {
                this._hide();
            }
        });
    }
    _show(instant = false) {
        if (!this._tooltipText() || this.mutableTooltipDisabled()) {
            return;
        }
        // 'instant-open' suppresses the enter animation. Decided with the delay at request time so a sibling
        // flipping the group window mid-delay can't desync the animation from the wait that actually happened.
        const openState = instant ? 'instant-open' : 'open';
        // Already attached: revive only if it is mid-close (exit animation playing). Cancel the
        // pending teardown and flip it back open instead of letting it fade out and detach.
        if (this._componentRef) {
            if (this._componentRef.instance.state() === 'closed') {
                this._closeGeneration++;
                this._componentRef.instance.state.set(openState);
                // Re-apply props so a programmatic text change during the close is reflected on revive.
                // Keep the live (possibly flipped) position rather than resetting to the raw input.
                this._applyContentProps(this._componentRef.instance, this._activePosition ?? this.position());
                this._group?.onOpen();
                this.show.emit();
            }
            return;
        }
        const tooltipPortal = new ComponentPortal(BrnTooltipContent);
        this._componentRef = this._overlayRef?.attach(tooltipPortal);
        this._componentRef?.onDestroy(() => {
            this._componentRef = undefined;
        });
        this._componentRef?.instance.state.set(openState);
        this._group?.onOpen();
        if (this._componentRef) {
            this._applyContentProps(this._componentRef.instance, this.position());
        }
        // Subscribe to position changes for the lifetime of the tooltip so that
        // arrow direction and CSS classes stay in sync when the CDK flips the
        // overlay (initial show, viewport resize, scroll, etc.).
        const strategy = this._overlayRef?.getConfig().positionStrategy;
        if (strategy && this._componentRef) {
            const compRef = this._componentRef;
            this._positionChangeSub = strategy.positionChanges
                .pipe(takeUntilDestroyed(this._destroyRef))
                .subscribe((change) => {
                const resolved = resolveTooltipPosition(change.connectionPair);
                if (resolved) {
                    this._applyContentProps(compRef.instance, resolved, null);
                }
            });
        }
        runInInjectionContext(this._injector, () => {
            this._ariaEffectRef = effect(() => {
                const tooltipId = this._componentRef?.instance.id();
                if (tooltipId) {
                    this._renderer.setAttribute(this._elementRef.nativeElement, 'aria-describedby', tooltipId);
                    this._ariaEffectRef?.destroy();
                    this._ariaEffectRef = undefined;
                }
            }, ...(ngDevMode ? [{ debugName: "_ariaEffectRef" }] : /* istanbul ignore next */ []));
        });
        this.show.emit();
    }
    /** Apply text + position (and the position-derived classes) to the content, recording the position as
     *  active. Pass `text = null` for a position-only update that keeps the content's existing text. */
    _applyContentProps(content, position, text = this._tooltipText()) {
        this._activePosition = position;
        content.setProps(text, position, this._config.tooltipContentClasses, this._config.arrowClasses(position), this._config.svgClasses);
    }
    _hide() {
        if (!this._componentRef || this._tooltipHovered)
            return;
        // Already closing (exit animation in flight): nothing to do.
        if (this._componentRef.instance.state() === 'closed')
            return;
        this._componentRef.instance.state.set('closed');
        this._group?.onClose();
        this.hide.emit();
        this._scheduleDetach(this._componentRef);
    }
    /**
     * Keep the content mounted until its `data-[state=closed]` exit animation finishes, then tear it
     * down. A re-show (revive) bumps `_closeGeneration`, which cancels the pending detach.
     */
    _scheduleDetach(componentRef) {
        const generation = ++this._closeGeneration;
        const content = componentRef.location.nativeElement;
        afterNextRender(() => {
            void waitForElementAnimations(content).then(() => {
                if (generation === this._closeGeneration)
                    this._detach();
            });
        }, { injector: this._injector });
    }
    _detach() {
        this._clearAriaDescribedBy();
        this._positionChangeSub?.unsubscribe();
        this._positionChangeSub = undefined;
        this._renderer.removeAttribute(this._elementRef.nativeElement, 'aria-describedby');
        this._overlayRef?.detach();
    }
    _clearAriaDescribedBy() {
        if (this._ariaEffectRef) {
            this._ariaEffectRef.destroy();
            this._ariaEffectRef = undefined;
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTooltip, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnTooltip, isStandalone: true, selector: "[brnTooltip]", inputs: { tooltipDisabled: { classPropertyName: "tooltipDisabled", publicName: "tooltipDisabled", isSignal: true, isRequired: false, transformFunction: null }, position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, brnTooltip: { classPropertyName: "brnTooltip", publicName: "brnTooltip", isSignal: true, isRequired: false, transformFunction: null }, showDelay: { classPropertyName: "showDelay", publicName: "showDelay", isSignal: true, isRequired: false, transformFunction: null }, hideDelay: { classPropertyName: "hideDelay", publicName: "hideDelay", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { show: "show", hide: "hide" }, exportAs: ["brnTooltip"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnTooltip, decorators: [{
            type: Directive,
            args: [{ selector: '[brnTooltip]', exportAs: 'brnTooltip' }]
        }], ctorParameters: () => [], propDecorators: { tooltipDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipDisabled", required: false }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: false }] }], brnTooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "brnTooltip", required: false }] }], showDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDelay", required: false }] }], hideDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideDelay", required: false }] }], show: [{ type: i0.Output, args: ["show"] }], hide: [{ type: i0.Output, args: ["hide"] }] } });

const BrnTooltipImports = [BrnTooltip, BrnTooltipContent];

/**
 * Generated bundle index. Do not edit.
 */

export { BRN_TOOLTIP_FALLBACK_POSITIONS, BrnTooltip, BrnTooltipContent, BrnTooltipGroup, BrnTooltipImports, defaultOptions, injectBrnTooltipDefaultOptions, provideBrnTooltipDefaultOptions, provideBrnTooltipGroup, resolveTooltipPosition };
//# sourceMappingURL=spartan-ng-brain-tooltip.mjs.map
