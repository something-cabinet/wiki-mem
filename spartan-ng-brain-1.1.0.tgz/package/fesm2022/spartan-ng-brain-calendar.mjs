import * as i0 from '@angular/core';
import { input, Directive, InjectionToken, inject, signal, Injectable, ChangeDetectorRef, Injector, booleanAttribute, model, numberAttribute, computed, contentChild, linkedSignal, afterNextRender, DestroyRef, ElementRef, effect, ViewContainerRef, TemplateRef, untracked } from '@angular/core';
import { injectDateAdapter } from '@spartan-ng/brain/date-time';
import { outputToObservable, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { BrnSelect } from '@spartan-ng/brain/select';

let uniqueId$1 = 0;
class BrnCalendarHeader {
    /** The unique id for the header */
    id = input(`brn-calendar-header-${++uniqueId$1}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarHeader, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnCalendarHeader, isStandalone: true, selector: "[brnCalendarHeader]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "aria-live": "polite", "role": "presentation" }, properties: { "id": "id()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarHeader, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCalendarHeader]',
                    host: {
                        '[id]': 'id()',
                        'aria-live': 'polite',
                        role: 'presentation',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }] } });

const BrnCalendarToken = new InjectionToken('BrnCalendarToken');
function provideBrnCalendar(instance) {
    return { provide: BrnCalendarToken, useExisting: instance };
}
/**
 * Inject the calendar component.
 */
function injectBrnCalendar() {
    return inject(BrnCalendarToken);
}

const BrnCalendarI18nToken = new InjectionToken('BrnCalendarI18nToken');
/**
 * Provide the calendar i18n configuration.
 */
function provideBrnCalendarI18n(configuration) {
    return {
        provide: BrnCalendarI18nToken,
        useFactory: () => {
            const service = new BrnCalendarI18nService();
            service.use(configuration ?? defaultCalendarI18n);
            return service;
        },
    };
}
const defaultCalendarI18n = {
    formatWeekdayName: (index) => {
        const weekdays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
        return weekdays[index];
    },
    months: () => ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    years: (startYear = 1925, endYear = new Date().getFullYear() + 1) => Array.from({ length: endYear - startYear + 1 }, (_, i) => startYear + i),
    formatHeader: (month, year) => {
        return new Date(year, month).toLocaleDateString(undefined, {
            month: 'long',
            year: 'numeric',
        });
    },
    formatMonth: (month) => {
        return new Date(2000, month).toLocaleDateString(undefined, {
            month: 'short',
        });
    },
    formatYear: (year) => {
        return new Date(year, 0).toLocaleDateString(undefined, {
            year: 'numeric',
        });
    },
    labelPrevious: () => 'Go to the previous month',
    labelNext: () => 'Go to the next month',
    labelWeekday: (index) => {
        const weekdays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return weekdays[index];
    },
    firstDayOfWeek: () => 0,
};
/**
 * Inject the calendar i18n configuration.
 */
function injectBrnCalendarI18n() {
    return inject(BrnCalendarI18nToken, { optional: true }) ?? inject(BrnCalendarI18nService); // fallback
}
class BrnCalendarI18nService {
    _config = signal(defaultCalendarI18n, ...(ngDevMode ? [{ debugName: "_config" }] : /* istanbul ignore next */ []));
    config = this._config.asReadonly();
    use(config) {
        this._config.set({ ...this.config(), ...config });
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarI18nService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    /** @nocollapse */ static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarI18nService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarI18nService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const compareDays = (a, b, dateAdapter) => {
    if (a === b)
        return true;
    if (!a || !b)
        return false;
    if (a.length !== b.length)
        return false;
    return a.every((day, i) => dateAdapter.isSameDay(day, b[i]));
};

class BrnCalendar {
    _i18n = injectBrnCalendarI18n();
    /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the change detector */
    _changeDetector = inject(ChangeDetectorRef);
    /** Access the injector */
    _injector = inject(Injector);
    /** The days to highlight. */
    highlightDays = input([], ...(ngDevMode ? [{ debugName: "highlightDays" }] : /* istanbul ignore next */ []));
    /** The minimum date that can be selected.*/
    min = input(...(ngDevMode ? [undefined, { debugName: "min" }] : /* istanbul ignore next */ []));
    /** The maximum date that can be selected. */
    max = input(...(ngDevMode ? [undefined, { debugName: "max" }] : /* istanbul ignore next */ []));
    /** Determine if the date picker is disabled. */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** The selected value. */
    date = model(...(ngDevMode ? [undefined, { debugName: "date" }] : /* istanbul ignore next */ []));
    /** Whether a specific date is disabled. */
    dateDisabled = input(() => false, ...(ngDevMode ? [{ debugName: "dateDisabled" }] : /* istanbul ignore next */ []));
    /** The day the week starts on */
    weekStartsOn = input(undefined, { ...(ngDevMode ? { debugName: "weekStartsOn" } : /* istanbul ignore next */ {}), transform: (v) => (v === undefined || v === null ? undefined : numberAttribute(v)) });
    _weekStartsOn = computed(() => this.weekStartsOn() ?? this._i18n.config().firstDayOfWeek(), ...(ngDevMode ? [{ debugName: "_weekStartsOn" }] : /* istanbul ignore next */ []));
    /** The default focused date. */
    defaultFocusedDate = input(...(ngDevMode ? [undefined, { debugName: "defaultFocusedDate" }] : /* istanbul ignore next */ []));
    /** @internal Access the header */
    header = contentChild(BrnCalendarHeader, ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    _cells = [];
    /**
     * The focused date.
     */
    focusedDate = linkedSignal(() => this.constrainDate(this.defaultFocusedDate() ?? this.date() ?? this._dateAdapter.now()), ...(ngDevMode ? [{ debugName: "focusedDate" }] : /* istanbul ignore next */ []));
    /**
     * Get all the days to display, this is the days of the current month
     * and the days of the previous and next month to fill the grid.
     */
    days = computed(() => {
        const weekStartsOn = this._weekStartsOn();
        const month = this.focusedDate();
        const days = [];
        // Get the first and last day of the month.
        let firstDay = this._dateAdapter.startOfMonth(month);
        let lastDay = this._dateAdapter.endOfMonth(month);
        // we need to subtract until we get the to starting day before or on the start of the month.
        while (this._dateAdapter.getDay(firstDay) !== weekStartsOn) {
            firstDay = this._dateAdapter.subtract(firstDay, { days: 1 });
        }
        const weekEndsOn = (weekStartsOn + 6) % 7;
        // we need to add until we get to the ending day after or on the end of the month.
        while (this._dateAdapter.getDay(lastDay) !== weekEndsOn) {
            lastDay = this._dateAdapter.add(lastDay, { days: 1 });
        }
        // collect all the days to display.
        while (firstDay <= lastDay) {
            days.push(firstDay);
            firstDay = this._dateAdapter.add(firstDay, { days: 1 });
        }
        return days;
    }, { ...(ngDevMode ? { debugName: "days" } : /* istanbul ignore next */ {}), equal: (a, b) => compareDays(a, b, this._dateAdapter) });
    /** @internal Constrain a date to the min and max boundaries */
    constrainDate(date) {
        const min = this.min();
        const max = this.max();
        // If there is no min or max, return the date.
        if (!min && !max) {
            return date;
        }
        // If there is a min and the date is before the min, return the min.
        if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
            return min;
        }
        // If there is a max and the date is after the max, return the max.
        if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
            return max;
        }
        // Return the date.
        return date;
    }
    /** @internal Determine if a date is disabled */
    isDateDisabled(date) {
        // if the calendar is disabled we can't select this date
        if (this.disabled()) {
            return true;
        }
        // if the date is outside the min and max range
        const min = this.min();
        const max = this.max();
        if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
            return true;
        }
        if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
            return true;
        }
        // if this specific date is disabled
        const disabledFn = this.dateDisabled();
        if (disabledFn(date)) {
            return true;
        }
        return false;
    }
    isSelected(date) {
        const selected = this.date();
        return selected !== undefined && this._dateAdapter.isSameDay(date, selected);
    }
    selectDate(date) {
        if (this.isSelected(date)) {
            this.date.set(undefined);
        }
        else {
            this.date.set(date);
        }
        this.focusedDate.set(date);
    }
    /** @internal Set the focused date */
    setFocusedDate(date) {
        // check if the date is disabled.
        if (this.isDateDisabled(date)) {
            return;
        }
        this.focusedDate.set(date);
        // wait until the cells have all updated
        afterNextRender({
            write: () => {
                const cell = this._cells.find((c) => this._dateAdapter.isSameDay(c.date(), date));
                if (cell) {
                    cell.focus();
                }
            },
        }, {
            injector: this._injector,
        });
        // we must update the view to ensure the focused cell is visible.
        this._changeDetector.detectChanges();
    }
    /**
     * Determine if a date is the start of a range. In a date picker, this is always false.
     * @param date The date to check.
     * @returns Always false.
     * @internal
     */
    isStartOfRange(_) {
        return false;
    }
    /**
     * Determine if a date is the end of a range. In a date picker, this is always false.
     * @param date The date to check.
     * @returns Always false.
     * @internal
     */
    isEndOfRange(_) {
        return false;
    }
    /**
     * Determine if a date is between the start and end dates. In a date picker, this is always false.
     * @param date The date to check.
     * @returns True if the date is between the start and end dates, false otherwise.
     * @internal
     */
    isBetweenRange(_) {
        return false;
    }
    unregisterCalendarCell(cell) {
        const index = this._cells.indexOf(cell);
        if (index !== -1) {
            this._cells.splice(index, 1);
        }
    }
    registerCalendarCell(cell) {
        this._cells.push(cell);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendar, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnCalendar, isStandalone: true, selector: "[brnCalendar]", inputs: { highlightDays: { classPropertyName: "highlightDays", publicName: "highlightDays", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, date: { classPropertyName: "date", publicName: "date", isSignal: true, isRequired: false, transformFunction: null }, dateDisabled: { classPropertyName: "dateDisabled", publicName: "dateDisabled", isSignal: true, isRequired: false, transformFunction: null }, weekStartsOn: { classPropertyName: "weekStartsOn", publicName: "weekStartsOn", isSignal: true, isRequired: false, transformFunction: null }, defaultFocusedDate: { classPropertyName: "defaultFocusedDate", publicName: "defaultFocusedDate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { date: "dateChange" }, providers: [provideBrnCalendar(BrnCalendar)], queries: [{ propertyName: "header", first: true, predicate: BrnCalendarHeader, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendar, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCalendar]',
                    providers: [provideBrnCalendar(BrnCalendar)],
                }]
        }], propDecorators: { highlightDays: [{ type: i0.Input, args: [{ isSignal: true, alias: "highlightDays", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], date: [{ type: i0.Input, args: [{ isSignal: true, alias: "date", required: false }] }, { type: i0.Output, args: ["dateChange"] }], dateDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "dateDisabled", required: false }] }], weekStartsOn: [{ type: i0.Input, args: [{ isSignal: true, alias: "weekStartsOn", required: false }] }], defaultFocusedDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultFocusedDate", required: false }] }], header: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BrnCalendarHeader), { isSignal: true }] }] } });

class BrnCalendarCell {
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarCell, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnCalendarCell, isStandalone: true, selector: "[brnCalendarCell]", host: { attributes: { "role": "presentation" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarCell, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCalendarCell]',
                    host: {
                        role: 'presentation',
                    },
                }]
        }] });

class BrnCalendarCellButton {
    /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    _destroyRef = inject(DestroyRef);
    /** Access the calendar component */
    _calendar = injectBrnCalendar();
    /** Access the element ref */
    _elementRef = inject(ElementRef);
    /** The date this cell represents */
    date = input.required(...(ngDevMode ? [{ debugName: "date" }] : /* istanbul ignore next */ []));
    /** Whether this date is currently selected */
    selected = computed(() => this._calendar.isSelected(this.date()), ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    start = computed(() => this._calendar.isStartOfRange(this.date()), ...(ngDevMode ? [{ debugName: "start" }] : /* istanbul ignore next */ []));
    end = computed(() => this._calendar.isEndOfRange(this.date()), ...(ngDevMode ? [{ debugName: "end" }] : /* istanbul ignore next */ []));
    betweenRange = computed(() => this._calendar.isBetweenRange(this.date()), ...(ngDevMode ? [{ debugName: "betweenRange" }] : /* istanbul ignore next */ []));
    highlighted = computed(() => this._calendar.highlightDays().some((d) => this._dateAdapter.isSameDay(this.date(), d)), ...(ngDevMode ? [{ debugName: "highlighted" }] : /* istanbul ignore next */ []));
    constructor() {
        this._calendar.registerCalendarCell(this);
        this._destroyRef.onDestroy(() => this._calendar.unregisterCalendarCell(this));
    }
    /** Whether this date is focusable */
    focusable = computed(() => this._dateAdapter.isSameDay(this._calendar.focusedDate(), this.date()), ...(ngDevMode ? [{ debugName: "focusable" }] : /* istanbul ignore next */ []));
    outside = computed(() => {
        const focusedDate = this._calendar.focusedDate();
        return !this._dateAdapter.isSameMonth(this.date(), focusedDate);
    }, ...(ngDevMode ? [{ debugName: "outside" }] : /* istanbul ignore next */ []));
    /** Whether this date is today */
    today = computed(() => this._dateAdapter.isSameDay(this.date(), this._dateAdapter.now()), ...(ngDevMode ? [{ debugName: "today" }] : /* istanbul ignore next */ []));
    /** Whether this date is disabled */
    disabled = computed(() => this._calendar.isDateDisabled(this.date()) || this._calendar.disabled(), ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /**
     * Focus the previous cell.
     */
    focusPrevious(event) {
        event.preventDefault();
        event.stopPropagation();
        // in rtl, the arrow keys are reversed.
        const targetDate = this._dateAdapter.add(this._calendar.focusedDate(), {
            days: this.getDirection() === 'rtl' ? 1 : -1,
        });
        this._calendar.setFocusedDate(targetDate);
    }
    /**
     * Focus the next cell.
     */
    focusNext(event) {
        event.preventDefault();
        event.stopPropagation();
        const targetDate = this._dateAdapter.add(this._calendar.focusedDate(), {
            days: this.getDirection() === 'rtl' ? -1 : 1,
        });
        this._calendar.setFocusedDate(targetDate);
    }
    /**
     * Focus the above cell.
     */
    focusAbove(event) {
        event.preventDefault();
        event.stopPropagation();
        this._calendar.setFocusedDate(this._dateAdapter.subtract(this._calendar.focusedDate(), { days: 7 }));
    }
    /**
     * Focus the below cell.
     */
    focusBelow(event) {
        event.preventDefault();
        event.stopPropagation();
        this._calendar.setFocusedDate(this._dateAdapter.add(this._calendar.focusedDate(), { days: 7 }));
    }
    /**
     * Focus the first date of the month.
     */
    focusFirst(event) {
        event.preventDefault();
        event.stopPropagation();
        this._calendar.setFocusedDate(this._dateAdapter.startOfMonth(this._calendar.focusedDate()));
    }
    /**
     * Focus the last date of the month.
     */
    focusLast(event) {
        event.preventDefault();
        event.stopPropagation();
        this._calendar.setFocusedDate(this._dateAdapter.endOfMonth(this._calendar.focusedDate()));
    }
    /**
     * Focus the same date in the previous month.
     */
    focusPreviousMonth(event) {
        event.preventDefault();
        event.stopPropagation();
        const date = this._dateAdapter.getDate(this._calendar.focusedDate());
        let previousMonthTarget = this._dateAdapter.startOfMonth(this._calendar.focusedDate());
        previousMonthTarget = this._dateAdapter.subtract(previousMonthTarget, { months: 1 });
        const lastDay = this._dateAdapter.endOfMonth(previousMonthTarget);
        // if we are on a date that does not exist in the previous month, we should focus the last day of the month.
        if (date > this._dateAdapter.getDate(lastDay)) {
            this._calendar.setFocusedDate(lastDay);
        }
        else {
            this._calendar.setFocusedDate(this._dateAdapter.set(previousMonthTarget, { day: date }));
        }
    }
    /**
     * Focus the same date in the next month.
     */
    focusNextMonth(event) {
        event.preventDefault();
        event.stopPropagation();
        const date = this._dateAdapter.getDate(this._calendar.focusedDate());
        let nextMonthTarget = this._dateAdapter.startOfMonth(this._calendar.focusedDate());
        nextMonthTarget = this._dateAdapter.add(nextMonthTarget, { months: 1 });
        const lastDay = this._dateAdapter.endOfMonth(nextMonthTarget);
        // if we are on a date that does not exist in the next month, we should focus the last day of the month.
        if (date > this._dateAdapter.getDate(lastDay)) {
            this._calendar.setFocusedDate(lastDay);
        }
        else {
            this._calendar.setFocusedDate(this._dateAdapter.set(nextMonthTarget, { day: date }));
        }
    }
    /**
     * Get the direction of the element.
     */
    getDirection() {
        return getComputedStyle(this._elementRef.nativeElement).direction === 'rtl' ? 'rtl' : 'ltr';
    }
    focus() {
        this._elementRef.nativeElement.focus();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarCellButton, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnCalendarCellButton, isStandalone: true, selector: "button[brnCalendarCellButton]", inputs: { date: { classPropertyName: "date", publicName: "date", isSignal: true, isRequired: true, transformFunction: null } }, host: { attributes: { "role": "gridcell", "type": "button" }, listeners: { "click": "_calendar.selectDate(date())", "keydown.arrowLeft": "focusPrevious($event)", "keydown.arrowRight": "focusNext($event)", "keydown.arrowUp": "focusAbove($event)", "keydown.arrowDown": "focusBelow($event)", "keydown.home": "focusFirst($event)", "keydown.end": "focusLast($event)", "keydown.pageUp": "focusPreviousMonth($event)", "keydown.pageDown": "focusNextMonth($event)" }, properties: { "tabindex": "focusable() ? 0 : -1", "attr.data-outside": "!selected() && outside() && (!end() && !start())? true : null", "attr.data-today": "today() && !selected() ? true : null", "attr.data-selected-single": "selected() && !start() && !end() && !betweenRange() ? true : null", "attr.data-disabled": "disabled() ? true : null", "attr.aria-selected": "selected() ? true : null", "attr.aria-disabled": "disabled() ? true : null", "attr.data-range-start": "start() ? true : null", "attr.data-range-end": "end() ? true : null", "attr.data-highlighted": "highlighted() ? true : null", "attr.data-range-middle": "betweenRange() ? true : null", "disabled": "disabled()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarCellButton, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnCalendarCellButton]',
                    host: {
                        role: 'gridcell',
                        '[tabindex]': 'focusable() ? 0 : -1',
                        type: 'button',
                        '[attr.data-outside]': '!selected() && outside() && (!end() && !start())? true : null',
                        '[attr.data-today]': 'today() && !selected() ? true : null',
                        '[attr.data-selected-single]': 'selected() && !start() && !end() && !betweenRange() ? true : null',
                        '[attr.data-disabled]': 'disabled() ? true : null',
                        '[attr.aria-selected]': 'selected() ? true : null',
                        '[attr.aria-disabled]': 'disabled() ? true : null',
                        '[attr.data-range-start]': 'start() ? true : null',
                        '[attr.data-range-end]': 'end() ? true : null',
                        '[attr.data-highlighted]': 'highlighted() ? true : null',
                        '[attr.data-range-middle]': 'betweenRange() ? true : null',
                        '[disabled]': 'disabled()',
                        '(click)': '_calendar.selectDate(date())',
                        '(keydown.arrowLeft)': 'focusPrevious($event)',
                        '(keydown.arrowRight)': 'focusNext($event)',
                        '(keydown.arrowUp)': 'focusAbove($event)',
                        '(keydown.arrowDown)': 'focusBelow($event)',
                        '(keydown.home)': 'focusFirst($event)',
                        '(keydown.end)': 'focusLast($event)',
                        '(keydown.pageUp)': 'focusPreviousMonth($event)',
                        '(keydown.pageDown)': 'focusNextMonth($event)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { date: [{ type: i0.Input, args: [{ isSignal: true, alias: "date", required: true }] }] } });

class BrnCalendarGrid {
    /** Access the calendar component */
    _calendar = injectBrnCalendar();
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarGrid, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnCalendarGrid, isStandalone: true, selector: "[brnCalendarGrid]", host: { attributes: { "role": "grid" }, properties: { "attr.aria-labelledby": "_calendar.header()?.id()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarGrid, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCalendarGrid]',
                    host: {
                        role: 'grid',
                        '[attr.aria-labelledby]': '_calendar.header()?.id()',
                    },
                }]
        }] });

class BrnCalendarMonthSelect {
    /** Access the select */
    _select = inject(BrnSelect);
    /** Access the calendar */
    _calendar = injectBrnCalendar();
    /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the calendar i18n */
    _i18n = injectBrnCalendarI18n();
    _selectedMonth = computed(() => {
        return this._i18n.config().months()[this._dateAdapter.getMonth(this._calendar.focusedDate())];
    }, ...(ngDevMode ? [{ debugName: "_selectedMonth" }] : /* istanbul ignore next */ []));
    constructor() {
        // React to user selection through the injected select's typed `value` output rather than a
        // host-listener `$event` (which Angular types as `Event`). The month select's values are the
        // month strings, so narrow to `string` before handling.
        outputToObservable(this._select.value)
            .pipe(takeUntilDestroyed())
            .subscribe((value) => {
            if (typeof value === 'string') {
                this.monthSelected(value);
            }
        });
        effect(() => {
            this._select.writeValue(this._selectedMonth());
        });
    }
    /** Focus selected month */
    monthSelected(selectedMonth) {
        const month = this._i18n
            .config()
            .months()
            .findIndex((month) => month === selectedMonth);
        const targetDate = this._dateAdapter.set(this._calendar.focusedDate(), { month });
        this._calendar.focusedDate.set(targetDate);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarMonthSelect, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnCalendarMonthSelect, isStandalone: true, selector: "brnSelect[brnCalendarMonthSelect],hlm-select[brnCalendarMonthSelect]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarMonthSelect, decorators: [{
            type: Directive,
            args: [{
                    selector: 'brnSelect[brnCalendarMonthSelect],hlm-select[brnCalendarMonthSelect]',
                }]
        }], ctorParameters: () => [] });

class BrnCalendarNextButton {
    /** Access the calendar */
    _calendar = injectBrnCalendar();
    /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the calendar i18n */
    _i18n = injectBrnCalendarI18n();
    /** Focus the next month */
    focusNextMonth() {
        const focusedDate = this._calendar.focusedDate();
        const date = this._dateAdapter.getDate(focusedDate);
        // go to start of month first, then add 1 month to avoid day overflow
        let nextMonthTarget = this._dateAdapter.startOfMonth(focusedDate);
        nextMonthTarget = this._dateAdapter.add(nextMonthTarget, { months: 1 });
        const lastDay = this._dateAdapter.endOfMonth(nextMonthTarget);
        // if we are on a date that does not exist in the next month, clamp to the last day of the month.
        let targetDate;
        if (date > this._dateAdapter.getDate(lastDay)) {
            targetDate = lastDay;
        }
        else {
            targetDate = this._dateAdapter.set(nextMonthTarget, { day: date });
        }
        // if the date is disabled, but there are available dates in the month, focus the constrained date.
        const possibleDate = this._calendar.constrainDate(targetDate);
        if (this._dateAdapter.isSameMonth(possibleDate, targetDate)) {
            // if this date is within the same month, then focus it
            this._calendar.focusedDate.set(possibleDate);
            return;
        }
        this._calendar.focusedDate.set(targetDate);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarNextButton, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnCalendarNextButton, isStandalone: true, selector: "[brnCalendarNextButton]", host: { attributes: { "type": "button", "data-slot": "calendar-next-button" }, listeners: { "click": "focusNextMonth()" }, properties: { "attr.aria-label": "_i18n.config().labelNext()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarNextButton, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCalendarNextButton]',
                    host: {
                        type: 'button',
                        'data-slot': 'calendar-next-button',
                        '[attr.aria-label]': '_i18n.config().labelNext()',
                        '(click)': 'focusNextMonth()',
                    },
                }]
        }] });

class BrnCalendarPreviousButton {
    /** Access the calendar */
    _calendar = injectBrnCalendar();
    /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the calendar i18n */
    _i18n = injectBrnCalendarI18n();
    /** Focus the previous month */
    focusPreviousMonth() {
        const focusedDate = this._calendar.focusedDate();
        const date = this._dateAdapter.getDate(focusedDate);
        // go to start of month first, then subtract 1 month to avoid day overflow
        let previousMonthTarget = this._dateAdapter.startOfMonth(focusedDate);
        previousMonthTarget = this._dateAdapter.subtract(previousMonthTarget, { months: 1 });
        const lastDay = this._dateAdapter.endOfMonth(previousMonthTarget);
        // if we are on a date that does not exist in the previous month, clamp to the last day of the month.
        let targetDate;
        if (date > this._dateAdapter.getDate(lastDay)) {
            targetDate = lastDay;
        }
        else {
            targetDate = this._dateAdapter.set(previousMonthTarget, { day: date });
        }
        // if the date is disabled, but there are available dates in the month, focus the constrained date.
        const possibleDate = this._calendar.constrainDate(targetDate);
        if (this._dateAdapter.isSameMonth(possibleDate, targetDate)) {
            // if this date is within the same month, then focus it
            this._calendar.focusedDate.set(possibleDate);
            return;
        }
        this._calendar.focusedDate.set(targetDate);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarPreviousButton, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnCalendarPreviousButton, isStandalone: true, selector: "[brnCalendarPreviousButton]", host: { attributes: { "type": "button", "data-slot": "calendar-previous-button" }, listeners: { "click": "focusPreviousMonth()" }, properties: { "attr.aria-label": "_i18n.config().labelPrevious()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarPreviousButton, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCalendarPreviousButton]',
                    host: {
                        type: 'button',
                        'data-slot': 'calendar-previous-button',
                        '[attr.aria-label]': '_i18n.config().labelPrevious()',
                        '(click)': 'focusPreviousMonth()',
                    },
                }]
        }] });

class BrnCalendarWeek {
    /** Access the calendar */
    _calendar = injectBrnCalendar();
    /** Access the view container ref */
    _viewContainerRef = inject(ViewContainerRef);
    /** Access the change detector */
    _changeDetector = inject(ChangeDetectorRef);
    /** Access the template ref */
    _templateRef = inject(TemplateRef);
    // get the weeks to display.
    _weeks = computed(() => {
        const days = this._calendar.days();
        const weeks = [];
        for (let i = 0; i < days.length; i += 7) {
            weeks.push(days.slice(i, i + 7));
        }
        return weeks;
    }, ...(ngDevMode ? [{ debugName: "_weeks" }] : /* istanbul ignore next */ []));
    /** Store the view refs */
    _viewRefs = [];
    // Make sure the template checker knows the type of the context with which the
    // template of this directive will be rendered
    static ngTemplateContextGuard(_, ctx) {
        return true;
    }
    constructor() {
        // this should use `afterRenderEffect` but it's not available in the current version
        effect(() => {
            const weeks = this._weeks();
            untracked(() => this._renderWeeks(weeks));
        });
    }
    _renderWeeks(weeks) {
        // Destroy all the views when the directive is destroyed
        for (const viewRef of this._viewRefs) {
            viewRef.destroy();
        }
        this._viewRefs = [];
        // Create a new view for each week
        for (const week of weeks) {
            const viewRef = this._viewContainerRef.createEmbeddedView(this._templateRef, {
                $implicit: week,
            });
            this._viewRefs.push(viewRef);
        }
        this._changeDetector.detectChanges();
    }
    ngOnDestroy() {
        // Destroy all the views when the directive is destroyed
        for (const viewRef of this._viewRefs) {
            viewRef.destroy();
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarWeek, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnCalendarWeek, isStandalone: true, selector: "[brnCalendarWeek]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarWeek, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCalendarWeek]',
                }]
        }], ctorParameters: () => [] });

class BrnCalendarWeekday {
    /** Access the calendar */
    _calendar = injectBrnCalendar();
    /** Access the date time adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the view container ref */
    _viewContainerRef = inject(ViewContainerRef);
    /** Access the change detector */
    _changeDetector = inject(ChangeDetectorRef);
    /** Access the template ref */
    _templateRef = inject(TemplateRef);
    /** Get the days of the week to display in the header. */
    _weekdays = computed(() => this._calendar.days().slice(0, 7), ...(ngDevMode ? [{ debugName: "_weekdays" }] : /* istanbul ignore next */ []));
    /** Store the view refs */
    _viewRefs = [];
    // Make sure the template checker knows the type of the context with which the
    // template of this directive will be rendered
    static ngTemplateContextGuard(_, ctx) {
        return true;
    }
    constructor() {
        // Create a new view for each day
        effect(() => {
            // Get the weekdays to display
            const weekdays = this._weekdays();
            // Render the weekdays
            untracked(() => this._renderWeekdays(weekdays));
        });
    }
    _renderWeekdays(weekdays) {
        // Destroy all the views when the directive is destroyed
        for (const viewRef of this._viewRefs) {
            viewRef.destroy();
        }
        this._viewRefs = [];
        // Create a new view for each day
        for (const day of weekdays) {
            const viewRef = this._viewContainerRef.createEmbeddedView(this._templateRef, {
                $implicit: this._dateAdapter.getDay(day),
            });
            this._viewRefs.push(viewRef);
        }
        this._changeDetector.detectChanges();
    }
    ngOnDestroy() {
        // Destroy all the views when the directive is destroyed
        for (const viewRef of this._viewRefs) {
            viewRef.destroy();
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarWeekday, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnCalendarWeekday, isStandalone: true, selector: "[brnCalendarWeekday]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarWeekday, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCalendarWeekday]',
                }]
        }], ctorParameters: () => [] });

class BrnCalendarYearSelect {
    /** Access the select */
    _select = inject(BrnSelect);
    /** Access the calendar */
    _calendar = injectBrnCalendar();
    /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the calendar i18n */
    _i18n = injectBrnCalendarI18n();
    constructor() {
        // React to user selection through the injected select's typed `value` output rather than a
        // host-listener `$event` (which Angular types as `Event`). The year select's values are
        // numbers, so narrow to `number` before handling.
        outputToObservable(this._select.value)
            .pipe(takeUntilDestroyed())
            .subscribe((value) => {
            if (typeof value === 'number') {
                this.yearSelected(value);
            }
        });
        effect(() => {
            this._select.writeValue(this._dateAdapter.getYear(this._calendar.focusedDate()));
        });
    }
    /** Focus selected year */
    yearSelected(year) {
        const targetDate = this._dateAdapter.set(this._calendar.focusedDate(), { year });
        this._calendar.focusedDate.set(targetDate);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarYearSelect, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnCalendarYearSelect, isStandalone: true, selector: "brnSelect[brnCalendarYearSelect],hlm-select[brnCalendarYearSelect]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarYearSelect, decorators: [{
            type: Directive,
            args: [{
                    selector: 'brnSelect[brnCalendarYearSelect],hlm-select[brnCalendarYearSelect]',
                }]
        }], ctorParameters: () => [] });

class BrnCalendarMulti {
    _i18n = injectBrnCalendarI18n();
    _cells = [];
    /**
     * Determine if a date is the start of a range. In a date picker, this is always false.
     * @param date The date to check.
     * @returns Always false.
     * @internal
     */
    isStartOfRange(_) {
        return false;
    }
    /**
     * Determine if a date is the end of a range. In a date picker, this is always false.
     * @param date The date to check.
     * @returns Always false.
     * @internal
     */
    isEndOfRange(_) {
        return false;
    }
    /**
     * Determine if a date is between the start and end dates. In a date picker, this is always false.
     * @param date The date to check.
     * @returns True if the date is between the start and end dates, false otherwise.
     * @internal
     */
    isBetweenRange(_) {
        return false;
    }
    // /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the change detector */
    _changeDetector = inject(ChangeDetectorRef);
    /** Access the injector */
    _injector = inject(Injector);
    /** The days to highlight. */
    highlightDays = input([], ...(ngDevMode ? [{ debugName: "highlightDays" }] : /* istanbul ignore next */ []));
    /** The minimum date that can be selected.*/
    min = input(...(ngDevMode ? [undefined, { debugName: "min" }] : /* istanbul ignore next */ []));
    /** The maximum date that can be selected. */
    max = input(...(ngDevMode ? [undefined, { debugName: "max" }] : /* istanbul ignore next */ []));
    /** The minimum selectable dates.  */
    minSelection = input(undefined, { ...(ngDevMode ? { debugName: "minSelection" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /** The maximum selectable dates.  */
    maxSelection = input(undefined, { ...(ngDevMode ? { debugName: "maxSelection" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /** Determine if the date picker is disabled. */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** The selected value. */
    date = model(...(ngDevMode ? [undefined, { debugName: "date" }] : /* istanbul ignore next */ []));
    /** Whether a specific date is disabled. */
    dateDisabled = input(() => false, ...(ngDevMode ? [{ debugName: "dateDisabled" }] : /* istanbul ignore next */ []));
    /** The day the week starts on */
    weekStartsOn = input(undefined, { ...(ngDevMode ? { debugName: "weekStartsOn" } : /* istanbul ignore next */ {}), transform: (v) => (v === undefined || v === null ? undefined : numberAttribute(v)) });
    _weekStartsOn = computed(() => this.weekStartsOn() ?? this._i18n.config().firstDayOfWeek(), ...(ngDevMode ? [{ debugName: "_weekStartsOn" }] : /* istanbul ignore next */ []));
    /** The default focused date. */
    defaultFocusedDate = input(...(ngDevMode ? [undefined, { debugName: "defaultFocusedDate" }] : /* istanbul ignore next */ []));
    /** @internal Access the header */
    header = contentChild(BrnCalendarHeader, ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    /**
     * The focused date.
     */
    focusedDate = linkedSignal(() => this.constrainDate(this.defaultFocusedDate() ?? this._dateAdapter.now()), ...(ngDevMode ? [{ debugName: "focusedDate" }] : /* istanbul ignore next */ []));
    /**
     * Get all the days to display, this is the days of the current month
     * and the days of the previous and next month to fill the grid.
     */
    days = computed(() => {
        const weekStartsOn = this._weekStartsOn();
        const month = this.focusedDate();
        const days = [];
        // Get the first and last day of the month.
        let firstDay = this._dateAdapter.startOfMonth(month);
        let lastDay = this._dateAdapter.endOfMonth(month);
        // we need to subtract until we get the to starting day before or on the start of the month.
        while (this._dateAdapter.getDay(firstDay) !== weekStartsOn) {
            firstDay = this._dateAdapter.subtract(firstDay, { days: 1 });
        }
        const weekEndsOn = (weekStartsOn + 6) % 7;
        // we need to add until we get to the ending day after or on the end of the month.
        while (this._dateAdapter.getDay(lastDay) !== weekEndsOn) {
            lastDay = this._dateAdapter.add(lastDay, { days: 1 });
        }
        // collect all the days to display.
        while (firstDay <= lastDay) {
            days.push(firstDay);
            firstDay = this._dateAdapter.add(firstDay, { days: 1 });
        }
        return days;
    }, { ...(ngDevMode ? { debugName: "days" } : /* istanbul ignore next */ {}), equal: (a, b) => compareDays(a, b, this._dateAdapter) });
    isSelected(date) {
        return this.date()?.some((d) => this._dateAdapter.isSameDay(d, date)) ?? false;
    }
    selectDate(date) {
        const selected = this.date();
        if (this.isSelected(date)) {
            const minSelection = this.minSelection();
            if (selected?.length === minSelection) {
                // min selection reached, do not allow to deselect
                return;
            }
            this.date.set(selected?.filter((d) => !this._dateAdapter.isSameDay(d, date)));
        }
        else {
            const maxSelection = this.maxSelection();
            if (selected?.length === maxSelection) {
                // max selection reached, reset the selection to date
                this.date.set([date]);
            }
            else {
                // add the date to the selection
                this.date.set([...(selected ?? []), date]);
            }
        }
    }
    // same as in brn-calendar.directive.ts
    /** @internal Constrain a date to the min and max boundaries */
    constrainDate(date) {
        const min = this.min();
        const max = this.max();
        // If there is no min or max, return the date.
        if (!min && !max) {
            return date;
        }
        // If there is a min and the date is before the min, return the min.
        if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
            return min;
        }
        // If there is a max and the date is after the max, return the max.
        if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
            return max;
        }
        // Return the date.
        return date;
    }
    /** @internal Determine if a date is disabled */
    isDateDisabled(date) {
        // if the calendar is disabled we can't select this date
        if (this.disabled()) {
            return true;
        }
        // if the date is outside the min and max range
        const min = this.min();
        const max = this.max();
        if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
            return true;
        }
        if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
            return true;
        }
        // if this specific date is disabled
        const disabledFn = this.dateDisabled();
        if (disabledFn(date)) {
            return true;
        }
        return false;
    }
    /** @internal Set the focused date */
    setFocusedDate(date) {
        // check if the date is disabled.
        if (this.isDateDisabled(date)) {
            return;
        }
        this.focusedDate.set(date);
        // wait until the cells have all updated
        afterNextRender({
            write: () => {
                const cell = this._cells.find((c) => this._dateAdapter.isSameDay(c.date(), date));
                if (cell) {
                    cell.focus();
                }
            },
        }, {
            injector: this._injector,
        });
        // we must update the view to ensure the focused cell is visible.
        this._changeDetector.detectChanges();
    }
    unregisterCalendarCell(cell) {
        const index = this._cells.indexOf(cell);
        if (index !== -1) {
            this._cells.splice(index, 1);
        }
    }
    registerCalendarCell(cell) {
        this._cells.push(cell);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarMulti, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnCalendarMulti, isStandalone: true, selector: "[brnCalendarMulti]", inputs: { highlightDays: { classPropertyName: "highlightDays", publicName: "highlightDays", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, minSelection: { classPropertyName: "minSelection", publicName: "minSelection", isSignal: true, isRequired: false, transformFunction: null }, maxSelection: { classPropertyName: "maxSelection", publicName: "maxSelection", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, date: { classPropertyName: "date", publicName: "date", isSignal: true, isRequired: false, transformFunction: null }, dateDisabled: { classPropertyName: "dateDisabled", publicName: "dateDisabled", isSignal: true, isRequired: false, transformFunction: null }, weekStartsOn: { classPropertyName: "weekStartsOn", publicName: "weekStartsOn", isSignal: true, isRequired: false, transformFunction: null }, defaultFocusedDate: { classPropertyName: "defaultFocusedDate", publicName: "defaultFocusedDate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { date: "dateChange" }, providers: [provideBrnCalendar(BrnCalendarMulti)], queries: [{ propertyName: "header", first: true, predicate: BrnCalendarHeader, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarMulti, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCalendarMulti]',
                    providers: [provideBrnCalendar(BrnCalendarMulti)],
                }]
        }], propDecorators: { highlightDays: [{ type: i0.Input, args: [{ isSignal: true, alias: "highlightDays", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], minSelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "minSelection", required: false }] }], maxSelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxSelection", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], date: [{ type: i0.Input, args: [{ isSignal: true, alias: "date", required: false }] }, { type: i0.Output, args: ["dateChange"] }], dateDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "dateDisabled", required: false }] }], weekStartsOn: [{ type: i0.Input, args: [{ isSignal: true, alias: "weekStartsOn", required: false }] }], defaultFocusedDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultFocusedDate", required: false }] }], header: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BrnCalendarHeader), { isSignal: true }] }] } });

class BrnCalendarRange {
    _cells = [];
    _i18n = injectBrnCalendarI18n();
    // /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the change detector */
    _changeDetector = inject(ChangeDetectorRef);
    /** Access the injector */
    _injector = inject(Injector);
    /** The days to highlight. */
    highlightDays = input([], ...(ngDevMode ? [{ debugName: "highlightDays" }] : /* istanbul ignore next */ []));
    /** The minimum date that can be selected.*/
    min = input(...(ngDevMode ? [undefined, { debugName: "min" }] : /* istanbul ignore next */ []));
    /** The maximum date that can be selected. */
    max = input(...(ngDevMode ? [undefined, { debugName: "max" }] : /* istanbul ignore next */ []));
    /** Determine if the date picker is disabled. */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Whether a specific date is disabled. */
    dateDisabled = input(() => false, ...(ngDevMode ? [{ debugName: "dateDisabled" }] : /* istanbul ignore next */ []));
    /** The day the week starts on */
    weekStartsOn = input(undefined, { ...(ngDevMode ? { debugName: "weekStartsOn" } : /* istanbul ignore next */ {}), transform: (v) => (v === undefined || v === null ? undefined : numberAttribute(v)) });
    _weekStartsOn = computed(() => this.weekStartsOn() ?? this._i18n.config().firstDayOfWeek(), ...(ngDevMode ? [{ debugName: "_weekStartsOn" }] : /* istanbul ignore next */ []));
    /** The default focused date. */
    defaultFocusedDate = input(...(ngDevMode ? [undefined, { debugName: "defaultFocusedDate" }] : /* istanbul ignore next */ []));
    /** @internal Access the header */
    header = contentChild(BrnCalendarHeader, ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    /**
     * The focused date.
     */
    focusedDate = linkedSignal(() => this.constrainDate(this.defaultFocusedDate() ?? this.startDate() ?? this._dateAdapter.now()), ...(ngDevMode ? [{ debugName: "focusedDate" }] : /* istanbul ignore next */ []));
    /**
     * The selected start date
     */
    startDate = model(...(ngDevMode ? [undefined, { debugName: "startDate" }] : /* istanbul ignore next */ []));
    /**
     * The selected end date
     */
    endDate = model(...(ngDevMode ? [undefined, { debugName: "endDate" }] : /* istanbul ignore next */ []));
    /**
     * Get all the days to display, this is the days of the current month
     * and the days of the previous and next month to fill the grid.
     */
    days = computed(() => {
        const weekStartsOn = this._weekStartsOn();
        const month = this.focusedDate();
        const days = [];
        // Get the first and last day of the month.
        let firstDay = this._dateAdapter.startOfMonth(month);
        let lastDay = this._dateAdapter.endOfMonth(month);
        // we need to subtract until we get the to starting day before or on the start of the month.
        while (this._dateAdapter.getDay(firstDay) !== weekStartsOn) {
            firstDay = this._dateAdapter.subtract(firstDay, { days: 1 });
        }
        const weekEndsOn = (weekStartsOn + 6) % 7;
        // we need to add until we get to the ending day after or on the end of the month.
        while (this._dateAdapter.getDay(lastDay) !== weekEndsOn) {
            lastDay = this._dateAdapter.add(lastDay, { days: 1 });
        }
        // collect all the days to display.
        while (firstDay <= lastDay) {
            days.push(firstDay);
            firstDay = this._dateAdapter.add(firstDay, { days: 1 });
        }
        return days;
    }, { ...(ngDevMode ? { debugName: "days" } : /* istanbul ignore next */ {}), equal: (a, b) => compareDays(a, b, this._dateAdapter) });
    isSelected(date) {
        const start = this.startDate();
        const end = this.endDate();
        if (!start && !end) {
            return false;
        }
        const isStartSelected = start ? this._dateAdapter.isSameDay(date, start) : false;
        const isEndSelected = end ? this._dateAdapter.isSameDay(date, end) : false;
        return isStartSelected || isEndSelected;
    }
    selectDate(date) {
        const start = this.startDate();
        const end = this.endDate();
        if (!start && !end) {
            this.startDate.set(date);
            return;
        }
        if (start && !end) {
            if (this._dateAdapter.isAfter(date, start)) {
                this.endDate.set(date);
            }
            else if (this._dateAdapter.isBefore(date, start)) {
                this.startDate.set(date);
                this.endDate.set(start);
            }
            else if (this._dateAdapter.isSameDay(date, start)) {
                this.endDate.set(date);
            }
            return;
        }
        // If both start and end are selected, reset selection
        this.startDate.set(date);
        this.endDate.set(undefined);
    }
    // same as in brn-calendar.directive.ts
    /** @internal Constrain a date to the min and max boundaries */
    constrainDate(date) {
        const min = this.min();
        const max = this.max();
        // If there is no min or max, return the date.
        if (!min && !max) {
            return date;
        }
        // If there is a min and the date is before the min, return the min.
        if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
            return min;
        }
        // If there is a max and the date is after the max, return the max.
        if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
            return max;
        }
        // Return the date.
        return date;
    }
    /** @internal Determine if a date is disabled */
    isDateDisabled(date) {
        // if the calendar is disabled we can't select this date
        if (this.disabled()) {
            return true;
        }
        // if the date is outside the min and max range
        const min = this.min();
        const max = this.max();
        if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
            return true;
        }
        if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
            return true;
        }
        // if this specific date is disabled
        const disabledFn = this.dateDisabled();
        if (disabledFn(date)) {
            return true;
        }
        return false;
    }
    /** @internal Set the focused date */
    setFocusedDate(date) {
        // check if the date is disabled.
        if (this.isDateDisabled(date)) {
            return;
        }
        this.focusedDate.set(date);
        // wait until the cells have all updated
        afterNextRender({
            write: () => {
                const cell = this._cells.find((c) => this._dateAdapter.isSameDay(c.date(), date));
                if (cell) {
                    cell.focus();
                }
            },
        }, {
            injector: this._injector,
        });
        // we must update the view to ensure the focused cell is visible.
        this._changeDetector.detectChanges();
    }
    /**
     * Determine if a date is the start of a range.
     * @param date The date to check.
     * @returns Always false.
     * @internal
     */
    isStartOfRange(date) {
        const start = this.startDate();
        return start ? this._dateAdapter.isSameDay(date, start) : false;
    }
    /**
     * Determine if a date is the end of a range.
     * @param date The date to check.
     * @returns Always false.
     * @internal
     */
    isEndOfRange(date) {
        const end = this.endDate();
        return end ? this._dateAdapter.isSameDay(date, end) : false;
    }
    /**
     * Determine if a date is between the start and end dates.
     * @param date The date to check.
     * @returns True if the date is between the start and end dates, false otherwise.
     * @internal
     */
    isBetweenRange(date) {
        const start = this.startDate();
        const end = this.endDate();
        if (!start || !end) {
            return false;
        }
        return (this._dateAdapter.isAfter(date, start) &&
            this._dateAdapter.isBefore(date, end) &&
            !this._dateAdapter.isSameDay(date, start) &&
            !this._dateAdapter.isSameDay(date, end));
    }
    unregisterCalendarCell(cell) {
        const index = this._cells.indexOf(cell);
        if (index !== -1) {
            this._cells.splice(index, 1);
        }
    }
    registerCalendarCell(cell) {
        this._cells.push(cell);
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarRange, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnCalendarRange, isStandalone: true, selector: "[brnCalendarRange]", inputs: { highlightDays: { classPropertyName: "highlightDays", publicName: "highlightDays", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, dateDisabled: { classPropertyName: "dateDisabled", publicName: "dateDisabled", isSignal: true, isRequired: false, transformFunction: null }, weekStartsOn: { classPropertyName: "weekStartsOn", publicName: "weekStartsOn", isSignal: true, isRequired: false, transformFunction: null }, defaultFocusedDate: { classPropertyName: "defaultFocusedDate", publicName: "defaultFocusedDate", isSignal: true, isRequired: false, transformFunction: null }, startDate: { classPropertyName: "startDate", publicName: "startDate", isSignal: true, isRequired: false, transformFunction: null }, endDate: { classPropertyName: "endDate", publicName: "endDate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { startDate: "startDateChange", endDate: "endDateChange" }, providers: [provideBrnCalendar(BrnCalendarRange)], queries: [{ propertyName: "header", first: true, predicate: BrnCalendarHeader, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnCalendarRange, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnCalendarRange]',
                    providers: [provideBrnCalendar(BrnCalendarRange)],
                }]
        }], propDecorators: { highlightDays: [{ type: i0.Input, args: [{ isSignal: true, alias: "highlightDays", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], dateDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "dateDisabled", required: false }] }], weekStartsOn: [{ type: i0.Input, args: [{ isSignal: true, alias: "weekStartsOn", required: false }] }], defaultFocusedDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultFocusedDate", required: false }] }], header: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BrnCalendarHeader), { isSignal: true }] }], startDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "startDate", required: false }] }, { type: i0.Output, args: ["startDateChange"] }], endDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "endDate", required: false }] }, { type: i0.Output, args: ["endDateChange"] }] } });

const BrnMonthYearCalendarToken = new InjectionToken('BrnMonthYearCalendarToken');
function provideBrnMonthYearCalendar(instance) {
    return { provide: BrnMonthYearCalendarToken, useExisting: instance };
}
/**
 * Inject the month/year selector.
 */
function injectBrnMonthYearCalendar() {
    return inject(BrnMonthYearCalendarToken);
}

let uniqueId = 0;
class BrnMonthYearCalendarHeader {
    /** The unique id for the header */
    id = input(`brn-month-year-header-${++uniqueId}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    _monthYear = injectBrnMonthYearCalendar();
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarHeader, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnMonthYearCalendarHeader, isStandalone: true, selector: "button[brnMonthYearCalendarHeader]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "_monthYear.view.set(\"year\")" }, properties: { "id": "id()", "disabled": "_monthYear.disabled() || _monthYear.view() === \"year\"" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarHeader, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnMonthYearCalendarHeader]',
                    host: {
                        '[id]': 'id()',
                        '[disabled]': '_monthYear.disabled() || _monthYear.view() === "year"',
                        '(click)': '_monthYear.view.set("year")',
                    },
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }] } });

/** The number of years shown per page (4 columns x 3 rows). */
const YEARS_PER_PAGE = 12;
/** Positive modulo. */
function floorMod(value, modulo) {
    return ((value % modulo) + modulo) % modulo;
}
class BrnMonthYearCalendar {
    /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the change detector */
    _changeDetector = inject(ChangeDetectorRef);
    /** Access the injector */
    _injector = inject(Injector);
    /** The minimum date that can be selected. */
    min = input(...(ngDevMode ? [undefined, { debugName: "min" }] : /* istanbul ignore next */ []));
    /** The maximum date that can be selected. */
    max = input(...(ngDevMode ? [undefined, { debugName: "max" }] : /* istanbul ignore next */ []));
    /** Whether the month/year selector is disabled. */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** The selected month. Represented by the first day of the month. */
    date = model(...(ngDevMode ? [undefined, { debugName: "date" }] : /* istanbul ignore next */ []));
    /** The default focused date. */
    defaultFocusedDate = input(...(ngDevMode ? [undefined, { debugName: "defaultFocusedDate" }] : /* istanbul ignore next */ []));
    /** The current view. The year view is shown first. */
    viewInput = input('year', { ...(ngDevMode ? { debugName: "viewInput" } : /* istanbul ignore next */ {}), alias: 'view' });
    /** The current view mutable. The year view is shown first. */
    view = linkedSignal(this.viewInput, ...(ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []));
    /** @internal Access the header */
    header = contentChild(BrnMonthYearCalendarHeader, ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    /** The focused date. */
    focusedDate = linkedSignal(() => this.constrainDate(this.defaultFocusedDate() ?? this.date() ?? this._dateAdapter.now()), ...(ngDevMode ? [{ debugName: "focusedDate" }] : /* istanbul ignore next */ []));
    _cells = [];
    /** The 12 months of the currently focused year. */
    months = computed(() => {
        const focused = this.focusedDate();
        return Array.from({ length: 12 }, (_, month) => this._dateAdapter.startOfMonth(this._dateAdapter.set(focused, { month, day: 1 })));
    }, ...(ngDevMode ? [{ debugName: "months" }] : /* istanbul ignore next */ []));
    /** The first and last year of the current page. */
    yearRange = computed(() => {
        const year = this._dateAdapter.getYear(this.focusedDate());
        const start = year - floorMod(year, YEARS_PER_PAGE);
        return { start, end: start + YEARS_PER_PAGE - 1 };
    }, ...(ngDevMode ? [{ debugName: "yearRange" }] : /* istanbul ignore next */ []));
    /** The years of the current page. */
    years = computed(() => {
        const focused = this.focusedDate();
        const { start } = this.yearRange();
        return Array.from({ length: YEARS_PER_PAGE }, (_, i) => this._dateAdapter.startOfMonth(this._dateAdapter.set(focused, { year: start + i, month: 0, day: 1 })));
    }, ...(ngDevMode ? [{ debugName: "years" }] : /* istanbul ignore next */ []));
    /** @internal Constrain a date to the min and max boundaries. */
    constrainDate(date) {
        const min = this.min();
        const max = this.max();
        if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
            return min;
        }
        if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
            return max;
        }
        return date;
    }
    selectMonth(date) {
        if (this.isMonthDisabled(date)) {
            return;
        }
        const month = this._dateAdapter.startOfDay(this._dateAdapter.startOfMonth(date));
        if (this.isMonthSelected(date)) {
            this.date.set(undefined);
        }
        else {
            this.date.set(month);
        }
        this.focusedDate.set(month);
    }
    selectYear(date) {
        if (this.isYearDisabled(date)) {
            return;
        }
        const year = this._dateAdapter.getYear(date);
        let target = this._dateAdapter.set(this.focusedDate(), { year });
        if (this.isMonthDisabled(target)) {
            target = this._dateAdapter.set(target, { month: 0, day: 1 });
        }
        this.focusedDate.set(target);
        this.view.set('month');
        // focus the first available month once the month view is rendered.
        this._focusCell((cell) => !this.isMonthDisabled(cell));
    }
    isMonthSelected(date) {
        const selected = this.date();
        return !!selected && this._dateAdapter.isSameMonth(date, selected) && this._dateAdapter.isSameYear(date, selected);
    }
    isYearSelected(date) {
        const selected = this.date();
        return !!selected && this._dateAdapter.isSameYear(date, selected);
    }
    isMonthToday(date) {
        const now = this._dateAdapter.now();
        return this._dateAdapter.isSameMonth(date, now) && this._dateAdapter.isSameYear(date, now);
    }
    isYearToday(date) {
        return this._dateAdapter.isSameYear(date, this._dateAdapter.now());
    }
    isMonthDisabled(date) {
        if (this.disabled()) {
            return true;
        }
        const min = this.min();
        const max = this.max();
        if (min && this._dateAdapter.isBefore(this._dateAdapter.endOfMonth(date), this._dateAdapter.startOfDay(min))) {
            return true;
        }
        if (max && this._dateAdapter.isAfter(this._dateAdapter.startOfMonth(date), this._dateAdapter.endOfDay(max))) {
            return true;
        }
        return false;
    }
    isYearDisabled(date) {
        if (this.disabled()) {
            return true;
        }
        const year = this._dateAdapter.getYear(date);
        const min = this.min();
        const max = this.max();
        if (min && year < this._dateAdapter.getYear(min)) {
            return true;
        }
        if (max && year > this._dateAdapter.getYear(max)) {
            return true;
        }
        return false;
    }
    setFocusedMonth(date) {
        if (this.isMonthDisabled(date)) {
            return;
        }
        this.focusedDate.set(this._dateAdapter.startOfMonth(date));
        this._focusCell((cell) => this._dateAdapter.isSameMonth(cell, date) && this._dateAdapter.isSameYear(cell, date));
    }
    setFocusedYear(date) {
        if (this.isYearDisabled(date)) {
            return;
        }
        const year = this._dateAdapter.getYear(date);
        this.focusedDate.set(this._dateAdapter.set(this.focusedDate(), { year }));
        this._focusCell((cell) => this._dateAdapter.isSameYear(cell, date));
    }
    goToPrevious() {
        if (this.isPreviousDisabled()) {
            return;
        }
        const amount = this.view() === 'month' ? 1 : YEARS_PER_PAGE;
        this.focusedDate.set(this._dateAdapter.subtract(this.focusedDate(), { years: amount }));
    }
    goToNext() {
        if (this.isNextDisabled()) {
            return;
        }
        const amount = this.view() === 'month' ? 1 : YEARS_PER_PAGE;
        this.focusedDate.set(this._dateAdapter.add(this.focusedDate(), { years: amount }));
    }
    isPreviousDisabled() {
        if (this.disabled()) {
            return true;
        }
        const min = this.min();
        if (!min) {
            return false;
        }
        const minYear = this._dateAdapter.getYear(min);
        if (this.view() === 'month') {
            return this._dateAdapter.getYear(this.focusedDate()) - 1 < minYear;
        }
        return this.yearRange().start - 1 < minYear;
    }
    isNextDisabled() {
        if (this.disabled()) {
            return true;
        }
        const max = this.max();
        if (!max) {
            return false;
        }
        const maxYear = this._dateAdapter.getYear(max);
        if (this.view() === 'month') {
            return this._dateAdapter.getYear(this.focusedDate()) + 1 > maxYear;
        }
        return this.yearRange().end + 1 > maxYear;
    }
    _focusCell(predicate) {
        afterNextRender({
            write: () => {
                const cell = this._cells.find((c) => predicate(c.value()));
                if (cell) {
                    cell.focus();
                }
            },
        }, { injector: this._injector });
        this._changeDetector.detectChanges();
    }
    registerCell(cell) {
        this._cells.push(cell);
    }
    unregisterCell(cell) {
        const index = this._cells.indexOf(cell);
        if (index !== -1) {
            this._cells.splice(index, 1);
        }
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendar, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.16", type: BrnMonthYearCalendar, isStandalone: true, selector: "[brnMonthYearCalendar]", inputs: { min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, date: { classPropertyName: "date", publicName: "date", isSignal: true, isRequired: false, transformFunction: null }, defaultFocusedDate: { classPropertyName: "defaultFocusedDate", publicName: "defaultFocusedDate", isSignal: true, isRequired: false, transformFunction: null }, viewInput: { classPropertyName: "viewInput", publicName: "view", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { date: "dateChange" }, providers: [provideBrnMonthYearCalendar(BrnMonthYearCalendar)], queries: [{ propertyName: "header", first: true, predicate: BrnMonthYearCalendarHeader, descendants: true, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendar, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnMonthYearCalendar]',
                    providers: [provideBrnMonthYearCalendar(BrnMonthYearCalendar)],
                }]
        }], propDecorators: { min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], date: [{ type: i0.Input, args: [{ isSignal: true, alias: "date", required: false }] }, { type: i0.Output, args: ["dateChange"] }], defaultFocusedDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultFocusedDate", required: false }] }], viewInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "view", required: false }] }], header: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BrnMonthYearCalendarHeader), { isSignal: true }] }] } });

class BrnMonthYearCalendarGrid {
    /** Access the month/year selector */
    _monthYear = injectBrnMonthYearCalendar();
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarGrid, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnMonthYearCalendarGrid, isStandalone: true, selector: "[brnMonthYearCalendarGrid]", host: { attributes: { "role": "grid" }, properties: { "attr.aria-labelledby": "_monthYear.header()?.id()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarGrid, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnMonthYearCalendarGrid]',
                    host: {
                        role: 'grid',
                        '[attr.aria-labelledby]': '_monthYear.header()?.id()',
                    },
                }]
        }] });

class BrnMonthYearCalendarMonthButton {
    /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the month/year selector */
    _monthYear = injectBrnMonthYearCalendar();
    /** Access the element ref */
    _elementRef = inject(ElementRef);
    _destroyRef = inject(DestroyRef);
    /** The month this cell represents. */
    date = input.required(...(ngDevMode ? [{ debugName: "date" }] : /* istanbul ignore next */ []));
    /** Expose the value for the month/year selector's focus tracking. */
    value = this.date;
    selected = computed(() => this._monthYear.isMonthSelected(this.date()), ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    today = computed(() => this._monthYear.isMonthToday(this.date()), ...(ngDevMode ? [{ debugName: "today" }] : /* istanbul ignore next */ []));
    disabled = computed(() => this._monthYear.isMonthDisabled(this.date()), ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    focusable = computed(() => this._dateAdapter.isSameMonth(this._monthYear.focusedDate(), this.date()) &&
        this._dateAdapter.isSameYear(this._monthYear.focusedDate(), this.date()), ...(ngDevMode ? [{ debugName: "focusable" }] : /* istanbul ignore next */ []));
    constructor() {
        this._monthYear.registerCell(this);
        this._destroyRef.onDestroy(() => this._monthYear.unregisterCell(this));
    }
    focusOffset(event, offset) {
        event.preventDefault();
        event.stopPropagation();
        this._monthYear.setFocusedMonth(this._dateAdapter.add(this._monthYear.focusedDate(), { months: offset }));
    }
    focusMonth(event, month) {
        event.preventDefault();
        event.stopPropagation();
        this._monthYear.setFocusedMonth(this._dateAdapter.set(this._monthYear.focusedDate(), { month, day: 1 }));
    }
    focusYearOffset(event, offset) {
        event.preventDefault();
        event.stopPropagation();
        this._monthYear.setFocusedMonth(this._dateAdapter.add(this._monthYear.focusedDate(), { years: offset }));
    }
    getDirection() {
        return getComputedStyle(this._elementRef.nativeElement).direction === 'rtl' ? 'rtl' : 'ltr';
    }
    focus() {
        this._elementRef.nativeElement.focus();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarMonthButton, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnMonthYearCalendarMonthButton, isStandalone: true, selector: "button[brnMonthYearCalendarMonthButton]", inputs: { date: { classPropertyName: "date", publicName: "date", isSignal: true, isRequired: true, transformFunction: null } }, host: { attributes: { "role": "gridcell", "type": "button" }, listeners: { "click": "_monthYear.selectMonth(date())", "keydown.arrowLeft": "focusOffset($event, getDirection() === \"rtl\" ? 1 : -1)", "keydown.arrowRight": "focusOffset($event, getDirection() === \"rtl\" ? -1 : 1)", "keydown.arrowUp": "focusOffset($event, -4)", "keydown.arrowDown": "focusOffset($event, 4)", "keydown.home": "focusMonth($event, 0)", "keydown.end": "focusMonth($event, 11)", "keydown.pageUp": "focusYearOffset($event, -1)", "keydown.pageDown": "focusYearOffset($event, 1)" }, properties: { "tabindex": "focusable() ? 0 : -1", "attr.data-selected": "selected() ? true : null", "attr.data-today": "today() && !selected() ? true : null", "attr.data-focused": "focusable() ? true : null", "attr.data-disabled": "disabled() ? true : null", "attr.aria-selected": "selected() ? true : null", "attr.aria-disabled": "disabled() ? true : null", "disabled": "disabled()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarMonthButton, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnMonthYearCalendarMonthButton]',
                    host: {
                        role: 'gridcell',
                        type: 'button',
                        '[tabindex]': 'focusable() ? 0 : -1',
                        '[attr.data-selected]': 'selected() ? true : null',
                        '[attr.data-today]': 'today() && !selected() ? true : null',
                        '[attr.data-focused]': 'focusable() ? true : null',
                        '[attr.data-disabled]': 'disabled() ? true : null',
                        '[attr.aria-selected]': 'selected() ? true : null',
                        '[attr.aria-disabled]': 'disabled() ? true : null',
                        '[disabled]': 'disabled()',
                        '(click)': '_monthYear.selectMonth(date())',
                        '(keydown.arrowLeft)': 'focusOffset($event, getDirection() === "rtl" ? 1 : -1)',
                        '(keydown.arrowRight)': 'focusOffset($event, getDirection() === "rtl" ? -1 : 1)',
                        '(keydown.arrowUp)': 'focusOffset($event, -4)',
                        '(keydown.arrowDown)': 'focusOffset($event, 4)',
                        '(keydown.home)': 'focusMonth($event, 0)',
                        '(keydown.end)': 'focusMonth($event, 11)',
                        '(keydown.pageUp)': 'focusYearOffset($event, -1)',
                        '(keydown.pageDown)': 'focusYearOffset($event, 1)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { date: [{ type: i0.Input, args: [{ isSignal: true, alias: "date", required: true }] }] } });

class BrnMonthYearCalendarNextButton {
    /** Access the month/year selector */
    _monthYear = injectBrnMonthYearCalendar();
    _disabled = computed(() => this._monthYear.isNextDisabled(), ...(ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []));
    _label = computed(() => this._monthYear.view() === 'month' ? 'Go to the next year' : 'Go to the next years', ...(ngDevMode ? [{ debugName: "_label" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarNextButton, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnMonthYearCalendarNextButton, isStandalone: true, selector: "button[brnMonthYearCalendarNextButton]", host: { attributes: { "type": "button", "data-slot": "month-year-next-button" }, listeners: { "click": "_monthYear.goToNext()" }, properties: { "attr.aria-label": "_label()", "attr.aria-disabled": "_disabled() ? true : null", "disabled": "_disabled()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarNextButton, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnMonthYearCalendarNextButton]',
                    host: {
                        type: 'button',
                        'data-slot': 'month-year-next-button',
                        '[attr.aria-label]': '_label()',
                        '[attr.aria-disabled]': '_disabled() ? true : null',
                        '[disabled]': '_disabled()',
                        '(click)': '_monthYear.goToNext()',
                    },
                }]
        }] });

class BrnMonthYearCalendarPreviousButton {
    /** Access the month/year selector */
    _monthYear = injectBrnMonthYearCalendar();
    _disabled = computed(() => this._monthYear.isPreviousDisabled(), ...(ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []));
    _label = computed(() => this._monthYear.view() === 'month' ? 'Go to the previous year' : 'Go to the previous years', ...(ngDevMode ? [{ debugName: "_label" }] : /* istanbul ignore next */ []));
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarPreviousButton, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.16", type: BrnMonthYearCalendarPreviousButton, isStandalone: true, selector: "button[brnMonthYearCalendarPreviousButton]", host: { attributes: { "type": "button", "data-slot": "month-year-previous-button" }, listeners: { "click": "_monthYear.goToPrevious()" }, properties: { "attr.aria-label": "_label()", "attr.aria-disabled": "_disabled() ? true : null", "disabled": "_disabled()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarPreviousButton, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnMonthYearCalendarPreviousButton]',
                    host: {
                        type: 'button',
                        'data-slot': 'month-year-previous-button',
                        '[attr.aria-label]': '_label()',
                        '[attr.aria-disabled]': '_disabled() ? true : null',
                        '[disabled]': '_disabled()',
                        '(click)': '_monthYear.goToPrevious()',
                    },
                }]
        }] });

class BrnMonthYearCalendarYearButton {
    /** Access the date adapter */
    _dateAdapter = injectDateAdapter();
    /** Access the month/year selector */
    _monthYear = injectBrnMonthYearCalendar();
    /** Access the element ref */
    _elementRef = inject(ElementRef);
    _destroyRef = inject(DestroyRef);
    /** The year this cell represents. */
    date = input.required(...(ngDevMode ? [{ debugName: "date" }] : /* istanbul ignore next */ []));
    /** Expose the value for the month/year selector's focus tracking. */
    value = this.date;
    selected = computed(() => this._monthYear.isYearSelected(this.date()), ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    today = computed(() => this._monthYear.isYearToday(this.date()), ...(ngDevMode ? [{ debugName: "today" }] : /* istanbul ignore next */ []));
    disabled = computed(() => this._monthYear.isYearDisabled(this.date()), ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    focusable = computed(() => this._dateAdapter.isSameYear(this._monthYear.focusedDate(), this.date()), ...(ngDevMode ? [{ debugName: "focusable" }] : /* istanbul ignore next */ []));
    _yearsPerPage = YEARS_PER_PAGE;
    constructor() {
        this._monthYear.registerCell(this);
        this._destroyRef.onDestroy(() => this._monthYear.unregisterCell(this));
    }
    focusOffset(event, offset) {
        event.preventDefault();
        event.stopPropagation();
        this._monthYear.setFocusedYear(this._dateAdapter.add(this._monthYear.focusedDate(), { years: offset }));
    }
    focusYear(event, year) {
        event.preventDefault();
        event.stopPropagation();
        this._monthYear.setFocusedYear(this._dateAdapter.set(this._monthYear.focusedDate(), { year }));
    }
    getDirection() {
        return getComputedStyle(this._elementRef.nativeElement).direction === 'rtl' ? 'rtl' : 'ltr';
    }
    focus() {
        this._elementRef.nativeElement.focus();
    }
    /** @nocollapse */ static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarYearButton, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    /** @nocollapse */ static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.16", type: BrnMonthYearCalendarYearButton, isStandalone: true, selector: "button[brnMonthYearCalendarYearButton]", inputs: { date: { classPropertyName: "date", publicName: "date", isSignal: true, isRequired: true, transformFunction: null } }, host: { attributes: { "role": "gridcell", "type": "button" }, listeners: { "click": "_monthYear.selectYear(date())", "keydown.arrowLeft": "focusOffset($event, getDirection() === \"rtl\" ? 1 : -1)", "keydown.arrowRight": "focusOffset($event, getDirection() === \"rtl\" ? -1 : 1)", "keydown.arrowUp": "focusOffset($event, -4)", "keydown.arrowDown": "focusOffset($event, 4)", "keydown.home": "focusYear($event, _monthYear.yearRange().start)", "keydown.end": "focusYear($event, _monthYear.yearRange().end)", "keydown.pageUp": "focusOffset($event, -_yearsPerPage)", "keydown.pageDown": "focusOffset($event, _yearsPerPage)" }, properties: { "tabindex": "focusable() ? 0 : -1", "attr.data-selected": "selected() ? true : null", "attr.data-today": "today() && !selected() ? true : null", "attr.data-focused": "focusable() ? true : null", "attr.data-disabled": "disabled() ? true : null", "attr.aria-selected": "selected() ? true : null", "attr.aria-disabled": "disabled() ? true : null", "disabled": "disabled()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: BrnMonthYearCalendarYearButton, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[brnMonthYearCalendarYearButton]',
                    host: {
                        role: 'gridcell',
                        type: 'button',
                        '[tabindex]': 'focusable() ? 0 : -1',
                        '[attr.data-selected]': 'selected() ? true : null',
                        '[attr.data-today]': 'today() && !selected() ? true : null',
                        '[attr.data-focused]': 'focusable() ? true : null',
                        '[attr.data-disabled]': 'disabled() ? true : null',
                        '[attr.aria-selected]': 'selected() ? true : null',
                        '[attr.aria-disabled]': 'disabled() ? true : null',
                        '[disabled]': 'disabled()',
                        '(click)': '_monthYear.selectYear(date())',
                        '(keydown.arrowLeft)': 'focusOffset($event, getDirection() === "rtl" ? 1 : -1)',
                        '(keydown.arrowRight)': 'focusOffset($event, getDirection() === "rtl" ? -1 : 1)',
                        '(keydown.arrowUp)': 'focusOffset($event, -4)',
                        '(keydown.arrowDown)': 'focusOffset($event, 4)',
                        '(keydown.home)': 'focusYear($event, _monthYear.yearRange().start)',
                        '(keydown.end)': 'focusYear($event, _monthYear.yearRange().end)',
                        '(keydown.pageUp)': 'focusOffset($event, -_yearsPerPage)',
                        '(keydown.pageDown)': 'focusOffset($event, _yearsPerPage)',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { date: [{ type: i0.Input, args: [{ isSignal: true, alias: "date", required: true }] }] } });

const BrnCalendarImports = [
    BrnCalendarCellButton,
    BrnCalendarGrid,
    BrnCalendarHeader,
    BrnCalendarNextButton,
    BrnCalendarPreviousButton,
    BrnCalendarWeek,
    BrnCalendarWeekday,
    BrnCalendar,
    BrnCalendarCell,
    BrnCalendarMulti,
    BrnCalendarRange,
    BrnCalendarMonthSelect,
    BrnCalendarYearSelect,
    BrnMonthYearCalendar,
    BrnMonthYearCalendarGrid,
    BrnMonthYearCalendarHeader,
    BrnMonthYearCalendarMonthButton,
    BrnMonthYearCalendarNextButton,
    BrnMonthYearCalendarPreviousButton,
    BrnMonthYearCalendarYearButton,
];

/**
 * Generated bundle index. Do not edit.
 */

export { BrnCalendar, BrnCalendarCell, BrnCalendarCellButton, BrnCalendarGrid, BrnCalendarHeader, BrnCalendarI18nService, BrnCalendarI18nToken, BrnCalendarImports, BrnCalendarMonthSelect, BrnCalendarMulti, BrnCalendarNextButton, BrnCalendarPreviousButton, BrnCalendarRange, BrnCalendarToken, BrnCalendarWeek, BrnCalendarWeekday, BrnCalendarYearSelect, BrnMonthYearCalendar, BrnMonthYearCalendarGrid, BrnMonthYearCalendarHeader, BrnMonthYearCalendarMonthButton, BrnMonthYearCalendarNextButton, BrnMonthYearCalendarPreviousButton, BrnMonthYearCalendarYearButton, injectBrnCalendar, injectBrnCalendarI18n, provideBrnCalendar, provideBrnCalendarI18n };
//# sourceMappingURL=spartan-ng-brain-calendar.mjs.map
