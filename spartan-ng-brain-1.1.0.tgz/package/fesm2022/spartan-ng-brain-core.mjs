import { untracked, computed, InjectionToken, forwardRef, inject, ElementRef, PLATFORM_ID, DestroyRef, signal, afterNextRender, runInInjectionContext, Injector } from '@angular/core';
import { Observable, pipe, merge, fromEvent } from 'rxjs';
import { map, filter, distinctUntilChanged, takeUntil, debounceTime } from 'rxjs/operators';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { isPlatformServer } from '@angular/common';

/**
 * Returns a signal that emits the previous value of the given signal.
 * The first time the signal is emitted, the previous value will be the same as the current value.
 *
 * @example
 * ```ts
 * const value = signal(0);
 * const previous = computedPrevious(value);
 *
 * effect(() => {
 *  console.log('Current value:', value());
 *  console.log('Previous value:', previous());
 * });
 *
 * Logs:
 * // Current value: 0
 * // Previous value: 0
 *
 * value.set(1);
 *
 * Logs:
 * // Current value: 1
 * // Previous value: 0
 *
 * value.set(2);
 *
 * Logs:
 * // Current value: 2
 * // Previous value: 1
 *```
 *
 * @param computation Signal to compute previous value for
 * @returns Signal that emits previous value of `s`
 */
function computedPrevious(computation) {
    let current = null;
    let previous = untracked(() => computation()); // initial value is the current value
    return computed(() => {
        current = computation();
        const result = previous;
        previous = current;
        return result;
    });
}

function brnZoneFull(zone) {
    return (source) => new Observable((subscriber) => source.subscribe({
        next: (value) => zone.run(() => subscriber.next(value)),
        error: (error) => zone.run(() => subscriber.error(error)),
        complete: () => zone.run(() => subscriber.complete()),
    }));
}
function brnZoneFree(zone) {
    return (source) => new Observable((subscriber) => zone.runOutsideAngular(() => source.subscribe(subscriber)));
}
function brnZoneOptimized(zone) {
    return pipe(brnZoneFree(zone), brnZoneFull(zone));
}

function movedOut({ currentTarget, relatedTarget }) {
    return !isElement(relatedTarget) || !isElement(currentTarget) || !currentTarget.contains(relatedTarget);
}
function isElement(node) {
    return !!node && 'nodeType' in node && node.nodeType === Node.ELEMENT_NODE;
}
const createHoverObservable = (nativeElement, zone, destroyed$) => {
    return merge(fromEvent(nativeElement, 'mouseenter').pipe(map(() => ({ hover: true }))), fromEvent(nativeElement, 'mouseleave').pipe(map((e) => ({ hover: false, relatedTarget: e.relatedTarget }))), 
    // Hello, Safari
    fromEvent(nativeElement, 'mouseout').pipe(filter(movedOut), map((e) => ({ hover: false, relatedTarget: e.relatedTarget })))).pipe(distinctUntilChanged(), brnZoneOptimized(zone), takeUntil(destroyed$));
};

function cssClassesToArray(classes, defaultClass = '') {
    const value = classes ?? defaultClass;
    return (Array.isArray(value) ? value : [value]).flatMap((className) => className.split(/\s+/).filter(Boolean));
}

function createInjectionToken(description) {
    const token = new InjectionToken(description);
    const provideFn = (value) => {
        return { provide: token, useValue: value };
    };
    const provideExistingFn = (value) => {
        return { provide: token, useExisting: forwardRef(value) };
    };
    const injectFn = (options = {}) => {
        return inject(token, options);
    };
    return [injectFn, provideFn, provideExistingFn, token];
}

const [injectCustomClassSettable, provideCustomClassSettable, provideCustomClassSettableExisting, SET_CLASS_TO_CUSTOM_ELEMENT_TOKEN,] = createInjectionToken('@spartan-ng SET_CLASS_TO_CUSTOM_ELEMENT_TOKEN');

/**
 * Creates a debounced version of a source signal.
 *
 * @param source - The input signal to debounce.
 * @param delay - Debounce time in milliseconds.
 * @returns A new signal that updates only after the source has stopped changing for `delay` ms.
 */
function debouncedSignal(source, delay) {
    const source$ = toObservable(source);
    const debounced$ = source$.pipe(debounceTime(delay), distinctUntilChanged());
    return toSignal(debounced$, { initialValue: source() });
}

/**
 * Set by Angular to true when in development mode.
 * Allows for tree-shaking code that is only used in development.
 */
const brnDevMode = ngDevMode;

const [injectExposedSideProvider, provideExposedSideProvider, provideExposedSideProviderExisting, EXPOSES_SIDE_TOKEN,] = createInjectionToken('@spartan-ng EXPOSES_SIDE_TOKEN');

const [injectExposesStateProvider, provideExposesStateProvider, provideExposesStateProviderExisting, EXPOSES_STATE_TOKEN,] = createInjectionToken('@spartan-ng EXPOSES_STATE_TOKEN');

/**
 * Measures the natural size of a collapsible host's content via `scrollHeight` so it can animate
 * between `height: 0` and a measured pixel height - the whole content is covered, regardless of how
 * it is projected. A `ResizeObserver` on the content keeps the value live. SSR-safe; the host must
 * be a block-level element for `scrollHeight` to reflect its content.
 *
 * @returns Signals with the content's width and height in px, or `null` before measurement.
 */
function injectContentDimensions() {
    const host = inject(ElementRef).nativeElement;
    const platformId = inject(PLATFORM_ID);
    const destroyRef = inject(DestroyRef);
    const width = signal(null, ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    const height = signal(null, ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    if (isPlatformServer(platformId)) {
        return { width: width.asReadonly(), height: height.asReadonly() };
    }
    const measure = () => {
        // Drop the clamped height for the read: scrollHeight is never smaller than the element's own
        // height, so while clamped it would only ever grow. `height: auto` lets it reflect the real
        // content size (and shrink). The read is synchronous, so the swap never paints.
        const previousHeight = host.style.height;
        host.style.height = 'auto';
        width.set(host.scrollWidth);
        height.set(host.scrollHeight);
        host.style.height = previousHeight;
    };
    afterNextRender({
        read: () => {
            measure();
            if (typeof ResizeObserver === 'undefined')
                return;
            // Observe the content wrapper (not the clamped/animated host) so re-measures fire on content
            // changes, never on the open/close height animation. Re-measure on a fresh frame rather than
            // inside the callback: measure() mutates the host's inline height, and doing that during
            // delivery trips "ResizeObserver loop completed with undelivered notifications".
            let frame = 0;
            const observer = new ResizeObserver(() => {
                cancelAnimationFrame(frame);
                frame = requestAnimationFrame(measure);
            });
            const content = host.firstElementChild;
            if (content) {
                observer.observe(content);
            }
            destroyRef.onDestroy(() => {
                cancelAnimationFrame(frame);
                observer.disconnect();
            });
        },
    });
    return { width: width.asReadonly(), height: height.asReadonly() };
}

/**
 * Returns a reactive signal that tracks the size of a DOM element.
 *
 * This function uses a shared {@link ResizeObserver} internally to monitor multiple elements efficiently.
 * The returned signal updates whenever the element's width or height changes. It is fully SSR-safe.
 *
 * @param options Optional {@link ElementSizeOptions} configuration object.
 * @param options.elementRef The {@link ElementRef} of the element to observe. Defaults to the {@link ElementRef} injected in the current context.
 * @param options.injector Optional custom {@link Injector} to run the function in. Defaults to the current injection context.
 *
 * @returns A readonly {@link Signal} containing `{ width, height }` of the element, or `undefined` if the element has not yet been measured or on the server.
 *
 * Based on https://github.com/radix-ui/primitives/blob/main/packages/react/use-size/src/use-size.tsx
 */
function injectElementSize(options = {}) {
    return runInInjectionContext(options.injector ?? inject(Injector), () => {
        const elementRef = options.elementRef ?? inject(ElementRef);
        const platformId = inject(PLATFORM_ID);
        const destroyRef = inject(DestroyRef);
        const element = elementRef.nativeElement;
        const size = signal(undefined, ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
        if (isPlatformServer(platformId)) {
            return size;
        }
        afterNextRender({
            read: () => {
                // Initial read
                const rect = element.getBoundingClientRect();
                size.set({
                    width: rect.width || element.offsetWidth,
                    height: rect.height || element.offsetHeight,
                });
                // Register element in shared observer
                observerMap.set(element, { element, size });
                getSharedObserver().observe(element, { box: 'border-box' });
                destroyRef.onDestroy(() => {
                    getSharedObserver().unobserve(element);
                    observerMap.delete(element);
                    // Disconnect global observer if no elements left
                    if (observerMap.size === 0 && sharedObserver) {
                        sharedObserver.disconnect();
                        sharedObserver = undefined;
                    }
                });
            },
        });
        return size.asReadonly();
    });
}
const observerMap = new Map();
let sharedObserver;
function getSharedObserver() {
    if (!sharedObserver) {
        sharedObserver = new ResizeObserver((entries) => {
            for (const entry of entries) {
                const el = entry.target;
                const entryData = observerMap.get(el);
                if (!entryData)
                    continue;
                let width;
                let height;
                if ('borderBoxSize' in entry) {
                    // Iron out differences between browsers
                    const borderSize = Array.isArray(entry.borderBoxSize) ? entry.borderBoxSize[0] : entry.borderBoxSize;
                    width = borderSize.inlineSize;
                    height = borderSize.blockSize;
                }
                else {
                    width = el.offsetWidth;
                    height = el.offsetHeight;
                }
                entryData.size.set({ width, height });
            }
        });
    }
    return sharedObserver;
}

const OPPOSITE_SIDE = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' };
const MENU_SIDE = new InjectionToken('SpartanMenuSide');
// derive data-side from the transform-origin CDK sets on the content. the anchored corner faces the
// trigger, so the side is its opposite. the configured `side` tells us which axis carries the anchor
// (top/bottom -> vertical token, left/right -> horizontal), so a CDK flip is read off the right axis.
// CDK's origin is rtl-aware, so the derived side is too. falls back to the configured side when the
// transform-origin is missing or centered (no flip information to apply).
const deriveMenuSideFromTransformOrigin = (transformOrigin, side) => {
    const [x, y] = transformOrigin.trim().split(/\s+/);
    const anchor = side === 'top' || side === 'bottom' ? y : x;
    return OPPOSITE_SIDE[anchor] ?? side;
};
const createMenuPosition = (align, side) => {
    const verticalAlign = align === 'start' ? 'top' : align === 'end' ? 'bottom' : 'center';
    const createPositions = (originX, originY, overlayX, overlayY) => [
        { originX, originY, overlayX, overlayY },
        { originX: overlayX, originY: overlayY, overlayX: originX, overlayY: originY },
    ];
    switch (side) {
        case 'top':
            return createPositions(align, 'top', align, 'bottom');
        case 'bottom':
            return createPositions(align, 'bottom', align, 'top');
        case 'left':
            return createPositions('start', verticalAlign, 'end', verticalAlign);
        case 'right':
            return createPositions('end', verticalAlign, 'start', verticalAlign);
    }
};

function stringifyAsLabel(item, itemToStringLabel) {
    if (itemToStringLabel && item !== null && item !== undefined) {
        return itemToStringLabel(item) ?? '';
    }
    if (item && typeof item === 'object') {
        if ('label' in item && item.label !== null && item.label !== undefined) {
            return String(item.label);
        }
        if ('value' in item && item.value !== null && item.value !== undefined) {
            return String(item.value);
        }
    }
    return serializeValue(item);
}
function serializeValue(value) {
    if (value === null || value === undefined) {
        return '';
    }
    if (typeof value === 'string') {
        return value;
    }
    try {
        return JSON.stringify(value);
    }
    catch {
        return String(value);
    }
}

/** Must be called in an injection context; cleans up its pending timer on destroy. */
function injectSkipDelay(skipDelayDuration) {
    const isOpenDelayed = signal(true, ...(ngDevMode ? [{ debugName: "isOpenDelayed" }] : /* istanbul ignore next */ []));
    let timer;
    inject(DestroyRef).onDestroy(() => clearTimeout(timer));
    return {
        isOpenDelayed: isOpenDelayed.asReadonly(),
        open() {
            clearTimeout(timer);
            if (skipDelayDuration() > 0)
                isOpenDelayed.set(false);
        },
        close() {
            clearTimeout(timer);
            const duration = skipDelayDuration();
            if (duration > 0) {
                timer = setTimeout(() => isOpenDelayed.set(true), duration);
            }
        },
    };
}

const [injectTableClassesSettable, provideTableClassesSettable, provideTableClassesSettableExisting, SET_TABLE_CLASSES_TOKEN,] = createInjectionToken('@spartan-ng SET_TABLE_CLASSES_TOKEN');

const MAX_ANIMATION_WAIT_MS = 5_000;
const ANIMATION_WAIT_BUFFER_MS = 50;
function getActiveElementAnimations(elements) {
    return elements
        .filter((element) => !!element)
        .flatMap((element) => typeof element.getAnimations === 'function'
        ? element.getAnimations({ subtree: true }).filter((animation) => animation.playState !== 'finished')
        : []);
}
async function waitForAnimations(animations) {
    if (!animations.length)
        return;
    let timeout;
    const fallbackMs = getFallbackTimeout(animations);
    try {
        await Promise.race([
            Promise.allSettled(animations.map((animation) => animation.finished)),
            new Promise((resolve) => {
                timeout = setTimeout(resolve, fallbackMs);
            }),
        ]);
    }
    finally {
        if (timeout)
            clearTimeout(timeout);
    }
}
/**
 * Waits for active animations, including subtree animations, within the given element to finish.
 */
async function waitForElementAnimations(element) {
    await waitForAnimations(getActiveElementAnimations([element]));
}
function getFallbackTimeout(animations) {
    const longestAnimation = animations.reduce((longest, animation) => {
        const endTime = animation.effect?.getComputedTiming().endTime;
        return typeof endTime === 'number' && Number.isFinite(endTime) ? Math.max(longest, endTime) : longest;
    }, 0);
    if (!longestAnimation)
        return MAX_ANIMATION_WAIT_MS;
    return Math.min(longestAnimation + ANIMATION_WAIT_BUFFER_MS, MAX_ANIMATION_WAIT_MS);
}

/**
 * Generated bundle index. Do not edit.
 */

export { EXPOSES_SIDE_TOKEN, EXPOSES_STATE_TOKEN, MENU_SIDE, SET_CLASS_TO_CUSTOM_ELEMENT_TOKEN, SET_TABLE_CLASSES_TOKEN, brnDevMode, brnZoneFree, brnZoneFull, brnZoneOptimized, computedPrevious, createHoverObservable, createMenuPosition, cssClassesToArray, debouncedSignal, deriveMenuSideFromTransformOrigin, getActiveElementAnimations, injectContentDimensions, injectCustomClassSettable, injectElementSize, injectExposedSideProvider, injectExposesStateProvider, injectSkipDelay, injectTableClassesSettable, isElement, provideCustomClassSettable, provideCustomClassSettableExisting, provideExposedSideProvider, provideExposedSideProviderExisting, provideExposesStateProvider, provideExposesStateProviderExisting, provideTableClassesSettable, provideTableClassesSettableExisting, serializeValue, stringifyAsLabel, waitForAnimations, waitForElementAnimations };
//# sourceMappingURL=spartan-ng-brain-core.mjs.map
