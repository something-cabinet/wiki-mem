import { InjectionToken, inject } from '@angular/core';

class BrnNativeDateAdapter {
    /**
     * Create a new date time object.
     */
    create({ day, hour, minute, month, second, year, millisecond }) {
        const now = new Date();
        return new Date(year ?? now.getFullYear(), month ?? now.getMonth(), day ?? now.getDate(), hour ?? now.getHours(), minute ?? now.getMinutes(), second ?? now.getSeconds(), millisecond ?? now.getMilliseconds());
    }
    /**
     * Create a new date with the current date and time.
     */
    now() {
        return new Date();
    }
    /**
     * Set the year of the date time object based on a duration.
     */
    set(date, values) {
        return new Date(values.year ?? date.getFullYear(), values.month ?? date.getMonth(), values.day ?? date.getDate(), values.hour ?? date.getHours(), values.minute ?? date.getMinutes(), values.second ?? date.getSeconds(), values.millisecond ?? date.getMilliseconds());
    }
    /**
     * Add a duration to the date time object.
     */
    add(date, duration) {
        return new Date(date.getFullYear() + (duration.years ?? 0), date.getMonth() + (duration.months ?? 0), date.getDate() + (duration.days ?? 0), date.getHours() + (duration.hours ?? 0), date.getMinutes() + (duration.minutes ?? 0), date.getSeconds() + (duration.seconds ?? 0), date.getMilliseconds() + (duration.milliseconds ?? 0));
    }
    /**
     * Subtract a duration from the date time object
     */
    subtract(date, duration) {
        return new Date(date.getFullYear() - (duration.years ?? 0), date.getMonth() - (duration.months ?? 0), date.getDate() - (duration.days ?? 0), date.getHours() - (duration.hours ?? 0), date.getMinutes() - (duration.minutes ?? 0), date.getSeconds() - (duration.seconds ?? 0), date.getMilliseconds() - (duration.milliseconds ?? 0));
    }
    /**
     * Compare two date time objects
     */
    compare(a, b) {
        const diff = a.getTime() - b.getTime();
        return diff === 0 ? 0 : diff > 0 ? 1 : -1;
    }
    /**
     * Determine if two date time objects are equal.
     */
    isEqual(a, b) {
        return a.getTime() === b.getTime();
    }
    /**
     * Determine if a date time object is before another.
     */
    isBefore(a, b) {
        return a.getTime() < b.getTime();
    }
    /**
     * Determine if a date time object is after another.
     */
    isAfter(a, b) {
        return a.getTime() > b.getTime();
    }
    /**
     * Determine if two date objects are on the same day.
     */
    isSameDay(a, b) {
        return this.isSameYear(a, b) && this.isSameMonth(a, b) && a.getDate() === b.getDate();
    }
    /**
     * Determine if two date objects are on the same month.
     */
    isSameMonth(a, b) {
        return this.isSameYear(a, b) && a.getMonth() === b.getMonth();
    }
    /**
     * Determine if two date objects are on the same year.
     */
    isSameYear(a, b) {
        return a.getFullYear() === b.getFullYear();
    }
    /**
     * Get the year.
     */
    getYear(date) {
        return date.getFullYear();
    }
    /**
     * Get the month.
     */
    getMonth(date) {
        return date.getMonth();
    }
    /**
     * Get the day.
     */
    getDay(date) {
        return date.getDay();
    }
    /**
     * Get the date.
     */
    getDate(date) {
        return date.getDate();
    }
    /**
     * Get the hours.
     */
    getHours(date) {
        return date.getHours();
    }
    /**
     * Get the minutes.
     */
    getMinutes(date) {
        return date.getMinutes();
    }
    /**
     * Get the seconds.
     */
    getSeconds(date) {
        return date.getSeconds();
    }
    /**
     * Get the milliseconds.
     */
    getMilliseconds(date) {
        return date.getMilliseconds();
    }
    /**
     * Get the first day of the month.
     */
    startOfMonth(date) {
        return new Date(date.getFullYear(), date.getMonth(), 1);
    }
    /**
     * Get the last day of the month.
     */
    endOfMonth(date) {
        return new Date(date.getFullYear(), date.getMonth() + 1, 0);
    }
    /**
     * Get the start of the day.
     */
    startOfDay(date) {
        return new Date(date.getFullYear(), date.getMonth(), date.getDate());
    }
    /**
     * Get the end of the day.
     */
    endOfDay(date) {
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59, 999);
    }
    /**
     * Get the time.
     */
    getTime(date) {
        return date.getTime();
    }
}

class BrnUtcDateAdapter {
    create({ day, hour, minute, month, second, year, millisecond }) {
        const now = new Date();
        const utcTime = Date.UTC(year ?? now.getUTCFullYear(), month ?? now.getUTCMonth(), day ?? now.getUTCDate(), hour ?? now.getUTCHours(), minute ?? now.getUTCMinutes(), second ?? now.getUTCSeconds(), millisecond ?? now.getUTCMilliseconds());
        return new Date(utcTime);
    }
    now() {
        return new Date(Date.now());
    }
    set(date, values) {
        const utcTime = Date.UTC(values.year ?? date.getUTCFullYear(), values.month ?? date.getUTCMonth(), values.day ?? date.getUTCDate(), values.hour ?? date.getUTCHours(), values.minute ?? date.getUTCMinutes(), values.second ?? date.getUTCSeconds(), values.millisecond ?? date.getUTCMilliseconds());
        return new Date(utcTime);
    }
    add(date, duration) {
        return new Date(Date.UTC(date.getUTCFullYear() + (duration.years ?? 0), date.getUTCMonth() + (duration.months ?? 0), date.getUTCDate() + (duration.days ?? 0), date.getUTCHours() + (duration.hours ?? 0), date.getUTCMinutes() + (duration.minutes ?? 0), date.getUTCSeconds() + (duration.seconds ?? 0), date.getUTCMilliseconds() + (duration.milliseconds ?? 0)));
    }
    subtract(date, duration) {
        return new Date(Date.UTC(date.getUTCFullYear() - (duration.years ?? 0), date.getUTCMonth() - (duration.months ?? 0), date.getUTCDate() - (duration.days ?? 0), date.getUTCHours() - (duration.hours ?? 0), date.getUTCMinutes() - (duration.minutes ?? 0), date.getUTCSeconds() - (duration.seconds ?? 0), date.getUTCMilliseconds() - (duration.milliseconds ?? 0)));
    }
    compare(a, b) {
        const diff = a.getTime() - b.getTime();
        return diff === 0 ? 0 : diff > 0 ? 1 : -1;
    }
    isEqual(a, b) {
        return a.getTime() === b.getTime();
    }
    isBefore(a, b) {
        return a.getTime() < b.getTime();
    }
    isAfter(a, b) {
        return a.getTime() > b.getTime();
    }
    isSameDay(a, b) {
        return this.isSameYear(a, b) && this.isSameMonth(a, b) && a.getUTCDate() === b.getUTCDate();
    }
    isSameMonth(a, b) {
        return this.isSameYear(a, b) && a.getUTCMonth() === b.getUTCMonth();
    }
    isSameYear(a, b) {
        return a.getUTCFullYear() === b.getUTCFullYear();
    }
    getYear(date) {
        return date.getUTCFullYear();
    }
    getMonth(date) {
        return date.getUTCMonth();
    }
    getDay(date) {
        return date.getUTCDay();
    }
    getDate(date) {
        return date.getUTCDate();
    }
    getHours(date) {
        return date.getUTCHours();
    }
    getMinutes(date) {
        return date.getUTCMinutes();
    }
    getSeconds(date) {
        return date.getUTCSeconds();
    }
    getMilliseconds(date) {
        return date.getUTCMilliseconds();
    }
    getTime(date) {
        return date.getTime();
    }
    startOfMonth(date) {
        return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), 1));
    }
    endOfMonth(date) {
        return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 0, 23, 59, 59, 999));
    }
    startOfDay(date) {
        return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
    }
    endOfDay(date) {
        return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), 23, 59, 59, 999));
    }
}

const BrnDateAdapterToken = new InjectionToken('BrnDateAdapterToken');
/**
 * Inject the DateAdapter instance
 */
function injectDateAdapter() {
    return inject(BrnDateAdapterToken, { optional: true }) ?? new BrnNativeDateAdapter();
}
/**
 * Provide the DateAdapter instance
 */
function provideDateAdapter(adapter) {
    return { provide: BrnDateAdapterToken, useClass: adapter };
}
/**
 * Provide the native date adapter
 */
function provideNativeDateAdapter() {
    return provideDateAdapter(BrnNativeDateAdapter);
}
/**
 * Provide the UTC date adapter
 */
function provideUtcDateAdapter() {
    return provideDateAdapter(BrnUtcDateAdapter);
}

const PersianDate = {
    gregorianDaysInMonth: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
    jalaliDaysInMonth: [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29],
    jalaliToGregorian: function (jalaliYear, jalaliMonth, jalaliDay) {
        const jalaliYearDelta = jalaliYear - 979;
        const jalaliMonthIdx = jalaliMonth - 1;
        const jalaliDayIdx = jalaliDay - 1;
        let jalaliDayNo = 365 * jalaliYearDelta + Math.floor(jalaliYearDelta / 33) * 8 + Math.floor(((jalaliYearDelta % 33) + 3) / 4);
        for (let i = 0; i < jalaliMonthIdx; ++i)
            jalaliDayNo += this.jalaliDaysInMonth[i];
        jalaliDayNo += jalaliDayIdx;
        let gregorianDayNo = jalaliDayNo + 79;
        let gregorianYear = 1600 + 400 * Math.floor(gregorianDayNo / 146097);
        gregorianDayNo = gregorianDayNo % 146097;
        let leap = true;
        if (gregorianDayNo >= 36525) {
            gregorianDayNo--;
            gregorianYear += 100 * Math.floor(gregorianDayNo / 36524);
            gregorianDayNo = gregorianDayNo % 36524;
            if (gregorianDayNo >= 365)
                gregorianDayNo++;
            else
                leap = false;
        }
        gregorianYear += 4 * Math.floor(gregorianDayNo / 1461);
        gregorianDayNo %= 1461;
        if (gregorianDayNo >= 366) {
            leap = false;
            gregorianDayNo--;
            gregorianYear += Math.floor(gregorianDayNo / 365);
            gregorianDayNo = gregorianDayNo % 365;
        }
        let i = 0;
        for (; gregorianDayNo >= this.gregorianDaysInMonth[i] + (i === 1 && leap ? 1 : 0); i++) {
            gregorianDayNo -= this.gregorianDaysInMonth[i] + (i === 1 && leap ? 1 : 0);
        }
        const gregorianMonth = i + 1;
        const gregorianDay = gregorianDayNo + 1;
        return [gregorianYear, gregorianMonth, gregorianDay];
    },
    gregorianToJalali: function (gregorianYear, gregorianMonth, gregorianDay) {
        const gregorianYearDelta = gregorianYear - 1600;
        const gregorianMonthIdx = gregorianMonth - 1;
        const gregorianDayIdx = gregorianDay - 1;
        let gregorianDayNo = 365 * gregorianYearDelta +
            Math.floor((gregorianYearDelta + 3) / 4) -
            Math.floor((gregorianYearDelta + 99) / 100) +
            Math.floor((gregorianYearDelta + 399) / 400);
        for (let i = 0; i < gregorianMonthIdx; ++i)
            gregorianDayNo += this.gregorianDaysInMonth[i];
        if (gregorianMonthIdx > 1 &&
            ((gregorianYearDelta % 4 === 0 && gregorianYearDelta % 100 !== 0) || gregorianYearDelta % 400 === 0))
            gregorianDayNo++;
        gregorianDayNo += gregorianDayIdx;
        let jalaliDayNo = gregorianDayNo - 79;
        const jalaliCycleCount = Math.floor(jalaliDayNo / 12053);
        jalaliDayNo = jalaliDayNo % 12053;
        let jalaliYear = 979 + 33 * jalaliCycleCount + 4 * Math.floor(jalaliDayNo / 1461);
        jalaliDayNo %= 1461;
        if (jalaliDayNo >= 366) {
            jalaliYear += Math.floor((jalaliDayNo - 1) / 365);
            jalaliDayNo = (jalaliDayNo - 1) % 365;
        }
        let i = 0;
        for (; i < 11 && jalaliDayNo >= this.jalaliDaysInMonth[i]; ++i) {
            jalaliDayNo -= this.jalaliDaysInMonth[i];
        }
        const jalaliMonth = i + 1;
        const jalaliDay = jalaliDayNo + 1;
        return [jalaliYear, jalaliMonth, jalaliDay];
    },
    isLeapJalaliYear: function (year) {
        const breaks = [1, 5, 9, 13, 17, 22, 26, 30];
        return breaks.includes(year % 33);
    },
    getDaysInMonth: function (year, month) {
        if (month < 1 || month > 12)
            return 0;
        if (month <= 6)
            return 31;
        if (month <= 11)
            return 30;
        return this.isLeapJalaliYear(year) ? 30 : 29;
    },
    getDayOfWeek: function (jalaliYear, jalaliMonth, jalaliDay) {
        const [gregorianYear, gregorianMonth, gregorianDay] = this.jalaliToGregorian(jalaliYear, jalaliMonth, jalaliDay);
        const date = new Date(gregorianYear, gregorianMonth - 1, gregorianDay);
        return date.getDay();
    },
    getDaysInYear: function (year) {
        return this.isLeapJalaliYear(year) ? 366 : 365;
    },
    isValidDate: function (year, month, day) {
        if (year < 0 || month < 1 || month > 12 || day < 1)
            return false;
        return day <= this.getDaysInMonth(year, month);
    },
};

class JalaliDate {
    year;
    month;
    day;
    constructor(year, month, day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }
    valueOf() {
        const [gregorianYear, gregorianMonth, gregorianDay] = PersianDate.jalaliToGregorian(this.year, this.month, this.day);
        return new Date(gregorianYear, gregorianMonth - 1, gregorianDay).getTime();
    }
    toString() {
        return `${this.year}/${String(this.month).padStart(2, '0')}/${String(this.day).padStart(2, '0')}`;
    }
}

class BrnJalaliDateAdapter {
    create({ year, month, day }) {
        const now = this.now();
        const m = month !== undefined ? month + 1 : now.month;
        return this._constrain(year ?? now.year, m, day ?? now.day);
    }
    now() {
        const today = new Date();
        const [jalaliYear, jalaliMonth, jalaliDay] = PersianDate.gregorianToJalali(today.getFullYear(), today.getMonth() + 1, today.getDate());
        return this._constrain(jalaliYear, jalaliMonth, jalaliDay);
    }
    set(date, values) {
        const year = values.year ?? date.year;
        const month = values.month !== undefined ? values.month + 1 : date.month;
        const day = values.day ?? date.day;
        return this._constrain(year, month, day);
    }
    add(date, duration) {
        let { year, month, day } = date;
        if (duration.years) {
            year += duration.years;
        }
        if (duration.months) {
            month += duration.months;
            if (month > 12) {
                year += Math.floor((month - 1) / 12);
                month = ((month - 1) % 12) + 1;
            }
            else if (month < 1) {
                year += Math.floor((month - 1) / 12);
                month = ((((month - 1) % 12) + 12) % 12) + 1;
            }
            day = Math.min(day, PersianDate.getDaysInMonth(year, month));
        }
        if (duration.days) {
            const [gregorianYear, gregorianMonth, gregorianDay] = PersianDate.jalaliToGregorian(year, month, day);
            const jsDate = new Date(gregorianYear, gregorianMonth - 1, gregorianDay);
            jsDate.setDate(jsDate.getDate() + duration.days);
            [year, month, day] = PersianDate.gregorianToJalali(jsDate.getFullYear(), jsDate.getMonth() + 1, jsDate.getDate());
        }
        return this._constrain(year, month, day);
    }
    subtract(date, duration) {
        return this.add(date, {
            years: duration.years ? -duration.years : undefined,
            months: duration.months ? -duration.months : undefined,
            days: duration.days ? -duration.days : undefined,
        });
    }
    compare(a, b) {
        const diff = a.valueOf() - b.valueOf();
        return diff === 0 ? 0 : diff > 0 ? 1 : -1;
    }
    isEqual(a, b) {
        return a.valueOf() === b.valueOf();
    }
    isBefore(a, b) {
        return a.valueOf() < b.valueOf();
    }
    isAfter(a, b) {
        return a.valueOf() > b.valueOf();
    }
    isSameDay(a, b) {
        return a.year === b.year && a.month === b.month && a.day === b.day;
    }
    isSameMonth(a, b) {
        return a.year === b.year && a.month === b.month;
    }
    isSameYear(a, b) {
        return a.year === b.year;
    }
    getYear(date) {
        return date.year;
    }
    getMonth(date) {
        return date.month - 1;
    }
    getDate(date) {
        return date.day;
    }
    getDay(date) {
        const [gregorianYear, gregorianMonth, gregorianDay] = PersianDate.jalaliToGregorian(date.year, date.month, date.day);
        return new Date(gregorianYear, gregorianMonth - 1, gregorianDay).getDay();
    }
    getHours(_date) {
        return 0;
    }
    getMinutes(_date) {
        return 0;
    }
    getSeconds(_date) {
        return 0;
    }
    getMilliseconds(_date) {
        return 0;
    }
    getTime(date) {
        return date.valueOf();
    }
    startOfMonth(date) {
        return new JalaliDate(date.year, date.month, 1);
    }
    endOfMonth(date) {
        return new JalaliDate(date.year, date.month, PersianDate.getDaysInMonth(date.year, date.month));
    }
    startOfDay(date) {
        return date;
    }
    endOfDay(date) {
        return date;
    }
    _constrain(year, month, day) {
        const maxDay = PersianDate.getDaysInMonth(year, month);
        return new JalaliDate(year, month, Math.min(day, maxDay));
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { BrnDateAdapterToken, BrnJalaliDateAdapter, BrnNativeDateAdapter, BrnUtcDateAdapter, JalaliDate, PersianDate, injectDateAdapter, provideDateAdapter, provideNativeDateAdapter, provideUtcDateAdapter };
//# sourceMappingURL=spartan-ng-brain-date-time.mjs.map
