import * as _spartan_ng_brain_forms from '@spartan-ng/brain/forms';
import { ControlState, ChangeFn, TouchFn } from '@spartan-ng/brain/forms';
import * as _angular_core from '@angular/core';
import { InputSignal, Signal, ModelSignal, InjectionToken, Type, ExistingProvider, ValueProvider, ElementRef } from '@angular/core';
import { Highlightable, ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import { BooleanInput } from '@angular/cdk/coercion';
import { ControlValueAccessor } from '@angular/forms';
import * as i1 from '@spartan-ng/brain/field';

declare class BrnComboboxChipInput<T> {
    private static _id;
    private readonly _el;
    private readonly _combobox;
    /** The id of the combobox input */
    readonly id: _angular_core.InputSignal<string>;
    /** Manual override for aria-invalid. When not set, auto-detects from the parent combobox error state. */
    readonly ariaInvalidOverride: _angular_core.InputSignalWithTransform<boolean | undefined, BooleanInput>;
    /** Computed aria-invalid: uses manual override if provided, otherwise reads from parent error state. */
    protected readonly _ariaInvalid: _angular_core.Signal<boolean | undefined>;
    protected readonly _dirty: _angular_core.Signal<boolean | undefined>;
    protected readonly _touched: _angular_core.Signal<boolean | undefined>;
    protected readonly _spartanInvalid: _angular_core.Signal<boolean | undefined>;
    protected readonly _disabled: _angular_core.Signal<boolean>;
    /** Whether the combobox panel is expanded */
    protected readonly _isExpanded: _angular_core.Signal<boolean>;
    constructor();
    protected onInput(event: Event): void;
    /** Listen for keydown events */
    protected onKeyDown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxChipInput<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxChipInput<any>, "input[brnComboboxChipInput]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaInvalidOverride": { "alias": "aria-invalid"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnComboboxItem<T> implements Highlightable {
    private static _id;
    private readonly _platform;
    private readonly _elementRef;
    /** Access the combobox component */
    private readonly _combobox;
    /** A unique id for the item */
    readonly id: _angular_core.InputSignal<string>;
    /** The value this item represents. */
    readonly value: _angular_core.InputSignal<T>;
    readonly _disabled: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Expose disabled as a value - used by the Highlightable interface */
    get disabled(): boolean;
    /** Whether the item is selected. */
    readonly active: _angular_core.Signal<boolean>;
    protected readonly _highlighted: _angular_core.WritableSignal<boolean>;
    /** @internal Determine if this item is visible based on the current search query */
    readonly visible: _angular_core.Signal<boolean>;
    setActiveStyles(): void;
    setInactiveStyles(): void;
    getLabel(): string;
    protected select(): void;
    protected activate(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxItem<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxItem<any>, "[brnComboboxItem]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": true; "isSignal": true; }; "_disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type ComboboxInputMode = 'combobox' | 'popup';
interface BrnComboboxBase<T> {
    filter: InputSignal<ComboboxFilter<T>>;
    itemToString: InputSignal<ComboboxItemToString<T> | undefined>;
    collator: Signal<Intl.Collator>;
    search: ModelSignal<string>;
    disabled: Signal<boolean>;
    disabledState: Signal<boolean>;
    keyManager: ActiveDescendantKeyManager<BrnComboboxItem<T>>;
    value: ModelSignal<T | undefined | null> | ModelSignal<T[] | undefined | null>;
    visibleItems: Signal<boolean>;
    isExpanded: Signal<boolean>;
    searchInputWrapperWidth: Signal<number | null>;
    mode: Signal<ComboboxInputMode>;
    controlState?: Signal<ControlState | null>;
    hasValue: Signal<boolean>;
    isSelected: (itemValue: T) => boolean;
    select: (itemValue: T) => void;
    open: () => void;
    resetValue: () => void;
    resetSearch: () => void;
    /** Select the active item with Enter key. */
    selectActiveItem: () => void;
    /** Remove last selected item with Backspace key. Only works with multiple selection comboboxes. */
    removeLastSelectedItem: () => void;
    removeValue: (value: T) => void;
    /** Register the combobox input component for single selection mode */
    registerComboboxInput?: (input: BrnComboboxInput<T>) => void;
    /** Register the combobox chip input component for multi selection mode */
    registerComboboxChipInput?: (input: BrnComboboxChipInput<T>) => void;
    updateInputWidth: (width: number | null) => void;
}
declare const BrnComboboxBaseToken: InjectionToken<BrnComboboxBase<unknown>>;
declare function provideBrnComboboxBase<T>(instance: Type<BrnComboboxBase<T>>): ExistingProvider;
/**
 * Inject the combobox component.
 */
declare function injectBrnComboboxBase<T>(): BrnComboboxBase<T>;
interface ComboboxFilterOptions extends Intl.CollatorOptions {
    /**
     * The locale to use for string comparison.
     * Defaults to the user's runtime locale.
     */
    locale?: Intl.LocalesArgument;
}
type ComboboxFilter<T> = (itemValue: T, search: string, collator: Intl.Collator, itemToString?: ComboboxItemToString<T>) => boolean;
type ComboboxItemEqualToValue<T> = (itemValue: T, selectedValue: T | undefined | null) => boolean;
type ComboboxItemToString<T> = (itemValue: T) => string;
interface BrnComboboxConfig<T> {
    filterOptions: ComboboxFilterOptions;
    filter: ComboboxFilter<T>;
    isItemEqualToValue: ComboboxItemEqualToValue<T>;
    /**
     * Determines whether a single value is present (i.e., has been selected).
     * Considers `undefined`, `null`, and empty string as "not present".
     * Only used by single-select combobox in popup mode, ignored by the multiple select variant.
     */
    isSingleValuePresent: (value: T | undefined | null) => boolean;
    itemToString?: ComboboxItemToString<T>;
    autoHighlight: boolean;
    /** Whether to reset the search and close the popover after selecting an item when the search is active. */
    closeOnSelect: boolean;
}
declare function provideBrnComboboxConfig<T>(config: Partial<BrnComboboxConfig<T>>): ValueProvider;
declare function injectBrnComboboxConfig<T>(): BrnComboboxConfig<T>;

declare class BrnComboboxInput<T> {
    private static _id;
    private readonly _el;
    private readonly _combobox;
    private readonly _content;
    readonly mode: _angular_core.Signal<ComboboxInputMode>;
    /** The id of the combobox input */
    readonly id: _angular_core.InputSignal<string>;
    /** Manual override for aria-invalid. When not set, auto-detects from the parent combobox error state. */
    readonly ariaInvalidOverride: _angular_core.InputSignalWithTransform<boolean | undefined, BooleanInput>;
    /** Forces the invalid state visually, regardless of form control state. */
    readonly forceInvalid: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    readonly disabled: _angular_core.Signal<boolean>;
    /** Whether the combobox panel is expanded */
    protected readonly _isExpanded: _angular_core.Signal<boolean>;
    /** Computed aria-invalid: uses manual override if provided, otherwise reads from parent error state. */
    protected readonly _ariaInvalid: _angular_core.Signal<boolean | undefined>;
    protected readonly _dirty: _angular_core.Signal<boolean | undefined>;
    protected readonly _touched: _angular_core.Signal<boolean | undefined>;
    protected readonly _spartanInvalid: _angular_core.Signal<boolean | undefined>;
    constructor();
    protected onInput(event: Event): void;
    /** Listen for keydown events */
    protected onKeyDown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxInput<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxInput<any>, "input[brnComboboxInput]", ["brnComboboxInput"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaInvalidOverride": { "alias": "aria-invalid"; "required": false; "isSignal": true; }; "forceInvalid": { "alias": "forceInvalid"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const BRN_COMBOBOX_VALUE_ACCESSOR: {
    provide: _angular_core.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: _angular_core.Type<any>;
    multi: boolean;
};
declare class BrnCombobox<T> implements BrnComboboxBase<T>, ControlValueAccessor {
    private readonly _injector;
    private readonly _fieldControl;
    private readonly _config;
    /** Access the popover if present */
    private readonly _brnPopover;
    readonly controlState: _angular_core.Signal<_spartan_ng_brain_forms.ControlState | null> | undefined;
    /** Whether the combobox is disabled */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    protected readonly _disabled: _angular_core.WritableSignal<boolean>;
    /** @internal The disabled state as a readonly signal */
    readonly disabledState: _angular_core.Signal<boolean>;
    /** Options for filtering the combobox items */
    readonly filterOptions: _angular_core.InputSignal<ComboboxFilterOptions>;
    /** @internal The collator used for string comparison */
    readonly collator: _angular_core.Signal<Intl.Collator>;
    /** A function to compare an item with the selected value. */
    readonly isItemEqualToValue: _angular_core.InputSignal<ComboboxItemEqualToValue<T>>;
    /** A function to convert an item to a string for display. */
    readonly itemToString: _angular_core.InputSignal<ComboboxItemToString<T> | undefined>;
    /** A custom filter function to use when searching. */
    readonly filter: _angular_core.InputSignal<ComboboxFilter<T>>;
    /** Whether to auto-highlight the first matching item. */
    readonly autoHighlight: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Whether to close the popover after selecting an item. */
    readonly closeOnSelect: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** The selected value of the combobox. */
    readonly value: _angular_core.ModelSignal<T | null | undefined>;
    /**
     * Determines whether a single value is present (i.e., has been selected).
     * Considers `undefined`, `null`, and empty string as "not present".
     * Only used by single-select combobox in popup mode, ignored by the multiple select variant.
     */
    readonly isSingleValuePresent: _angular_core.InputSignal<(value: T | undefined | null) => boolean>;
    readonly hasValue: _angular_core.Signal<boolean>;
    /** The current search query. */
    readonly search: _angular_core.ModelSignal<string>;
    private readonly _inputWidth;
    /** @internal The width of the search input wrapper */
    readonly searchInputWrapperWidth: _angular_core.Signal<number | null>;
    /** @internal Access all the items within the combobox */
    readonly items: _angular_core.Signal<readonly BrnComboboxItem<T>[]>;
    private readonly _content;
    /** Determine if the combobox has any visible items */
    readonly visibleItems: _angular_core.Signal<boolean>;
    /** @internal The key manager for managing active descendant */
    readonly keyManager: ActiveDescendantKeyManager<BrnComboboxItem<T>>;
    /** @internal Whether the combobox is expanded */
    readonly isExpanded: _angular_core.Signal<boolean>;
    private readonly _comboboxInput;
    readonly mode: _angular_core.Signal<ComboboxInputMode>;
    readonly labelableId: _angular_core.Signal<string | undefined>;
    protected _onChange?: ChangeFn<T | undefined | null>;
    protected _onTouched?: TouchFn;
    constructor();
    registerComboboxInput(input: BrnComboboxInput<T>): void;
    updateInputWidth(width: number | null): void;
    isSelected(itemValue: T): boolean;
    select(itemValue: T): void;
    /** Select the active item with Enter key. */
    selectActiveItem(): void;
    resetValue(): void;
    resetSearch(): void;
    removeValue(_: T): void;
    removeLastSelectedItem(): void;
    open(): void;
    /** CONTROL VALUE ACCESSOR */
    writeValue(value: T | undefined | null): void;
    registerOnChange(fn: ChangeFn<T | undefined | null>): void;
    registerOnTouched(fn: TouchFn): void;
    setDisabledState(isDisabled: boolean): void;
    protected _onFocusOut(event: FocusEvent): void;
    private close;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnCombobox<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnCombobox<any>, "[brnCombobox]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "filterOptions": { "alias": "filterOptions"; "required": false; "isSignal": true; }; "isItemEqualToValue": { "alias": "isItemEqualToValue"; "required": false; "isSignal": true; }; "itemToString": { "alias": "itemToString"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "autoHighlight": { "alias": "autoHighlight"; "required": false; "isSignal": true; }; "closeOnSelect": { "alias": "closeOnSelect"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "isSingleValuePresent": { "alias": "isSingleValuePresent"; "required": false; "isSignal": true; }; "search": { "alias": "search"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "search": "searchChange"; }, ["items", "_content"], never, true, [{ directive: typeof i1.BrnFieldControl; inputs: {}; outputs: {}; }]>;
}

declare class BrnComboboxAnchor {
    private readonly _host;
    private readonly _brnOverlay;
    private readonly _content;
    private readonly _combobox;
    private readonly _elementSize;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxAnchor, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxAnchor, "[brnComboboxAnchor]", never, {}, {}, never, never, true, never>;
}

declare class BrnComboboxChip<T> {
    private readonly _combobox;
    protected readonly _disabled: _angular_core.Signal<boolean>;
    readonly value: _angular_core.InputSignal<T>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxChip<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxChip<any>, "[brnComboboxChip]", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnComboboxChipRemove<T> {
    private readonly _combobox;
    private readonly _chip;
    protected readonly _disabled: _angular_core.Signal<boolean>;
    protected removeChip(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxChipRemove<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxChipRemove<any>, "button[brnComboboxChipRemove]", never, {}, {}, never, never, true, never>;
}

declare class BrnComboboxClear {
    private readonly _combobox;
    private readonly _renderer;
    private readonly _templateRef;
    private readonly _viewContainerRef;
    /** Determine if the combobox has a value */
    private readonly _shouldShowClear;
    constructor();
    private clear;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxClear, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxClear, "[brnComboboxClear]", never, {}, {}, never, never, true, never>;
}

declare class BrnComboboxContent {
    private readonly _combobox;
    readonly el: ElementRef<HTMLElement>;
    protected readonly _dataState: _angular_core.Signal<"open" | "closed">;
    /** Determine if the combobox has no visible items */
    protected readonly _isEmpty: _angular_core.Signal<boolean>;
    protected readonly _comboboxWidth: _angular_core.Signal<number | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxContent, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxContent, "[brnComboboxContent]", never, {}, {}, never, never, true, never>;
}

declare class BrnComboboxEmpty {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxEmpty, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxEmpty, "[brnComboboxEmpty]", never, {}, {}, never, never, true, never>;
}

declare class BrnComboboxGroup {
    /** Get the items in the group */
    private readonly _items;
    /** Determine if there are any visible items in the group */
    protected readonly _visible: _angular_core.Signal<boolean>;
    /** Get the label associated with the group */
    private readonly _label;
    protected readonly _labelledBy: _angular_core.Signal<string | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxGroup, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxGroup, "[brnComboboxGroup]", never, {}, {}, ["_items", "_label"], never, true, never>;
}

declare class BrnComboboxLabel {
    private static _id;
    /** The id of the combobox label */
    readonly id: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxLabel, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxLabel, "[brnComboboxLabel]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnComboboxList {
    private static _id;
    private readonly _combobox;
    /** Determine if the combobox has any visible items */
    protected readonly _visibleItems: _angular_core.Signal<boolean>;
    /** The id of the combobox list */
    readonly id: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxList, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxList, "[brnComboboxList]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const BRN_COMBOBOX_MULTIPLE_VALUE_ACCESSOR: {
    provide: _angular_core.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: _angular_core.Type<any>;
    multi: boolean;
};
declare class BrnComboboxMultiple<T> implements BrnComboboxBase<T>, ControlValueAccessor {
    private readonly _injector;
    private readonly _fieldControl;
    private readonly _config;
    /** Access the popover if present */
    private readonly _brnPopover;
    readonly controlState: _angular_core.Signal<_spartan_ng_brain_forms.ControlState | null> | undefined;
    /** Whether the combobox is disabled */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    protected readonly _disabled: _angular_core.WritableSignal<boolean>;
    /** @internal The disabled state as a readonly signal */
    readonly disabledState: _angular_core.Signal<boolean>;
    /** Options for filtering the combobox items */
    readonly filterOptions: _angular_core.InputSignal<ComboboxFilterOptions>;
    /** @internal The collator used for string comparison */
    readonly collator: _angular_core.Signal<Intl.Collator>;
    /** A function to compare an item with the selected value. */
    readonly isItemEqualToValue: _angular_core.InputSignal<ComboboxItemEqualToValue<T>>;
    /** A function to convert an item to a string for display. */
    readonly itemToString: _angular_core.InputSignal<ComboboxItemToString<T> | undefined>;
    /** A custom filter function to use when searching. */
    readonly filter: _angular_core.InputSignal<ComboboxFilter<T>>;
    /** Whether to auto-highlight the first matching item. */
    readonly autoHighlight: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Whether to reset the search and close the popover after selecting an item when the search is active. */
    readonly closeOnSelect: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** The selected values of the combobox. */
    readonly value: _angular_core.ModelSignal<T[] | null | undefined>;
    readonly hasValue: _angular_core.Signal<boolean>;
    /** The current search query. */
    readonly search: _angular_core.ModelSignal<string>;
    private readonly _inputWidth;
    /** @internal The width of the search input wrapper */
    readonly searchInputWrapperWidth: _angular_core.Signal<number | null>;
    /** @internal Access all the items within the combobox */
    readonly items: _angular_core.Signal<readonly BrnComboboxItem<T>[]>;
    private readonly _content;
    /** Determine if the combobox has any visible items */
    readonly visibleItems: _angular_core.Signal<boolean>;
    /** @internal The key manager for managing active descendant */
    readonly keyManager: ActiveDescendantKeyManager<BrnComboboxItem<T>>;
    /** @internal Whether the autocomplete is expanded */
    readonly isExpanded: _angular_core.Signal<boolean>;
    private readonly _comboboxChipInput;
    readonly mode: _angular_core.Signal<ComboboxInputMode>;
    readonly labelableId: _angular_core.Signal<string | undefined>;
    protected _onChange?: ChangeFn<T[] | undefined | null>;
    protected _onTouched?: TouchFn;
    constructor();
    registerComboboxChipInput(input: BrnComboboxChipInput<T>): void;
    updateInputWidth(width: number | null): void;
    isSelected(itemValue: T): boolean;
    select(itemValue: T): void;
    /** Select the active item with Enter key. */
    selectActiveItem(): void;
    resetValue(): void;
    resetSearch(): void;
    removeValue(itemValue: T): void;
    removeLastSelectedItem(): void;
    open(): void;
    protected _onFocusOut(event: FocusEvent): void;
    private close;
    /** CONTROL VALUE ACCESSOR */
    writeValue(value: T[] | undefined | null): void;
    registerOnChange(fn: ChangeFn<T[] | undefined | null>): void;
    registerOnTouched(fn: TouchFn): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxMultiple<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxMultiple<any>, "[brnCombobox]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "filterOptions": { "alias": "filterOptions"; "required": false; "isSignal": true; }; "isItemEqualToValue": { "alias": "isItemEqualToValue"; "required": false; "isSignal": true; }; "itemToString": { "alias": "itemToString"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "autoHighlight": { "alias": "autoHighlight"; "required": false; "isSignal": true; }; "closeOnSelect": { "alias": "closeOnSelect"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "search": { "alias": "search"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "search": "searchChange"; }, ["items", "_content"], never, true, [{ directive: typeof i1.BrnFieldControl; inputs: {}; outputs: {}; }]>;
}

declare class BrnComboboxPlaceholder {
    private readonly _combobox;
    protected readonly _hasValue: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxPlaceholder, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxPlaceholder, "[brnComboboxPlaceholder]", never, {}, {}, never, never, true, never>;
}

declare class BrnComboboxPopoverTrigger<T> {
    private readonly _combobox;
    private readonly _brnOverlay;
    /**
     * Whether clicking the trigger may close an open popover. Button triggers toggle (click again to
     * close); text-input triggers set this to `false` so clicking or typing in an open combobox only
     * ever opens it and never closes it underneath the user.
     */
    readonly closeOnTriggerClickInput: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Writable, input-synced state so the behavior can also be set programmatically. */
    readonly closeOnTriggerClick: _angular_core.WritableSignal<boolean>;
    protected _onClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxPopoverTrigger<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxPopoverTrigger<any>, "[brnComboboxPopoverTrigger]", never, { "closeOnTriggerClickInput": { "alias": "closeOnTriggerClick"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnComboboxSeparator {
    readonly orientation: _angular_core.InputSignal<"vertical" | "horizontal">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxSeparator, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxSeparator, "[brnComboboxSeparator]", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnComboboxStatus {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxStatus, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxStatus, "[brnComboboxStatus]", never, {}, {}, never, never, true, never>;
}

declare class BrnComboboxTrigger<T> {
    private readonly _combobox;
    protected readonly _isExpanded: _angular_core.Signal<boolean>;
    protected readonly _disabled: _angular_core.Signal<boolean>;
    protected readonly _isPlaceholder: _angular_core.Signal<boolean>;
    protected readonly _ariaInvalid: _angular_core.Signal<boolean | undefined>;
    protected readonly _dirty: _angular_core.Signal<boolean | undefined>;
    protected readonly _touched: _angular_core.Signal<boolean | undefined>;
    protected readonly _spartanInvalid: _angular_core.Signal<boolean | undefined>;
    readonly forceInvalid: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Listen for keydown events */
    protected onKeyDown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxTrigger<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxTrigger<any>, "button[brnComboboxTrigger]", never, { "forceInvalid": { "alias": "forceInvalid"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnComboboxValue<T> {
    private readonly _combobox;
    readonly placeholder: _angular_core.InputSignal<string>;
    protected readonly _isPlaceholder: _angular_core.Signal<boolean>;
    readonly hidden: _angular_core.Signal<boolean>;
    protected readonly _value: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxValue<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxValue<any>, "[brnComboboxValue]", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnComboboxValueTemplate<T> {
    private readonly _templateRef;
    private readonly _viewContainerRef;
    private readonly _combobox;
    protected readonly _value: _angular_core.Signal<T | null>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxValueTemplate<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxValueTemplate<any>, "[brnComboboxValueTemplate]", never, {}, {}, never, never, true, never>;
}

declare class BrnComboboxValues<T> {
    private readonly _templateRef;
    private readonly _viewContainerRef;
    private readonly _combobox;
    protected readonly _values: _angular_core.Signal<T[] | null>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnComboboxValues<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnComboboxValues<any>, "[brnComboboxValues]", never, {}, {}, never, never, true, never>;
}

type BrnComboboxFilter = <Item>(item: Item, query: string, collator: Intl.Collator, itemToString?: (item: Item) => string) => boolean;
declare const comboboxContainsFilter: BrnComboboxFilter;
declare const comboboxStartsWithFilter: BrnComboboxFilter;
declare const comboboxEndsWithFilter: BrnComboboxFilter;

declare const BrnComboboxItemToken: InjectionToken<BrnComboboxItem<unknown>>;
declare function provideBrnComboboxItem<T>(comboboxItem: Type<BrnComboboxItem<T>>): ExistingProvider;

declare const BrnComboboxImports: readonly [typeof BrnCombobox, typeof BrnComboboxAnchor, typeof BrnComboboxChip, typeof BrnComboboxChipInput, typeof BrnComboboxChipRemove, typeof BrnComboboxClear, typeof BrnComboboxContent, typeof BrnComboboxEmpty, typeof BrnComboboxGroup, typeof BrnComboboxInput, typeof BrnComboboxItem, typeof BrnComboboxLabel, typeof BrnComboboxList, typeof BrnComboboxMultiple, typeof BrnComboboxPlaceholder, typeof BrnComboboxPopoverTrigger, typeof BrnComboboxSeparator, typeof BrnComboboxStatus, typeof BrnComboboxTrigger, typeof BrnComboboxValue, typeof BrnComboboxValueTemplate, typeof BrnComboboxValues];

export { BRN_COMBOBOX_MULTIPLE_VALUE_ACCESSOR, BRN_COMBOBOX_VALUE_ACCESSOR, BrnCombobox, BrnComboboxAnchor, BrnComboboxBaseToken, BrnComboboxChip, BrnComboboxChipInput, BrnComboboxChipRemove, BrnComboboxClear, BrnComboboxContent, BrnComboboxEmpty, BrnComboboxGroup, BrnComboboxImports, BrnComboboxInput, BrnComboboxItem, BrnComboboxItemToken, BrnComboboxLabel, BrnComboboxList, BrnComboboxMultiple, BrnComboboxPlaceholder, BrnComboboxPopoverTrigger, BrnComboboxSeparator, BrnComboboxStatus, BrnComboboxTrigger, BrnComboboxValue, BrnComboboxValueTemplate, BrnComboboxValues, comboboxContainsFilter, comboboxEndsWithFilter, comboboxStartsWithFilter, injectBrnComboboxBase, injectBrnComboboxConfig, provideBrnComboboxBase, provideBrnComboboxConfig, provideBrnComboboxItem };
export type { BrnComboboxBase, BrnComboboxConfig, BrnComboboxFilter, ComboboxFilter, ComboboxFilterOptions, ComboboxInputMode, ComboboxItemEqualToValue, ComboboxItemToString };
