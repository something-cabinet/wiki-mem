import * as _spartan_ng_brain_forms from '@spartan-ng/brain/forms';
import { ControlState, ChangeFn, TouchFn } from '@spartan-ng/brain/forms';
import * as _angular_core from '@angular/core';
import { Signal, InputSignal, ModelSignal, InjectionToken, Type, ExistingProvider, ValueProvider } from '@angular/core';
import { Highlightable, ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import { BooleanInput } from '@angular/cdk/coercion';
import { ControlValueAccessor } from '@angular/forms';
import * as i1 from '@spartan-ng/brain/field';

declare class BrnSelectItem<T> implements Highlightable {
    private static _id;
    private readonly _platform;
    private readonly _elementRef;
    /** Access the select component */
    private readonly _select;
    /** A unique id for the item */
    readonly id: _angular_core.InputSignal<string>;
    /** The value this item represents. */
    readonly value: _angular_core.InputSignal<T>;
    readonly _disabled: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Expose disabled as a value - used by the Highlightable interface */
    get disabled(): boolean;
    /** Whether the item is selected. */
    readonly active: _angular_core.Signal<boolean>;
    protected readonly _highlighted: _angular_core.WritableSignal<boolean>;
    setActiveStyles(): void;
    setInactiveStyles(): void;
    getLabel(): string;
    protected select(): void;
    protected activate(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectItem<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectItem<any>, "[brnSelectItem]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": true; "isSignal": true; }; "_disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnSelectTrigger {
    private static _id;
    private readonly _host;
    private readonly _brnOverlay;
    private readonly _select;
    private readonly _elementSize;
    readonly id: _angular_core.InputSignal<string>;
    /** Whether to force the trigger into an invalid state. */
    readonly forceInvalid: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Whether the combobox panel is expanded */
    protected readonly _isExpanded: _angular_core.Signal<boolean>;
    protected readonly _disabled: _angular_core.Signal<boolean>;
    protected readonly _isPlaceholder: _angular_core.Signal<boolean>;
    protected readonly _invalid: _angular_core.Signal<boolean | undefined>;
    protected readonly _touched: _angular_core.Signal<boolean | undefined>;
    protected readonly _dirty: _angular_core.Signal<boolean | undefined>;
    protected readonly _spartanInvalid: _angular_core.Signal<boolean | undefined>;
    constructor();
    protected toggle(): void;
    protected open(): void;
    /** Listen for keydown events */
    protected onKeyDown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectTrigger, "button[brnSelectTrigger]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "forceInvalid": { "alias": "forceInvalid"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface BrnSelectBase<T> {
    disabledState: Signal<boolean>;
    itemToString: InputSignal<SelectItemToString<T> | undefined>;
    keyManager: ActiveDescendantKeyManager<BrnSelectItem<T>>;
    value: ModelSignal<T | undefined | null> | ModelSignal<T[] | undefined | null>;
    hasValue: Signal<boolean>;
    isExpanded: Signal<boolean>;
    triggerWidth: Signal<number | null>;
    controlState?: Signal<ControlState | null>;
    isSelected: (itemValue: T) => boolean;
    select: (itemValue: T) => void;
    /** Select the active item with Enter key. */
    selectActiveItem: () => void;
    open: () => void;
    close: () => void;
    toggle: () => void;
    registerSelectTrigger: (input: BrnSelectTrigger) => void;
    updateTriggerWidth: (width: number | null) => void;
}
declare const BrnSelectBaseToken: InjectionToken<BrnSelectBase<unknown>>;
declare function provideBrnSelectBase<T>(instance: Type<BrnSelectBase<T>>): ExistingProvider;
/**
 * Inject the select component.
 */
declare function injectBrnSelectBase<T>(): BrnSelectBase<T>;
type SelectItemEqualToValue<T> = (itemValue: T, selectedValue: T | undefined | null) => boolean;
type SelectItemToString<T> = (itemValue: T) => string;
interface BrnSelectConfig<T> {
    isItemEqualToValue: SelectItemEqualToValue<T>;
    /**
     * Determines whether a single value is present (i.e., has been selected).
     * Considers `undefined`, `null`, and empty string as "not present".
     * Only used by {@link BrnSelectComponent} (single select), ignored by the multiple select variant.
     */
    isSingleValuePresent: (value: T | undefined | null) => boolean;
    itemToString?: SelectItemToString<T>;
}
declare function provideBrnSelectConfig<T>(config: Partial<BrnSelectConfig<T>>): ValueProvider;
declare function injectBrnSelectConfig<T>(): BrnSelectConfig<T>;

declare const BRN_SELECT_VALUE_ACCESSOR: {
    provide: _angular_core.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: _angular_core.Type<any>;
    multi: boolean;
};
declare class BrnSelect<T> implements BrnSelectBase<T>, ControlValueAccessor {
    private readonly _injector;
    private readonly _fieldControl;
    private readonly _config;
    readonly controlState: _angular_core.Signal<_spartan_ng_brain_forms.ControlState | null> | undefined;
    /** Access the popover if present */
    private readonly _brnPopover;
    /** Whether the select is disabled */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    protected readonly _disabled: _angular_core.WritableSignal<boolean>;
    /** @internal The disabled state as a readonly signal */
    readonly disabledState: _angular_core.Signal<boolean>;
    /** The selected value of the select. */
    readonly value: _angular_core.ModelSignal<T | null | undefined>;
    /**
     * Determines whether a single value is present (i.e., has been selected).
     * Considers `undefined`, `null`, and empty string as "not present".
     * Only used by single select, ignored by the multiple select variant.
     */
    readonly isSingleValuePresent: _angular_core.InputSignal<(value: T | undefined | null) => boolean>;
    readonly hasValue: _angular_core.Signal<boolean>;
    /** A function to compare an item with the selected value. */
    readonly isItemEqualToValue: _angular_core.InputSignal<SelectItemEqualToValue<T>>;
    /** A function to convert an item to a string for display. */
    readonly itemToString: _angular_core.InputSignal<SelectItemToString<T> | undefined>;
    private readonly _triggerWidth;
    /** @internal The width of the trigger wrapper */
    readonly triggerWidth: _angular_core.Signal<number | null>;
    /** @internal Access all the items within the select */
    readonly items: _angular_core.Signal<readonly BrnSelectItem<T>[]>;
    /** @internal The key manager for managing active descendant */
    readonly keyManager: ActiveDescendantKeyManager<BrnSelectItem<T>>;
    /** @internal Whether the select is expanded */
    readonly isExpanded: _angular_core.Signal<boolean>;
    private readonly _selectTrigger;
    readonly labelableId: _angular_core.Signal<string | undefined>;
    protected _onChange?: ChangeFn<T | undefined | null>;
    protected _onTouched?: TouchFn;
    constructor();
    registerSelectTrigger(input: BrnSelectTrigger): void;
    updateTriggerWidth(width: number | null): void;
    isSelected(itemValue: T): boolean;
    select(itemValue: T): void;
    /** Select the active item with Enter key. */
    selectActiveItem(): void;
    open(): void;
    close(): void;
    toggle(): void;
    /** CONTROL VALUE ACCESSOR */
    writeValue(value: T | undefined | null): void;
    registerOnChange(fn: ChangeFn<T | undefined | null>): void;
    registerOnTouched(fn: TouchFn): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelect<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelect<any>, "[brnSelect]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "isSingleValuePresent": { "alias": "isSingleValuePresent"; "required": false; "isSignal": true; }; "isItemEqualToValue": { "alias": "isItemEqualToValue"; "required": false; "isSignal": true; }; "itemToString": { "alias": "itemToString"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, ["items"], never, true, [{ directive: typeof i1.BrnFieldControl; inputs: {}; outputs: {}; }]>;
}

declare class BrnSelectContent {
    private readonly _select;
    protected readonly _selectWidth: _angular_core.Signal<number | null>;
    private readonly _elementRef;
    private readonly _scrollUp;
    readonly showScrollUp: _angular_core.Signal<boolean>;
    private readonly _scrollDown;
    readonly showScrollDown: _angular_core.Signal<boolean>;
    protected readonly _dataState: _angular_core.Signal<"closed" | "open">;
    constructor();
    handleScroll(): void;
    private _checkScroll;
    scrollDown(stop: () => void): void;
    scrollUp(stop: () => void): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectContent, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectContent, "[brnSelectContent]", never, {}, {}, never, never, true, never>;
}

declare class BrnSelectGroup {
    private readonly _selectLabel;
    protected readonly _labelledby: _angular_core.Signal<string | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectGroup, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectGroup, "[brnSelectGroup]", never, {}, {}, ["_selectLabel"], never, true, never>;
}

declare class BrnSelectLabel {
    private static _id;
    readonly id: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectLabel, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectLabel, "[brnSelectLabel]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnSelectList {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectList, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectList, "[brnSelectList]", never, {}, {}, never, never, true, never>;
}

declare const BRN_SELECT_MULTIPLE_VALUE_ACCESSOR: {
    provide: _angular_core.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: _angular_core.Type<any>;
    multi: boolean;
};
declare class BrnSelectMultiple<T> implements BrnSelectBase<T>, ControlValueAccessor {
    private readonly _injector;
    private readonly _fieldControl;
    private readonly _config;
    readonly controlState: _angular_core.Signal<_spartan_ng_brain_forms.ControlState | null> | undefined;
    /** Access the popover if present */
    private readonly _brnPopover;
    /** Whether the combobox is disabled */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    protected readonly _disabled: _angular_core.WritableSignal<boolean>;
    /** @internal The disabled state as a readonly signal */
    readonly disabledState: _angular_core.Signal<boolean>;
    /** The selected value of the select. */
    readonly value: _angular_core.ModelSignal<T[] | null | undefined>;
    readonly hasValue: _angular_core.Signal<boolean>;
    /** A function to compare an item with the selected value. */
    readonly isItemEqualToValue: _angular_core.InputSignal<SelectItemEqualToValue<T>>;
    /** A function to convert an item to a string for display. */
    readonly itemToString: _angular_core.InputSignal<SelectItemToString<T> | undefined>;
    private readonly _triggerWidth;
    /** @internal The width of the trigger wrapper */
    readonly triggerWidth: _angular_core.Signal<number | null>;
    /** @internal Access all the items within the select */
    readonly items: _angular_core.Signal<readonly BrnSelectItem<T>[]>;
    /** @internal The key manager for managing active descendant */
    readonly keyManager: ActiveDescendantKeyManager<BrnSelectItem<T>>;
    /** @internal Whether the select is expanded */
    readonly isExpanded: _angular_core.Signal<boolean>;
    private readonly _selectTrigger;
    readonly labelableId: _angular_core.Signal<string | undefined>;
    protected _onChange?: ChangeFn<T[] | undefined | null>;
    protected _onTouched?: TouchFn;
    constructor();
    registerSelectTrigger(input: BrnSelectTrigger): void;
    updateTriggerWidth(width: number | null): void;
    isSelected(itemValue: T): boolean;
    select(itemValue: T): void;
    /** Select the active item with Enter key. */
    selectActiveItem(): void;
    open(): void;
    close(): void;
    toggle(): void;
    /** CONTROL VALUE ACCESSOR */
    writeValue(value: T[] | undefined | null): void;
    registerOnChange(fn: ChangeFn<T[] | undefined | null>): void;
    registerOnTouched(fn: TouchFn): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectMultiple<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectMultiple<any>, "[brnSelectMultiple]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "isItemEqualToValue": { "alias": "isItemEqualToValue"; "required": false; "isSignal": true; }; "itemToString": { "alias": "itemToString"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, ["items"], never, true, [{ directive: typeof i1.BrnFieldControl; inputs: {}; outputs: {}; }]>;
}

declare class BrnSelectPlaceholder {
    private readonly _select;
    protected readonly _hasValue: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectPlaceholder, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectPlaceholder, "[brnSelectPlaceholder]", never, {}, {}, never, never, true, never>;
}

declare class BrnSelectScrollDown {
    private readonly _el;
    private readonly _destroyRef;
    private readonly _selectContent;
    protected readonly _showScrollDown: _angular_core.Signal<boolean>;
    private readonly _endReached;
    protected _scrollDown(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectScrollDown, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectScrollDown, "[brnSelectScrollDown]", never, {}, {}, never, never, true, never>;
}

declare class BrnSelectScrollUp {
    private readonly _el;
    private readonly _destroyRef;
    private readonly _selectContent;
    protected readonly _showScrollUp: _angular_core.Signal<boolean>;
    private readonly _endReached;
    protected _scrollUp(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectScrollUp, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectScrollUp, "[brnSelectScrollUp]", never, {}, {}, never, never, true, never>;
}

declare class BrnSelectSeparator {
    readonly orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectSeparator, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectSeparator, "[brnSelectSeparator]", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnSelectValue<T> {
    private readonly _select;
    readonly placeholder: _angular_core.InputSignal<string>;
    protected readonly _isPlaceholder: _angular_core.Signal<boolean>;
    readonly hidden: _angular_core.Signal<boolean>;
    protected readonly _value: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectValue<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectValue<any>, "[brnSelectValue]", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnSelectValueTemplate<T> {
    private readonly _templateRef;
    private readonly _viewContainerRef;
    private readonly _select;
    protected readonly _value: _angular_core.Signal<T | null>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectValueTemplate<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectValueTemplate<any>, "[brnSelectValueTemplate]", never, {}, {}, never, never, true, never>;
}

declare class BrnSelectValues<T> {
    private readonly _templateRef;
    private readonly _viewContainerRef;
    private readonly _select;
    protected readonly _values: _angular_core.Signal<T[] | null | undefined>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnSelectValues<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnSelectValues<any>, "[brnSelectValues]", never, {}, {}, never, never, true, never>;
}

declare const BrnSelectItemToken: InjectionToken<BrnSelectItem<unknown>>;
declare function provideBrnSelectItem<T>(selectItem: Type<BrnSelectItem<T>>): ExistingProvider;

declare const BrnSelectImports: readonly [typeof BrnSelect, typeof BrnSelectContent, typeof BrnSelectGroup, typeof BrnSelectItem, typeof BrnSelectLabel, typeof BrnSelectList, typeof BrnSelectMultiple, typeof BrnSelectPlaceholder, typeof BrnSelectScrollUp, typeof BrnSelectScrollDown, typeof BrnSelectSeparator, typeof BrnSelectTrigger, typeof BrnSelectValue, typeof BrnSelectValueTemplate, typeof BrnSelectValues];

export { BRN_SELECT_MULTIPLE_VALUE_ACCESSOR, BRN_SELECT_VALUE_ACCESSOR, BrnSelect, BrnSelectBaseToken, BrnSelectContent, BrnSelectGroup, BrnSelectImports, BrnSelectItem, BrnSelectItemToken, BrnSelectLabel, BrnSelectList, BrnSelectMultiple, BrnSelectPlaceholder, BrnSelectScrollDown, BrnSelectScrollUp, BrnSelectSeparator, BrnSelectTrigger, BrnSelectValue, BrnSelectValueTemplate, BrnSelectValues, injectBrnSelectBase, injectBrnSelectConfig, provideBrnSelectBase, provideBrnSelectConfig, provideBrnSelectItem };
export type { BrnSelectBase, BrnSelectConfig, SelectItemEqualToValue, SelectItemToString };
