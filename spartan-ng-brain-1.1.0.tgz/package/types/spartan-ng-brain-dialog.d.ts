import * as _angular_cdk_dialog from '@angular/cdk/dialog';
import { AutoFocusTarget, RestoreFocusValue, DialogRef } from '@angular/cdk/dialog';
import * as _angular_cdk_overlay from '@angular/cdk/overlay';
import { ConnectedPosition, FlexibleConnectedPositionStrategyOrigin, PositionStrategy, ScrollStrategy, OverlayPositionBuilder, ComponentType } from '@angular/cdk/overlay';
import * as _angular_core from '@angular/core';
import { StaticProvider, Signal, TemplateRef, Injector, ValueProvider, ViewContainerRef, InjectOptions } from '@angular/core';
import * as _spartan_ng_brain_dialog from '@spartan-ng/brain/dialog';
import { BooleanInput } from '@angular/cdk/coercion';
import { Direction } from '@angular/cdk/bidi';
import { Observable } from 'rxjs';
export { cssClassesToArray } from '@spartan-ng/brain/core';

type BrnDialogOptions = {
    ariaDescribedBy: string | null | undefined;
    ariaLabel: string | null | undefined;
    ariaLabelledBy: string | null | undefined;
    ariaModal: boolean;
    attachPositions: ConnectedPosition[];
    attachTo: FlexibleConnectedPositionStrategyOrigin | null | undefined;
    autoFocus: boolean | AutoFocusTarget | (Record<never, never> & string);
    backdropClass: string | string[];
    direction?: Direction;
    closeOnOutsidePointerEvents: boolean;
    disableClose: boolean;
    hasBackdrop: boolean;
    id: string;
    panelClass: string | string[];
    positionStrategy: PositionStrategy | null | undefined;
    providers?: StaticProvider[] | (() => StaticProvider[]);
    restoreFocus: RestoreFocusValue;
    role: 'dialog' | 'alertdialog';
    scrollStrategy: ScrollStrategy | 'close' | 'reposition' | null | undefined;
};

type BrnDialogState = 'closed' | 'open';
type BrnDialogPhase = 'closed' | 'closing' | 'open';
type BrnDialogDismissReason = 'backdrop' | 'escape' | 'outside';

declare class BrnDialog<TResult = unknown, TContext extends Record<string, unknown> = Record<string, unknown>> {
    private readonly _dialogService;
    private readonly _destroyRef;
    private readonly _vcr;
    protected readonly _positionBuilder: OverlayPositionBuilder;
    private readonly _scrollStrategies;
    private readonly _injector;
    private readonly _directionality;
    protected readonly _defaultOptions: _spartan_ng_brain_dialog.BrnDialogDefaultOptions;
    private readonly _dialogRef;
    private readonly _origin;
    private readonly _panelClass;
    private readonly _backdropClass;
    private _content;
    private _destroyed;
    private _overlayClass;
    private readonly _resolvedBackdropClass;
    private readonly _resolvedPanelClass;
    readonly closed: _angular_core.OutputEmitterRef<TResult>;
    readonly stateChanged: _angular_core.OutputEmitterRef<BrnDialogState>;
    readonly stateComputed: Signal<BrnDialogState>;
    readonly id: _angular_core.InputSignal<string>;
    readonly state: _angular_core.InputSignal<BrnDialogState | null>;
    readonly role: _angular_core.InputSignal<"dialog" | "alertdialog">;
    readonly hasBackdrop: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    readonly positionStrategy: _angular_core.InputSignal<_angular_cdk_overlay.PositionStrategy | null | undefined>;
    readonly scrollStrategy: _angular_core.InputSignal<ScrollStrategy | "close" | "reposition" | null | undefined>;
    readonly restoreFocus: _angular_core.InputSignal<_angular_cdk_dialog.RestoreFocusValue>;
    readonly closeOnOutsidePointerEvents: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    readonly attachTo: _angular_core.InputSignal<_angular_cdk_overlay.FlexibleConnectedPositionStrategyOrigin | null | undefined>;
    readonly attachPositions: _angular_core.InputSignal<_angular_cdk_overlay.ConnectedPosition[]>;
    readonly autoFocus: _angular_core.InputSignal<boolean | _angular_cdk_dialog.AutoFocusTarget | (Record<never, never> & string)>;
    readonly disableClose: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    readonly ariaDescribedBy: _angular_core.InputSignal<string | null | undefined>;
    readonly ariaLabelledBy: _angular_core.InputSignal<string | null | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | null | undefined>;
    readonly ariaModal: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    protected readonly _options: Signal<Partial<BrnDialogOptions>>;
    constructor();
    open(): void;
    close(result?: TResult): void;
    registerContent(template: TemplateRef<unknown>, context: Signal<TContext | undefined>, panelClass: Signal<string | null | undefined>): void;
    registerOverlayClass(overlayClass: Signal<string | null | undefined>): void;
    setOrigin(origin: BrnDialogOptions['attachTo']): void;
    setOverlayClass(overlayClass: string | string[] | null | undefined): void;
    setPanelClass(panelClass: string | string[] | null | undefined): void;
    updatePosition(): void;
    protected getAttachTo(): BrnDialogOptions['attachTo'];
    protected getPositionStrategy(): BrnDialogOptions['positionStrategy'];
    private getScrollStrategy;
    private _syncPanelClass;
    private _syncOverlayClass;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnDialog<any, any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnDialog<any, any>, "[brnDialog],brn-dialog", ["brnDialog"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "hasBackdrop": { "alias": "hasBackdrop"; "required": false; "isSignal": true; }; "positionStrategy": { "alias": "positionStrategy"; "required": false; "isSignal": true; }; "scrollStrategy": { "alias": "scrollStrategy"; "required": false; "isSignal": true; }; "restoreFocus": { "alias": "restoreFocus"; "required": false; "isSignal": true; }; "closeOnOutsidePointerEvents": { "alias": "closeOnOutsidePointerEvents"; "required": false; "isSignal": true; }; "attachTo": { "alias": "attachTo"; "required": false; "isSignal": true; }; "attachPositions": { "alias": "attachPositions"; "required": false; "isSignal": true; }; "autoFocus": { "alias": "autoFocus"; "required": false; "isSignal": true; }; "disableClose": { "alias": "disableClose"; "required": false; "isSignal": true; }; "ariaDescribedBy": { "alias": "aria-describedby"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "aria-labelledby"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; "ariaModal": { "alias": "aria-modal"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "stateChanged": "stateChanged"; }, never, never, true, never>;
}

declare class BrnDialogClose {
    private readonly _brnDialogRef;
    close(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnDialogClose, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnDialogClose, "button[brnDialogClose]", never, {}, {}, never, never, true, never>;
}

declare class BrnDialogContent<T extends Record<string, unknown>> {
    private readonly _brnDialog;
    private readonly _brnDialogRef;
    private readonly _template;
    readonly state: _angular_core.Signal<_spartan_ng_brain_dialog.BrnDialogState>;
    readonly className: _angular_core.InputSignal<string | null | undefined>;
    readonly context: _angular_core.InputSignal<T | undefined>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnDialogContent<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnDialogContent<any>, "[brnDialogContent]", never, { "className": { "alias": "class"; "required": false; "isSignal": true; }; "context": { "alias": "context"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnDialogDescription {
    private readonly _brnDialogRef;
    protected readonly _id: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnDialogDescription, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnDialogDescription, "[brnDialogDescription]", never, {}, {}, never, never, true, never>;
}

declare class BrnDialogOverlay {
    private readonly _brnDialog;
    private readonly _customClass;
    readonly className: _angular_core.InputSignal<string | null | undefined>;
    private readonly _resolvedClass;
    constructor();
    setClassToCustomElement(newClass: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnDialogOverlay, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnDialogOverlay, "[brnDialogOverlay],brn-dialog-overlay", never, { "className": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnDialogTitle {
    private readonly _brnDialogRef;
    protected readonly _id: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnDialogTitle, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnDialogTitle, "[brnDialogTitle]", never, {}, {}, never, never, true, never>;
}

declare class BrnDialogTrigger {
    private readonly _injectedDialog;
    private readonly _dialogRef;
    readonly id: _angular_core.InputSignal<string>;
    readonly type: _angular_core.InputSignal<"button" | "submit" | "reset">;
    readonly brnDialogTriggerFor: _angular_core.InputSignal<BrnDialog<unknown, Record<string, unknown>> | undefined>;
    readonly state: _angular_core.Signal<BrnDialogState>;
    readonly dialogId: _angular_core.Signal<string | null>;
    protected getDialog(): BrnDialog | undefined;
    open(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnDialogTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnDialogTrigger, "button[brnDialogTrigger],button[brnDialogTriggerFor]", ["brnDialogTrigger"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "brnDialogTriggerFor": { "alias": "brnDialogTriggerFor"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnDialogRef<DialogResult = unknown> {
    private readonly _cdkDialogRef;
    private readonly _injector;
    readonly dialogId: number;
    private readonly initialOptions;
    private readonly _closing;
    readonly closing$: Observable<void>;
    private readonly _closed;
    readonly closed$: Observable<DialogResult | undefined>;
    private readonly _stateChanged;
    readonly stateChanged$: Observable<BrnDialogState>;
    private readonly _phase;
    readonly phase: _angular_core.Signal<BrnDialogPhase>;
    readonly state: _angular_core.Signal<BrnDialogState>;
    private _closeGeneration;
    private _panelClasses;
    private _backdropClasses;
    get open(): boolean;
    get id(): string;
    constructor(_cdkDialogRef: DialogRef<DialogResult>, _injector: Injector, dialogId: number, initialOptions: BrnDialogOptions);
    close(result?: DialogResult): void;
    dismiss(reason: BrnDialogDismissReason): boolean;
    reopen(): void;
    forceClose(result?: DialogResult): void;
    setPanelClass(panelClass: string | string[] | null | undefined): void;
    setOverlayClass(overlayClass: string | string[] | null | undefined): void;
    updatePosition(): void;
    private _finishClose;
    private _getActiveAnimations;
    private _setDataState;
}

type BrnDialogDefaultOptions = Omit<BrnDialogOptions, 'direction' | 'id' | 'providers'>;
declare const defaultOptions: BrnDialogDefaultOptions;
declare function provideBrnDialogDefaultOptions(options: Partial<BrnDialogDefaultOptions>): ValueProvider;
declare function injectBrnDialogDefaultOptions(): BrnDialogDefaultOptions;

type BrnDialogContext<T> = T & {
    close: (result?: unknown) => void;
};
declare const injectBrnDialogContext: <DialogContext = unknown>(options?: InjectOptions) => DialogContext;
declare class BrnDialogService {
    private readonly _overlayCloseDispatcher;
    private readonly _cdkDialog;
    private readonly _positionBuilder;
    private readonly _scrollStrategies;
    private readonly _injector;
    private readonly _defaultOptions;
    open<DialogContext, DialogResult = unknown>(content: ComponentType<unknown> | TemplateRef<unknown>, vcr?: ViewContainerRef, context?: DialogContext, options?: Partial<BrnDialogOptions>): BrnDialogRef<DialogResult>;
    private _createProviders;
    private _connectDismissalEvents;
    private _isTopmostOutsideTarget;
    private _isNested;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnDialogService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<BrnDialogService>;
}

declare const BrnDialogImports: readonly [typeof BrnDialog, typeof BrnDialogOverlay, typeof BrnDialogTrigger, typeof BrnDialogClose, typeof BrnDialogContent, typeof BrnDialogTitle, typeof BrnDialogDescription];

export { BrnDialog, BrnDialogClose, BrnDialogContent, BrnDialogDescription, BrnDialogImports, BrnDialogOverlay, BrnDialogRef, BrnDialogService, BrnDialogTitle, BrnDialogTrigger, defaultOptions, injectBrnDialogContext, injectBrnDialogDefaultOptions, provideBrnDialogDefaultOptions };
export type { BrnDialogContext, BrnDialogDefaultOptions, BrnDialogDismissReason, BrnDialogOptions, BrnDialogPhase, BrnDialogState };
