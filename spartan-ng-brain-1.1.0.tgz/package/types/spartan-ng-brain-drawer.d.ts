import * as _angular_cdk_overlay from '@angular/cdk/overlay';
import * as i0 from '@angular/core';
import * as i1 from '@spartan-ng/brain/dialog';
import { BrnDialog, BrnDialogClose, BrnDialogContent, BrnDialogOverlay, BrnDialogTrigger } from '@spartan-ng/brain/dialog';
import { ExposesSide } from '@spartan-ng/brain/core';

declare class BrnDrawer extends BrnDialog {
    readonly directionInput: i0.InputSignal<"bottom" | "top" | "left" | "right">;
    readonly direction: i0.WritableSignal<"bottom" | "top" | "left" | "right">;
    protected getPositionStrategy(): _angular_cdk_overlay.GlobalPositionStrategy;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnDrawer, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnDrawer, "[brnDrawer],brn-drawer", ["brnDrawer"], { "directionInput": { "alias": "direction"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnDrawerClose extends BrnDialogClose {
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnDrawerClose, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnDrawerClose, "button[brnDrawerClose]", never, {}, {}, never, never, true, never>;
}

declare class BrnDrawerContent<T extends Record<string, unknown>> extends BrnDialogContent<T> implements ExposesSide {
    readonly side: i0.WritableSignal<"bottom" | "top" | "left" | "right">;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnDrawerContent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnDrawerContent<any>, "[brnDrawerContent]", never, {}, {}, never, never, true, never>;
}

declare class BrnDrawerDescription {
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnDrawerDescription, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnDrawerDescription, "[brnDrawerDescription]", never, {}, {}, never, never, true, [{ directive: typeof i1.BrnDialogDescription; inputs: {}; outputs: {}; }]>;
}

declare class BrnDrawerHandle {
    private readonly _brnDialogRef;
    private readonly _brnDrawer;
    private readonly _element;
    private readonly _document;
    private readonly _destroyRef;
    private _pointerId;
    constructor();
    private _drawerEl;
    private _backdropEl;
    private _direction;
    private _initialBackdropOpacity;
    private _pointerStartX;
    private _pointerStartY;
    private _pointerStart;
    private _pointerType;
    private _isDragging;
    private _isAllowedToDrag;
    private _wasBeyondThreshold;
    private _openTime;
    private _lastTimeDragPrevented;
    private _dragStartTime;
    private _resetTimeout;
    readonly closeThreshold: i0.InputSignal<number>;
    private get _isVertical();
    private get _isPositive();
    private get _dimensionMultiplier();
    private get _swipeThreshold();
    protected _onPointerDown(event: PointerEvent): void;
    private readonly _onPointerMove;
    private readonly _onPointerUp;
    private readonly _onPointerCancel;
    private _shouldDrag;
    private _getTranslate;
    private _resetDrawer;
    private _clearResetTimeout;
    private _animateAndClose;
    private _cleanup;
    private _findScrollableAncestor;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnDrawerHandle, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnDrawerHandle, "[brnDrawerHandle]", never, { "closeThreshold": { "alias": "closeThreshold"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnDrawerOverlay extends BrnDialogOverlay {
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnDrawerOverlay, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnDrawerOverlay, "[brnDrawerOverlay],brn-drawer-overlay", never, {}, {}, never, never, true, never>;
}

declare class BrnDrawerTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnDrawerTitle, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnDrawerTitle, "[brnDrawerTitle]", never, {}, {}, never, never, true, [{ directive: typeof i1.BrnDialogTitle; inputs: {}; outputs: {}; }]>;
}

declare class BrnDrawerTrigger extends BrnDialogTrigger {
    private readonly _drawer;
    readonly direction: i0.InputSignal<"bottom" | "top" | "left" | "right" | undefined>;
    open(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnDrawerTrigger, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnDrawerTrigger, "button[brnDrawerTrigger]", never, { "direction": { "alias": "direction"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const BrnDrawerImports: readonly [typeof BrnDrawer, typeof BrnDrawerOverlay, typeof BrnDrawerTrigger, typeof BrnDrawerClose, typeof BrnDrawerContent, typeof BrnDrawerTitle, typeof BrnDrawerDescription, typeof BrnDrawerHandle];

export { BrnDrawer, BrnDrawerClose, BrnDrawerContent, BrnDrawerDescription, BrnDrawerHandle, BrnDrawerImports, BrnDrawerOverlay, BrnDrawerTitle, BrnDrawerTrigger };
