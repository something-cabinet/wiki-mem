import * as _spartan_ng_brain_forms from '@spartan-ng/brain/forms';
import { ControlState, ChangeFn, TouchFn } from '@spartan-ng/brain/forms';
import * as _angular_core from '@angular/core';
import { InputSignal, ModelSignal, Signal, InjectionToken, Type, ExistingProvider, ValueProvider } from '@angular/core';
import { Highlightable, ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import { BooleanInput } from '@angular/cdk/coercion';
import { ControlValueAccessor } from '@angular/forms';
import * as i1 from '@spartan-ng/brain/field';

declare class BrnAutocompleteInput<T> {
    private static _id;
    private readonly _el;
    private readonly _autocomplete;
    /** The id of the autocomplete input */
    readonly id: _angular_core.InputSignal<string>;
    /** Manual override for aria-invalid. When not set, auto-detects from the parent autocomplete error state. */
    readonly ariaInvalidOverride: _angular_core.InputSignalWithTransform<boolean | undefined, BooleanInput>;
    /** Forces the invalid state visually, regardless of form control state. */
    readonly forceInvalid: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    readonly disabled: _angular_core.Signal<boolean>;
    /** Whether the autocomplete panel is expanded */
    protected readonly _isExpanded: _angular_core.Signal<boolean>;
    /** Computed aria-invalid: uses manual override if provided, otherwise reads from parent error state. */
    protected readonly _ariaInvalid: _angular_core.Signal<boolean | undefined>;
    protected readonly _spartanInvalid: _angular_core.Signal<boolean | undefined>;
    protected readonly _touched: _angular_core.Signal<boolean | undefined>;
    protected readonly _dirty: _angular_core.Signal<boolean | undefined>;
    constructor();
    protected onInput(event: Event): void;
    protected onKeyDown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteInput<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteInput<any>, "input[brnAutocompleteInput]", ["brnAutocompleteInput"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaInvalidOverride": { "alias": "aria-invalid"; "required": false; "isSignal": true; }; "forceInvalid": { "alias": "forceInvalid"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnAutocompleteItem<T> implements Highlightable {
    private static _id;
    private readonly _platform;
    private readonly _elementRef;
    /** Access the autocomplete component */
    private readonly _autocomplete;
    /** A unique id for the item */
    readonly id: _angular_core.InputSignal<string>;
    /** The value this item represents. */
    readonly value: _angular_core.InputSignal<T>;
    readonly _disabled: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Expose disabled as a value - used by the Highlightable interface */
    get disabled(): boolean;
    /** Whether the item is selected. */
    readonly active: _angular_core.Signal<boolean>;
    protected readonly _highlighted: _angular_core.WritableSignal<boolean>;
    setActiveStyles(): void;
    setInactiveStyles(): void;
    getLabel(): string;
    protected select(): void;
    protected activate(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteItem<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteItem<any>, "[brnAutocompleteItem]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": true; "isSignal": true; }; "_disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface BrnAutocompleteBase<T> {
    itemToString: InputSignal<AutocompleteItemToString<T> | undefined>;
    search: ModelSignal<string>;
    disabled: Signal<boolean>;
    disabledState: Signal<boolean>;
    keyManager: ActiveDescendantKeyManager<BrnAutocompleteItem<T>>;
    value: ModelSignal<T | undefined | null> | ModelSignal<string | undefined | null>;
    visibleItems: Signal<boolean>;
    isExpanded: Signal<boolean>;
    searchInputWrapperWidth: Signal<number | null>;
    controlState: Signal<ControlState | null> | undefined;
    updateSearch: (value: string) => void;
    isSelected: (itemValue: T) => boolean;
    select: (itemValue: T) => void;
    open: () => void;
    resetValue: () => void;
    /** Select the active item with Enter key. */
    selectActiveItem: () => void;
    registerAutocompleteInput: (input: BrnAutocompleteInput<T>) => void;
    updateInputWidth: (width: number | null) => void;
}
declare const BrnAutocompleteBaseToken: InjectionToken<BrnAutocompleteBase<unknown>>;
declare function provideBrnAutocompleteBase<T>(autocomplete: Type<BrnAutocompleteBase<T>>): ExistingProvider;
declare function injectBrnAutocompleteBase<T>(): BrnAutocompleteBase<T>;
type AutocompleteItemEqualToValue<T> = (itemValue: T, selectedValue: T | undefined | null) => boolean;
type AutocompleteItemToString<T> = (itemValue: T) => string;
interface BrnAutocompleteConfig<T> {
    isItemEqualToValue: AutocompleteItemEqualToValue<T>;
    itemToString?: AutocompleteItemToString<T>;
    autoHighlight: boolean;
}
declare function provideBrnAutocompleteConfig<T>(config: Partial<BrnAutocompleteConfig<T>>): ValueProvider;
declare function injectBrnAutocompleteConfig<T>(): BrnAutocompleteConfig<T>;

declare const BRN_AUTOCOMPLETE_CONTROL_VALUE_ACCESSOR: {
    provide: _angular_core.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: _angular_core.Type<any>;
    multi: boolean;
};
declare class BrnAutocomplete<T> implements BrnAutocompleteBase<T>, ControlValueAccessor {
    private readonly _injector;
    private readonly _fieldControl;
    private readonly _config;
    /** Access the popover if present */
    private readonly _brnPopover;
    /** Whether the autocomplete is disabled */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    protected readonly _disabled: _angular_core.WritableSignal<boolean>;
    /** @internal The disabled state as a readonly signal */
    readonly disabledState: _angular_core.Signal<boolean>;
    /** A function to compare an item with the selected value. */
    readonly isItemEqualToValue: _angular_core.InputSignal<AutocompleteItemEqualToValue<T>>;
    /** A function to convert an item to a string for display. */
    readonly itemToString: _angular_core.InputSignal<AutocompleteItemToString<T> | undefined>;
    /** Whether to auto-highlight the first matching item. */
    readonly autoHighlight: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** The selected value of the autocomplete. */
    readonly value: _angular_core.ModelSignal<T | null | undefined>;
    /** The current search query. */
    readonly search: _angular_core.ModelSignal<string>;
    private readonly _inputWidth;
    /** @internal The width of the search input wrapper */
    readonly searchInputWrapperWidth: _angular_core.Signal<number | null>;
    /** @internal Access all the items within the autocomplete */
    readonly items: _angular_core.Signal<readonly BrnAutocompleteItem<T>[]>;
    /** Determine if the autocomplete has any visible items */
    readonly visibleItems: _angular_core.Signal<boolean>;
    /** @internal The key manager for managing active descendant */
    readonly keyManager: ActiveDescendantKeyManager<BrnAutocompleteItem<T>>;
    /** @internal Whether the autocomplete is expanded */
    readonly isExpanded: _angular_core.Signal<boolean>;
    private readonly _autocompleteInput;
    protected _onChange?: ChangeFn<T | undefined | null>;
    protected _onTouched?: TouchFn;
    readonly labelableId: _angular_core.Signal<string | undefined>;
    readonly controlState: _angular_core.Signal<_spartan_ng_brain_forms.ControlState | null> | undefined;
    constructor();
    registerAutocompleteInput(input: BrnAutocompleteInput<T>): void;
    updateInputWidth(width: number | null): void;
    updateSearch(value: string): void;
    isSelected(itemValue: T): boolean;
    select(itemValue: T): void;
    /** Select the active item with Enter key. */
    selectActiveItem(): void;
    resetValue(): void;
    open(): void;
    close(): void;
    toggle(): void;
    /** CONTROL VALUE ACCESSOR */
    writeValue(value: T | undefined | null): void;
    registerOnChange(fn: ChangeFn<T | undefined | null>): void;
    registerOnTouched(fn: TouchFn): void;
    setDisabledState(isDisabled: boolean): void;
    protected _onFocusOut(event: FocusEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocomplete<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocomplete<any>, "[brnAutocomplete]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "isItemEqualToValue": { "alias": "isItemEqualToValue"; "required": false; "isSignal": true; }; "itemToString": { "alias": "itemToString"; "required": false; "isSignal": true; }; "autoHighlight": { "alias": "autoHighlight"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "search": { "alias": "search"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "search": "searchChange"; }, ["items"], never, true, [{ directive: typeof i1.BrnFieldControl; inputs: {}; outputs: {}; }]>;
}

declare class BrnAutocompleteAnchor {
    private readonly _host;
    private readonly _brnOverlay;
    private readonly _autocomplete;
    private readonly _elementSize;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteAnchor, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteAnchor, "[brnAutocompleteAnchor]", never, {}, {}, never, never, true, never>;
}

declare class BrnAutocompleteClear {
    private readonly _autocomplete;
    private readonly _renderer;
    private readonly _templateRef;
    private readonly _viewContainerRef;
    /** Determine if the autocomplete has a value or search text */
    private readonly _shouldShowClear;
    constructor();
    clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteClear, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteClear, "[brnAutocompleteClear]", never, {}, {}, never, never, true, never>;
}

declare class BrnAutocompleteContent {
    private readonly _autocomplete;
    /** Determine if the autocomplete has any visible items */
    protected readonly _visibleItems: _angular_core.Signal<boolean>;
    protected readonly _autocompleteWidth: _angular_core.Signal<number | null>;
    protected readonly _dataState: _angular_core.Signal<"closed" | "open">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteContent, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteContent, "[brnAutocompleteContent]", never, {}, {}, never, never, true, never>;
}

declare class BrnAutocompleteEmpty {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteEmpty, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteEmpty, "[brnAutocompleteEmpty]", never, {}, {}, never, never, true, never>;
}

declare class BrnAutocompleteGroup {
    /** Get the items in the group */
    private readonly _items;
    /** Determine if there are any visible items in the group */
    protected readonly _visible: _angular_core.Signal<boolean>;
    /** Get the label associated with the group */
    private readonly _label;
    protected readonly _labelledBy: _angular_core.Signal<string | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteGroup, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteGroup, "[brnAutocompleteGroup]", never, {}, {}, ["_items", "_label"], never, true, never>;
}

declare class BrnAutocompleteLabel {
    private static _id;
    /** The id of the autocomplete label */
    readonly id: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteLabel, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteLabel, "[brnAutocompleteLabel]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnAutocompleteList {
    private static _id;
    private readonly _autocomplete;
    /** Determine if the autocomplete has any visible items */
    protected readonly _visibleItems: _angular_core.Signal<boolean>;
    /** The id of the autocomplete list */
    readonly id: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteList, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteList, "[brnAutocompleteList]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const BRN_AUTOCOMPLETE_SEARCH_VALUE_ACCESSOR: {
    provide: _angular_core.InjectionToken<readonly ControlValueAccessor[]>;
    useExisting: _angular_core.Type<any>;
    multi: boolean;
};
declare class BrnAutocompleteSearch<T> implements BrnAutocompleteBase<T>, ControlValueAccessor {
    private readonly _injector;
    private readonly _fieldControl;
    private readonly _config;
    /** Access the popover if present */
    private readonly _brnPopover;
    readonly controlState: _angular_core.Signal<_spartan_ng_brain_forms.ControlState | null> | undefined;
    /** Whether the autocomplete is disabled */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    protected readonly _disabled: _angular_core.WritableSignal<boolean>;
    /** @internal The disabled state as a readonly signal */
    readonly disabledState: _angular_core.Signal<boolean>;
    /** A function to convert an item to a string for display. */
    readonly itemToString: _angular_core.InputSignal<AutocompleteItemToString<T> | undefined>;
    /** Whether to auto-highlight the first matching item. */
    readonly autoHighlight: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** The selected value of the autocomplete. */
    readonly value: _angular_core.ModelSignal<string | null | undefined>;
    /** The current search query. */
    readonly search: _angular_core.ModelSignal<string>;
    private readonly _inputWidth;
    /** @internal The width of the search input wrapper */
    readonly searchInputWrapperWidth: _angular_core.Signal<number | null>;
    /** @internal Access all the items within the autocomplete */
    readonly items: _angular_core.Signal<readonly BrnAutocompleteItem<T>[]>;
    /** Determine if the autocomplete has any visible items */
    readonly visibleItems: _angular_core.Signal<boolean>;
    /** @internal The key manager for managing active descendant */
    readonly keyManager: ActiveDescendantKeyManager<BrnAutocompleteItem<T>>;
    /** @internal Whether the autocomplete is expanded */
    readonly isExpanded: _angular_core.Signal<boolean>;
    private readonly _autocompleteInput;
    protected _onChange?: ChangeFn<string | undefined | null>;
    protected _onTouched?: TouchFn;
    readonly labelableId: _angular_core.Signal<string | undefined>;
    constructor();
    registerAutocompleteInput(input: BrnAutocompleteInput<T>): void;
    updateInputWidth(width: number | null): void;
    updateSearch(value: string): void;
    isSelected(itemValue: T): boolean;
    select(itemValue: T): void;
    /** Select the active item with Enter key. */
    selectActiveItem(): void;
    resetValue(): void;
    open(): void;
    close(): void;
    toggle(): void;
    /** CONTROL VALUE ACCESSOR */
    writeValue(value: string | undefined | null): void;
    registerOnChange(fn: ChangeFn<string | undefined | null>): void;
    registerOnTouched(fn: TouchFn): void;
    setDisabledState(isDisabled: boolean): void;
    protected _onFocusOut(event: FocusEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteSearch<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteSearch<any>, "[brnAutocomplete]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "itemToString": { "alias": "itemToString"; "required": false; "isSignal": true; }; "autoHighlight": { "alias": "autoHighlight"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "search": { "alias": "search"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "search": "searchChange"; }, ["items"], never, true, [{ directive: typeof i1.BrnFieldControl; inputs: {}; outputs: {}; }]>;
}

declare class BrnAutocompleteSeparator {
    readonly orientation: _angular_core.InputSignal<"vertical" | "horizontal">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteSeparator, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteSeparator, "[brnAutocompleteSeparator]", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnAutocompleteStatus {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnAutocompleteStatus, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnAutocompleteStatus, "[brnAutocompleteStatus]", never, {}, {}, never, never, true, never>;
}

declare const BrnAutocompleteItemToken: InjectionToken<BrnAutocompleteItem<unknown>>;
declare function provideBrnAutocompleteItem<T>(autocomplete: Type<BrnAutocompleteItem<T>>): ExistingProvider;

declare const BrnAutocompleteImports: readonly [typeof BrnAutocomplete, typeof BrnAutocompleteAnchor, typeof BrnAutocompleteClear, typeof BrnAutocompleteContent, typeof BrnAutocompleteEmpty, typeof BrnAutocompleteGroup, typeof BrnAutocompleteInput, typeof BrnAutocompleteItem, typeof BrnAutocompleteLabel, typeof BrnAutocompleteList, typeof BrnAutocompleteSearch, typeof BrnAutocompleteSeparator, typeof BrnAutocompleteStatus];

export { BRN_AUTOCOMPLETE_CONTROL_VALUE_ACCESSOR, BRN_AUTOCOMPLETE_SEARCH_VALUE_ACCESSOR, BrnAutocomplete, BrnAutocompleteAnchor, BrnAutocompleteBaseToken, BrnAutocompleteClear, BrnAutocompleteContent, BrnAutocompleteEmpty, BrnAutocompleteGroup, BrnAutocompleteImports, BrnAutocompleteInput, BrnAutocompleteItem, BrnAutocompleteItemToken, BrnAutocompleteLabel, BrnAutocompleteList, BrnAutocompleteSearch, BrnAutocompleteSeparator, BrnAutocompleteStatus, injectBrnAutocompleteBase, injectBrnAutocompleteConfig, provideBrnAutocompleteBase, provideBrnAutocompleteConfig, provideBrnAutocompleteItem };
export type { AutocompleteItemEqualToValue, AutocompleteItemToString, BrnAutocompleteBase, BrnAutocompleteConfig };
