import * as _spartan_ng_brain_popover from '@spartan-ng/brain/popover';
import { BrnPopover } from '@spartan-ng/brain/popover';
import * as _spartan_ng_brain_date_picker from '@spartan-ng/brain/date-picker';
import * as _angular_core from '@angular/core';
import { Signal, InjectionToken, Type, ExistingProvider } from '@angular/core';
import { BooleanInput } from '@angular/cdk/coercion';

/**
 * Headless behavior shared by every date picker text input (single, multi,
 * range, month-year). Owns the editable text mirror, cursor preservation and
 * the commit/parse lifecycle; styled subclasses provide the template, styling
 * and the parse/format strategy.
 *
 * `V` is the value type held by the associated date picker (e.g. `Date`,
 * `Date[]` or `[Date, Date]`).
 */
declare abstract class BrnDateInput<V> {
    private static _nextId;
    readonly inputId: _angular_core.InputSignal<string>;
    private readonly _document;
    private readonly _host;
    private readonly _inputElement;
    private _pendingSelection;
    protected readonly _datePicker: _spartan_ng_brain_date_picker.BrnDatePickerBase<V>;
    protected readonly _popover: _angular_core.Signal<_spartan_ng_brain_popover.BrnPopover>;
    protected readonly _disabled: _angular_core.Signal<boolean>;
    /** Initial text shown in the input. Mirrored by the picker once a date is committed. */
    readonly inputValue: _angular_core.InputSignal<string>;
    /** Show a clear button that resets the input and picker value. Hidden when empty. */
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Open the popover on input click. */
    readonly openOnClick: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Forces the invalid state visually, regardless of form control state. */
    readonly forceInvalid: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    /** Accessible label for the clear button. */
    readonly clearAriaLabel: _angular_core.InputSignal<string>;
    /** Accessible label for the calendar trigger button. */
    readonly calendarAriaLabel: _angular_core.InputSignal<string>;
    /** @internal Id used by the trigger contract for labeling. */
    readonly triggerId: _angular_core.Signal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    /**
     * Parse user-entered text into the picker value. Return `null` for
     * invalid input - the picker's value is cleared while the text is preserved
     * so the user can fix it.
     */
    protected abstract parseValue(value: string): V | null;
    /**
     * Format the committed value into the input/edit format shown while the
     * input is focused. On blur the picker's display format is restored.
     */
    protected abstract formatInputValue(value: V): string;
    /**
     * Text shown in the input. Mirrors the picker's `formattedDate` and the
     * parent's `inputValue`, and accepts user writes via `_handleInputChange`.
     * Commits only happen on blur / Enter, so in-progress text isn't clobbered.
     */
    protected readonly _inputValue: _angular_core.WritableSignal<string>;
    protected readonly _showClearButton: _angular_core.Signal<boolean>;
    constructor();
    protected _handleInputChange(event: Event): void;
    protected _clear(): void;
    protected _handleEnter(event: Event): void;
    /** On focus, reformat the committed value into the input/edit format. */
    protected _handleFocus(): void;
    /** On blur, commit the input and snap back to the picker's display format. */
    protected _handleBlur(): void;
    protected _commitDate(): void;
    protected _open(): void;
    protected _handleClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnDateInput<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnDateInput<any>, never, never, { "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "inputValue": { "alias": "inputValue"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "openOnClick": { "alias": "openOnClick"; "required": false; "isSignal": true; }; "forceInvalid": { "alias": "forceInvalid"; "required": false; "isSignal": true; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; "isSignal": true; }; "calendarAriaLabel": { "alias": "calendarAriaLabel"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface BrnDatePickerTriggerBase {
    triggerId: Signal<string>;
}
declare const BrnDatePickerTriggerToken: InjectionToken<BrnDatePickerTriggerBase>;
declare function provideBrnDatePickerTrigger(instance: Type<BrnDatePickerTriggerBase>): ExistingProvider;

interface BrnDatePickerBase<T> {
    popover: Signal<BrnPopover>;
    disabledState: Signal<boolean>;
    formattedDate: Signal<string | undefined>;
    hasDate: Signal<boolean>;
    /** The current raw value. Used by inputs to reformat into the input format on focus. Optional. */
    value?: Signal<T | null>;
    /** Commit a date to the picker (e.g. from a parsed input). Pass `null` to clear. Optional. */
    updateDate?(value: T | null): void;
    touched?(): void;
}
declare const BrnDatePickerToken: InjectionToken<BrnDatePickerBase<unknown>>;
declare function provideBrnDatePicker(instance: Type<BrnDatePickerBase<unknown>>): ExistingProvider;
/**
 * Inject the date picker component.
 */
declare function injectBrnDatePicker<T>(): BrnDatePickerBase<T>;

export { BrnDateInput, BrnDatePickerToken, BrnDatePickerTriggerToken, injectBrnDatePicker, provideBrnDatePicker, provideBrnDatePickerTrigger };
export type { BrnDatePickerBase, BrnDatePickerTriggerBase };
