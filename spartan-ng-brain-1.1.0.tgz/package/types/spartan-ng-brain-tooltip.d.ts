import * as _angular_core from '@angular/core';
import { TemplateRef, Provider, ValueProvider } from '@angular/core';
import { ConnectedPosition } from '@angular/cdk/overlay';
import { ClassValue } from 'clsx';

type BrnTooltipPosition = 'top' | 'bottom' | 'left' | 'right';
/** Fallback order for each preferred position when it doesn't fit in the viewport. */
declare const BRN_TOOLTIP_FALLBACK_POSITIONS: Record<BrnTooltipPosition, BrnTooltipPosition[]>;
/** Map a resolved CDK ConnectedPosition back to a BrnTooltipPosition, or null if no match. */
declare function resolveTooltipPosition(pair: ConnectedPosition): BrnTooltipPosition | null;

type BrnTooltipType = string | TemplateRef<void> | null;

declare class BrnTooltip {
    private readonly _config;
    private readonly _destroyRef;
    private readonly _document;
    private readonly _elementRef;
    private readonly _injector;
    private readonly _overlay;
    private readonly _overlayPositionBuilder;
    private readonly _renderer;
    private readonly _dir;
    private readonly _group;
    private _tooltipHovered;
    private _listenersRefs;
    private _delaySubject;
    private _componentRef;
    private _overlayRef;
    private _ariaEffectRef;
    private _positionChangeSub;
    /** Bumped on every close/show so a pending exit-animation teardown can detect it was superseded. */
    private _closeGeneration;
    /** The position currently applied to the content - the CDK-resolved one after a flip, not the raw input. */
    private _activePosition;
    readonly tooltipDisabled: _angular_core.InputSignalWithTransform<boolean, boolean>;
    readonly mutableTooltipDisabled: _angular_core.WritableSignal<boolean>;
    readonly position: _angular_core.InputSignal<BrnTooltipPosition>;
    readonly brnTooltip: _angular_core.InputSignal<BrnTooltipType>;
    readonly showDelay: _angular_core.InputSignalWithTransform<number, number>;
    readonly hideDelay: _angular_core.InputSignalWithTransform<number, number>;
    readonly show: _angular_core.OutputEmitterRef<void>;
    readonly hide: _angular_core.OutputEmitterRef<void>;
    private readonly _tooltipText;
    constructor();
    private _updatePosition;
    private _buildPositionStrategy;
    /** Build [preferred, ...fallbacks] position array for viewport-aware auto-flip. */
    private _getAllPositions;
    private _getAdjustedPositionFor;
    private _initTriggers;
    private _initHoverListeners;
    /** Snapshot the group skip decision once, so the delay and the instant-open state agree even if a
     *  sibling flips the window during the show delay. */
    private _requestShow;
    private _initScrollListener;
    private _cleanupTriggerEvents;
    private delay;
    private _setupDelayMechanism;
    private _show;
    /** Apply text + position (and the position-derived classes) to the content, recording the position as
     *  active. Pass `text = null` for a position-only update that keeps the content's existing text. */
    private _applyContentProps;
    private _hide;
    /**
     * Keep the content mounted until its `data-[state=closed]` exit animation finishes, then tear it
     * down. A re-show (revive) bumps `_closeGeneration`, which cancels the pending detach.
     */
    private _scheduleDetach;
    private _detach;
    private _clearAriaDescribedBy;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnTooltip, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnTooltip, "[brnTooltip]", ["brnTooltip"], { "tooltipDisabled": { "alias": "tooltipDisabled"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "brnTooltip": { "alias": "brnTooltip"; "required": false; "isSignal": true; }; "showDelay": { "alias": "showDelay"; "required": false; "isSignal": true; }; "hideDelay": { "alias": "hideDelay"; "required": false; "isSignal": true; }; }, { "show": "show"; "hide": "hide"; }, never, never, true, never>;
}

declare class BrnTooltipContent {
    readonly id: _angular_core.InputSignal<string>;
    readonly state: _angular_core.WritableSignal<"closed" | "open" | "instant-open">;
    protected readonly _tooltipClass: _angular_core.WritableSignal<ClassValue>;
    protected readonly _arrowClass: _angular_core.WritableSignal<ClassValue>;
    protected readonly _svgClass: _angular_core.WritableSignal<ClassValue>;
    protected readonly _position: _angular_core.WritableSignal<BrnTooltipPosition>;
    protected readonly _tooltipText: _angular_core.WritableSignal<BrnTooltipType>;
    setProps(tooltipText: BrnTooltipType, position: BrnTooltipPosition, tooltipClasses: ClassValue, arrowClasses: ClassValue, svgClasses: ClassValue): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnTooltipContent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BrnTooltipContent, "ng-component", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface BrnTooltipGroupOptions {
    /** Time (ms) after the last tooltip closes during which others open instantly. `0` disables it. */
    skipDelayDuration: number;
}
/** Skip-delay coordinator for grouped tooltips; provide via `provideBrnTooltipGroup` on the wrapper. */
declare class BrnTooltipGroup {
    private readonly _options;
    private readonly _skipDelay;
    /** Whether the next tooltip waits for its show delay, or opens instantly within the skip window. */
    readonly isOpenDelayed: _angular_core.Signal<boolean>;
    onOpen(): void;
    onClose(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnTooltipGroup, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<BrnTooltipGroup>;
}
declare function provideBrnTooltipGroup(options?: Partial<BrnTooltipGroupOptions>): Provider[];

interface BrnTooltipOptions {
    /** Default delay when the tooltip is shown. */
    showDelay: number;
    /** Default delay when the tooltip is hidden. */
    hideDelay: number;
    /** Default position for tooltips. */
    position?: BrnTooltipPosition;
    /** Additional classes for the SVG element in the tooltip arrow. */
    svgClasses: ClassValue;
    /** Additional classes for the tooltip arrow element based on position. */
    arrowClasses: (position: BrnTooltipPosition) => ClassValue;
    /** Additional classes for the tooltip content element. */
    tooltipContentClasses: ClassValue;
}
declare const defaultOptions: BrnTooltipOptions;
declare function provideBrnTooltipDefaultOptions(options: Partial<BrnTooltipOptions>): ValueProvider;
declare function injectBrnTooltipDefaultOptions(): BrnTooltipOptions;

declare const BrnTooltipImports: readonly [typeof BrnTooltip, typeof BrnTooltipContent];

export { BRN_TOOLTIP_FALLBACK_POSITIONS, BrnTooltip, BrnTooltipContent, BrnTooltipGroup, BrnTooltipImports, defaultOptions, injectBrnTooltipDefaultOptions, provideBrnTooltipDefaultOptions, provideBrnTooltipGroup, resolveTooltipPosition };
export type { BrnTooltipGroupOptions, BrnTooltipOptions, BrnTooltipPosition, BrnTooltipType };
