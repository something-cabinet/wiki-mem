import * as _angular_core from '@angular/core';
import { Signal, NgZone, ElementRef, Injector, InjectionToken } from '@angular/core';
import { Subject, Observable, MonoTypeOperatorFunction } from 'rxjs';
import { ConnectedPosition } from '@angular/cdk/overlay';

/**
 * Returns a signal that emits the previous value of the given signal.
 * The first time the signal is emitted, the previous value will be the same as the current value.
 *
 * @example
 * ```ts
 * const value = signal(0);
 * const previous = computedPrevious(value);
 *
 * effect(() => {
 *  console.log('Current value:', value());
 *  console.log('Previous value:', previous());
 * });
 *
 * Logs:
 * // Current value: 0
 * // Previous value: 0
 *
 * value.set(1);
 *
 * Logs:
 * // Current value: 1
 * // Previous value: 0
 *
 * value.set(2);
 *
 * Logs:
 * // Current value: 2
 * // Previous value: 1
 *```
 *
 * @param computation Signal to compute previous value for
 * @returns Signal that emits previous value of `s`
 */
declare function computedPrevious<T>(computation: Signal<T>): Signal<T>;

declare function isElement(node?: Element | EventTarget | Node | null): node is Element;
declare const createHoverObservable: (nativeElement: HTMLElement, zone: NgZone, destroyed$: Subject<void>) => Observable<{
    hover: boolean;
    relatedTarget?: EventTarget | null;
}>;

declare function cssClassesToArray(classes: string | string[] | null | undefined, defaultClass?: string): string[];

interface CustomElementClassSettable {
    setClassToCustomElement: (newClass: string) => void;
}
declare const injectCustomClassSettable: {
    (): CustomElementClassSettable;
    (injectOptions: _angular_core.InjectOptions & {
        optional?: false;
    }): CustomElementClassSettable;
    (injectOptions: _angular_core.InjectOptions & {
        optional: true;
    }): CustomElementClassSettable | null;
};
declare const provideCustomClassSettable: (value: CustomElementClassSettable) => _angular_core.Provider;
declare const provideCustomClassSettableExisting: (valueFactory: () => _angular_core.Type<CustomElementClassSettable>) => _angular_core.Provider;
declare const SET_CLASS_TO_CUSTOM_ELEMENT_TOKEN: _angular_core.InjectionToken<CustomElementClassSettable>;

/**
 * Creates a debounced version of a source signal.
 *
 * @param source - The input signal to debounce.
 * @param delay - Debounce time in milliseconds.
 * @returns A new signal that updates only after the source has stopped changing for `delay` ms.
 */
declare function debouncedSignal<T>(source: Signal<T>, delay: number): Signal<T>;

/**
 * Set by Angular to true when in development mode.
 * Allows for tree-shaking code that is only used in development.
 */
declare const brnDevMode: boolean;

interface ExposesSide {
    side: Signal<'top' | 'bottom' | 'left' | 'right'>;
}
declare const injectExposedSideProvider: {
    (): ExposesSide;
    (injectOptions: _angular_core.InjectOptions & {
        optional?: false;
    }): ExposesSide;
    (injectOptions: _angular_core.InjectOptions & {
        optional: true;
    }): ExposesSide | null;
};
declare const provideExposedSideProvider: (value: ExposesSide) => _angular_core.Provider;
declare const provideExposedSideProviderExisting: (valueFactory: () => _angular_core.Type<ExposesSide>) => _angular_core.Provider;
declare const EXPOSES_SIDE_TOKEN: _angular_core.InjectionToken<ExposesSide>;

interface ExposesState {
    state: Signal<'open' | 'closed'>;
}
declare const injectExposesStateProvider: {
    (): ExposesState;
    (injectOptions: _angular_core.InjectOptions & {
        optional?: false;
    }): ExposesState;
    (injectOptions: _angular_core.InjectOptions & {
        optional: true;
    }): ExposesState | null;
};
declare const provideExposesStateProvider: (value: ExposesState) => _angular_core.Provider;
declare const provideExposesStateProviderExisting: (valueFactory: () => _angular_core.Type<ExposesState>) => _angular_core.Provider;
declare const EXPOSES_STATE_TOKEN: _angular_core.InjectionToken<ExposesState>;

/** Reactive natural size of a collapsible host's projected content, or `null` before measurement. */
interface ContentDimensions {
    width: Signal<number | null>;
    height: Signal<number | null>;
}
/**
 * Measures the natural size of a collapsible host's content via `scrollHeight` so it can animate
 * between `height: 0` and a measured pixel height - the whole content is covered, regardless of how
 * it is projected. A `ResizeObserver` on the content keeps the value live. SSR-safe; the host must
 * be a block-level element for `scrollHeight` to reflect its content.
 *
 * @returns Signals with the content's width and height in px, or `null` before measurement.
 */
declare function injectContentDimensions(): ContentDimensions;

/**
 * Returns a reactive signal that tracks the size of a DOM element.
 *
 * This function uses a shared {@link ResizeObserver} internally to monitor multiple elements efficiently.
 * The returned signal updates whenever the element's width or height changes. It is fully SSR-safe.
 *
 * @param options Optional {@link ElementSizeOptions} configuration object.
 * @param options.elementRef The {@link ElementRef} of the element to observe. Defaults to the {@link ElementRef} injected in the current context.
 * @param options.injector Optional custom {@link Injector} to run the function in. Defaults to the current injection context.
 *
 * @returns A readonly {@link Signal} containing `{ width, height }` of the element, or `undefined` if the element has not yet been measured or on the server.
 *
 * Based on https://github.com/radix-ui/primitives/blob/main/packages/react/use-size/src/use-size.tsx
 */
declare function injectElementSize(options?: ElementSizeOptions): Signal<{
    width: number;
    height: number;
} | undefined>;
/**
 * Options to configure `injectElementSize`.
 */
interface ElementSizeOptions {
    /** The ElementRef of the element to observe. Defaults to injected ElementRef in the current context. */
    elementRef?: ElementRef<HTMLElement>;
    /** Optional Injector to run the function in. Defaults to the current injection context. */
    injector?: Injector;
}

type MenuAlign = 'start' | 'center' | 'end';
type MenuSide = 'top' | 'bottom' | 'left' | 'right';
/**
 * Lets a menu trigger expose its configured `side` to the portaled content. CDK gives the content a
 * child injector whose parent is the trigger's injector, so the content can resolve this token to
 * learn which axis to read off the transform-origin.
 */
interface MenuSideProvider {
    readonly side: () => MenuSide;
}
declare const MENU_SIDE: InjectionToken<MenuSideProvider>;
declare const deriveMenuSideFromTransformOrigin: (transformOrigin: string, side: MenuSide) => MenuSide;
declare const createMenuPosition: (align: MenuAlign, side: MenuSide) => ConnectedPosition[];

declare function stringifyAsLabel(item: any, itemToStringLabel?: (item: any) => string): string;
declare function serializeValue(value: unknown): string;

/** Skip-delay grouping: once one member opens, siblings skip their delay until the window elapses. */
interface SkipDelay {
    /** Whether the next open should still wait for its delay (`true`) or open instantly (`false`). */
    readonly isOpenDelayed: Signal<boolean>;
    /** Report that a member opened: opens the skip window so siblings skip their delay. */
    open(): void;
    /** Report that a member closed: re-require the delay once the window elapses. */
    close(): void;
}
/** Must be called in an injection context; cleans up its pending timer on destroy. */
declare function injectSkipDelay(skipDelayDuration: () => number): SkipDelay;

interface TableClassesSettable {
    setTableClasses: (classes: Partial<{
        table: string;
        headerRow: string;
        bodyRow: string;
    }>) => void;
}
declare const injectTableClassesSettable: {
    (): TableClassesSettable;
    (injectOptions: _angular_core.InjectOptions & {
        optional?: false;
    }): TableClassesSettable;
    (injectOptions: _angular_core.InjectOptions & {
        optional: true;
    }): TableClassesSettable | null;
};
declare const provideTableClassesSettable: (value: TableClassesSettable) => _angular_core.Provider;
declare const provideTableClassesSettableExisting: (valueFactory: () => _angular_core.Type<TableClassesSettable>) => _angular_core.Provider;
declare const SET_TABLE_CLASSES_TOKEN: _angular_core.InjectionToken<TableClassesSettable>;

declare function getActiveElementAnimations(elements: readonly (HTMLElement | null | undefined)[]): Animation[];
declare function waitForAnimations(animations: readonly Animation[]): Promise<void>;
/**
 * Waits for active animations, including subtree animations, within the given element to finish.
 */
declare function waitForElementAnimations(element: HTMLElement): Promise<void>;

/**
 * We are building on shoulders of giants here and use the implementation provided by the incredible TaigaUI
 * team: https://github.com/taiga-family/taiga-ui/blob/main/projects/cdk/observables/zone-free.ts#L22
 * Check them out! Give them a try! Leave a star! Their work is incredible!
 */

declare function brnZoneFull<T>(zone: NgZone): MonoTypeOperatorFunction<T>;
declare function brnZoneFree<T>(zone: NgZone): MonoTypeOperatorFunction<T>;
declare function brnZoneOptimized<T>(zone: NgZone): MonoTypeOperatorFunction<T>;

export { EXPOSES_SIDE_TOKEN, EXPOSES_STATE_TOKEN, MENU_SIDE, SET_CLASS_TO_CUSTOM_ELEMENT_TOKEN, SET_TABLE_CLASSES_TOKEN, brnDevMode, brnZoneFree, brnZoneFull, brnZoneOptimized, computedPrevious, createHoverObservable, createMenuPosition, cssClassesToArray, debouncedSignal, deriveMenuSideFromTransformOrigin, getActiveElementAnimations, injectContentDimensions, injectCustomClassSettable, injectElementSize, injectExposedSideProvider, injectExposesStateProvider, injectSkipDelay, injectTableClassesSettable, isElement, provideCustomClassSettable, provideCustomClassSettableExisting, provideExposedSideProvider, provideExposedSideProviderExisting, provideExposesStateProvider, provideExposesStateProviderExisting, provideTableClassesSettable, provideTableClassesSettableExisting, serializeValue, stringifyAsLabel, waitForAnimations, waitForElementAnimations };
export type { ContentDimensions, CustomElementClassSettable, ExposesSide, ExposesState, MenuAlign, MenuSide, MenuSideProvider, SkipDelay, TableClassesSettable };
