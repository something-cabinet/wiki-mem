import * as _angular_cdk_overlay from '@angular/cdk/overlay';
import { ConnectedPosition, FlexibleConnectedPositionStrategyOrigin, PositionStrategy, ScrollStrategy, OverlayPositionBuilder, OverlayRef } from '@angular/cdk/overlay';
import * as _angular_core from '@angular/core';
import { StaticProvider, InjectionToken, ValueProvider, Signal, TemplateRef, Injector, ViewContainerRef } from '@angular/core';
import { BooleanInput } from '@angular/cdk/coercion';
import { Direction } from '@angular/cdk/bidi';
import * as _spartan_ng_brain_overlay from '@spartan-ng/brain/overlay';
import { ComponentType } from '@angular/cdk/portal';
import { Observable } from 'rxjs';

type BrnOverlayOptions = {
    attachPositions: ConnectedPosition[];
    attachTo: FlexibleConnectedPositionStrategyOrigin | null | undefined;
    /** Move focus to the first tabbable element inside the overlay when it opens. */
    autoFocus: boolean;
    backdropClass: string | string[];
    closeOnOutsidePointerEvents: boolean;
    direction?: Direction;
    disableClose: boolean;
    hasBackdrop: boolean;
    id: string;
    panelClass: string | string[];
    positionStrategy: PositionStrategy | null | undefined;
    providers?: StaticProvider[] | (() => StaticProvider[]);
    role: string | null;
    scrollStrategy: ScrollStrategy | 'close' | 'reposition' | null | undefined;
};

type BrnOverlayState = 'closed' | 'open';
type BrnOverlayPhase = 'closed' | 'closing' | 'open';
type BrnOverlayDismissReason = 'backdrop' | 'escape' | 'outside';

type BrnOverlayDefaultOptions = Omit<BrnOverlayOptions, 'direction' | 'id' | 'providers'>;
declare const defaultOptions: BrnOverlayDefaultOptions;
declare const BRN_OVERLAY_DEFAULT_OPTIONS: InjectionToken<BrnOverlayDefaultOptions>;
declare function provideBrnOverlayDefaultOptions(options: Partial<BrnOverlayDefaultOptions>): ValueProvider;
declare function injectBrnOverlayDefaultOptions(): BrnOverlayDefaultOptions;
declare const BRN_OVERLAY_DATA: InjectionToken<unknown>;
declare function injectBrnOverlayContext<OverlayContext = unknown>(): OverlayContext;

declare class BrnOverlay<TResult = unknown, TContext extends Record<string, unknown> = Record<string, unknown>> {
    private readonly _overlayService;
    private readonly _destroyRef;
    private readonly _vcr;
    protected readonly _positionBuilder: OverlayPositionBuilder;
    private readonly _scrollStrategies;
    private readonly _injector;
    private readonly _directionality;
    private readonly _document;
    protected readonly _defaultOptions: BrnOverlayDefaultOptions;
    private readonly _overlayRef;
    private readonly _origin;
    private readonly _panelClass;
    private readonly _backdropClass;
    private _content;
    private _destroyed;
    private readonly _resolvedBackdropClass;
    private readonly _resolvedPanelClass;
    readonly closed: _angular_core.OutputEmitterRef<TResult>;
    readonly stateChanged: _angular_core.OutputEmitterRef<BrnOverlayState>;
    readonly stateComputed: Signal<BrnOverlayState>;
    readonly id: _angular_core.InputSignal<string>;
    readonly state: _angular_core.InputSignal<BrnOverlayState | null>;
    readonly role: _angular_core.InputSignal<string | null>;
    readonly hasBackdrop: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    readonly positionStrategy: _angular_core.InputSignal<_angular_cdk_overlay.PositionStrategy | null | undefined>;
    readonly scrollStrategy: _angular_core.InputSignal<ScrollStrategy | "close" | "reposition" | null | undefined>;
    readonly closeOnOutsidePointerEvents: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    readonly attachTo: _angular_core.InputSignal<_angular_cdk_overlay.FlexibleConnectedPositionStrategyOrigin | null | undefined>;
    readonly attachPositions: _angular_core.InputSignal<_angular_cdk_overlay.ConnectedPosition[]>;
    readonly disableClose: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    readonly autoFocus: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    protected readonly _options: Signal<Partial<BrnOverlayOptions>>;
    constructor();
    protected getDefaultOptions(): BrnOverlayDefaultOptions;
    open(): void;
    close(result?: TResult): void;
    toggle(result?: TResult): void;
    registerContent(template: TemplateRef<unknown>, context: Signal<TContext | undefined>, panelClass: Signal<string | null | undefined>): void;
    setOrigin(origin: BrnOverlayOptions['attachTo']): void;
    setOverlayClass(overlayClass: string | string[] | null | undefined): void;
    setPanelClass(panelClass: string | string[] | null | undefined): void;
    updatePosition(): void;
    protected getAttachTo(): BrnOverlayOptions['attachTo'];
    protected getAttachPositions(): BrnOverlayOptions['attachPositions'];
    protected getPositionStrategy(): BrnOverlayOptions['positionStrategy'];
    private getScrollStrategy;
    private _restoreFocus;
    private _syncPanelClass;
    private _syncBackdropClass;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnOverlay<any, any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnOverlay<any, any>, "[brnOverlay],brn-overlay", ["brnOverlay"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "hasBackdrop": { "alias": "hasBackdrop"; "required": false; "isSignal": true; }; "positionStrategy": { "alias": "positionStrategy"; "required": false; "isSignal": true; }; "scrollStrategy": { "alias": "scrollStrategy"; "required": false; "isSignal": true; }; "closeOnOutsidePointerEvents": { "alias": "closeOnOutsidePointerEvents"; "required": false; "isSignal": true; }; "attachTo": { "alias": "attachTo"; "required": false; "isSignal": true; }; "attachPositions": { "alias": "attachPositions"; "required": false; "isSignal": true; }; "disableClose": { "alias": "disableClose"; "required": false; "isSignal": true; }; "autoFocus": { "alias": "autoFocus"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "stateChanged": "stateChanged"; }, never, never, true, never>;
}

declare class BrnOverlayClose {
    private readonly _brnOverlayRef;
    close(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnOverlayClose, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnOverlayClose, "button[brnOverlayClose]", never, {}, {}, never, never, true, never>;
}

declare class BrnOverlayContent<T extends Record<string, unknown>> {
    private readonly _brnOverlay;
    private readonly _brnOverlayRef;
    private readonly _template;
    readonly state: _angular_core.Signal<_spartan_ng_brain_overlay.BrnOverlayState>;
    readonly className: _angular_core.InputSignal<string | null | undefined>;
    readonly context: _angular_core.InputSignal<T | undefined>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnOverlayContent<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnOverlayContent<any>, "[brnOverlayContent]", never, { "className": { "alias": "class"; "required": false; "isSignal": true; }; "context": { "alias": "context"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnOverlayTrigger {
    private readonly _injectedOverlay;
    private readonly _overlayRef;
    readonly id: _angular_core.InputSignal<string>;
    readonly type: _angular_core.InputSignal<"button" | "submit" | "reset">;
    readonly brnOverlayTriggerFor: _angular_core.InputSignal<BrnOverlay<unknown, Record<string, unknown>> | undefined>;
    readonly state: _angular_core.Signal<BrnOverlayState>;
    readonly overlayId: _angular_core.Signal<string | null>;
    protected getOverlay(): BrnOverlay | undefined;
    open(): void;
    toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnOverlayTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BrnOverlayTrigger, "button[brnOverlayTrigger],button[brnOverlayTriggerFor]", ["brnOverlayTrigger"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "brnOverlayTriggerFor": { "alias": "brnOverlayTriggerFor"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnOverlayRef<OverlayResult = unknown> {
    private readonly _overlayRef;
    private readonly _injector;
    readonly overlayId: number;
    private readonly initialOptions;
    private readonly _onDisposed;
    private readonly _closing;
    readonly closing$: Observable<void>;
    private readonly _closed;
    readonly closed$: Observable<OverlayResult | undefined>;
    private readonly _stateChanged;
    readonly stateChanged$: Observable<BrnOverlayState>;
    private readonly _phase;
    readonly phase: _angular_core.Signal<BrnOverlayPhase>;
    readonly state: _angular_core.Signal<BrnOverlayState>;
    private _closeGeneration;
    private _panelClasses;
    private _backdropClasses;
    get open(): boolean;
    get id(): string;
    constructor(_overlayRef: OverlayRef, _injector: Injector, overlayId: number, initialOptions: BrnOverlayOptions, _onDisposed: () => void);
    close(result?: OverlayResult): void;
    dismiss(reason: BrnOverlayDismissReason, target?: EventTarget | null): boolean;
    /** Whether the event target sits within the overlay's origin (its trigger/anchor element). */
    private _isWithinOrigin;
    reopen(): void;
    forceClose(result?: OverlayResult): void;
    setPanelClass(panelClass: string | string[] | null | undefined): void;
    setBackdropClass(backdropClass: string | string[] | null | undefined): void;
    updatePosition(): void;
    private _finishClose;
    private _dispose;
    private _getActiveAnimations;
    private _setDataState;
}

type BrnOverlayContext<T> = T & {
    close: (result?: unknown) => void;
};
declare class BrnOverlayService {
    private readonly _overlay;
    private readonly _positionBuilder;
    private readonly _scrollStrategies;
    private readonly _injector;
    private readonly _interactivityChecker;
    private readonly _defaultOptions;
    private readonly _openOverlayIds;
    private readonly _overlayStack;
    open<OverlayContext, OverlayResult = unknown>(content: ComponentType<unknown> | TemplateRef<unknown>, vcr?: ViewContainerRef, context?: OverlayContext, options?: Partial<BrnOverlayOptions>): BrnOverlayRef<OverlayResult>;
    /**
     * Moves focus to the first tabbable element inside the overlay once its content has rendered.
     * If the overlay has no tabbable content (e.g. a select listbox), focus is left untouched so the
     * trigger keeps it - this is what keeps the `aria-activedescendant` keyboard model working.
     */
    private _focusInitialElement;
    private _firstTabbableElement;
    private _createProviders;
    private _configureElement;
    private _connectDismissalEvents;
    private _requestDismissal;
    private _removeFromStack;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BrnOverlayService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<BrnOverlayService>;
}

declare const BrnOverlayImports: readonly [typeof BrnOverlay, typeof BrnOverlayTrigger, typeof BrnOverlayClose, typeof BrnOverlayContent];

export { BRN_OVERLAY_DATA, BRN_OVERLAY_DEFAULT_OPTIONS, BrnOverlay, BrnOverlayClose, BrnOverlayContent, BrnOverlayImports, BrnOverlayRef, BrnOverlayService, BrnOverlayTrigger, defaultOptions, injectBrnOverlayContext, injectBrnOverlayDefaultOptions, provideBrnOverlayDefaultOptions };
export type { BrnOverlayContext, BrnOverlayDefaultOptions, BrnOverlayDismissReason, BrnOverlayOptions, BrnOverlayPhase, BrnOverlayState };
