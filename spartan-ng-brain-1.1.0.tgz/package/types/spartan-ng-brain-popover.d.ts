import * as _angular_cdk_overlay from '@angular/cdk/overlay';
import { ConnectedPosition } from '@angular/cdk/overlay';
import * as i0 from '@angular/core';
import { ValueProvider } from '@angular/core';
import { NumberInput } from '@angular/cdk/coercion';
import { BrnOverlayDefaultOptions, BrnOverlay, BrnOverlayContent, BrnOverlayTrigger } from '@spartan-ng/brain/overlay';

type BrnPopoverAlign = 'start' | 'center' | 'end';
interface BrnPopoverConfig {
    align: BrnPopoverAlign;
    sideOffset: number;
    offsetX: number;
}
declare function provideBrnPopoverConfig(config: Partial<BrnPopoverConfig>): ValueProvider;
declare function injectBrnPopoverConfig(): BrnPopoverConfig;
declare const BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS: BrnOverlayDefaultOptions;
declare function provideBrnPopoverDefaultOptions(options: Partial<BrnOverlayDefaultOptions>): ValueProvider;
declare function injectBrnPopoverDefaultOptions(): BrnOverlayDefaultOptions;

/** @deprecated Use `BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS`. */
declare const BRN_POPOVER_DIALOG_DEFAULT_OPTIONS: BrnOverlayDefaultOptions;
declare class BrnPopover extends BrnOverlay {
    private readonly _config;
    readonly align: i0.InputSignal<BrnPopoverAlign>;
    readonly sideOffset: i0.InputSignalWithTransform<number, NumberInput>;
    readonly offsetX: i0.InputSignalWithTransform<number, NumberInput>;
    protected getDefaultOptions(): BrnOverlayDefaultOptions;
    protected getAttachPositions(): ConnectedPosition[];
    protected getPositionStrategy(): _angular_cdk_overlay.PositionStrategy | null | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnPopover, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnPopover, "[brnPopover],brn-popover", ["brnPopover"], { "align": { "alias": "align"; "required": false; "isSignal": true; }; "sideOffset": { "alias": "sideOffset"; "required": false; "isSignal": true; }; "offsetX": { "alias": "offsetX"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class BrnPopoverContent<T extends Record<string, unknown>> extends BrnOverlayContent<T> {
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnPopoverContent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnPopoverContent<any>, "[brnPopoverContent]", never, {}, {}, never, never, true, never>;
}

declare class BrnPopoverTrigger extends BrnOverlayTrigger {
    private readonly _host;
    readonly brnPopoverTriggerFor: i0.InputSignal<BrnPopover | undefined>;
    protected getOverlay(): BrnOverlay | undefined;
    open(): void;
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnPopoverTrigger, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnPopoverTrigger, "button[brnPopoverTrigger],button[brnPopoverTriggerFor]", never, { "brnPopoverTriggerFor": { "alias": "brnPopoverTriggerFor"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const BrnPopoverImports: readonly [typeof BrnPopover, typeof BrnPopoverTrigger, typeof BrnPopoverContent];

export { BRN_POPOVER_DIALOG_DEFAULT_OPTIONS, BRN_POPOVER_OVERLAY_DEFAULT_OPTIONS, BrnPopover, BrnPopoverContent, BrnPopoverImports, BrnPopoverTrigger, injectBrnPopoverConfig, injectBrnPopoverDefaultOptions, provideBrnPopoverConfig, provideBrnPopoverDefaultOptions };
export type { BrnPopoverAlign, BrnPopoverConfig };
